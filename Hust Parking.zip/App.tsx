const Stack = createNativeStackNavigator();
import * as React from "react";
import { NavigationContainer } from "@react-navigation/native";
import { useFonts } from "expo-font";
import DanhMucSinhVien from "./screens/DanhMucSinhVien";
import DanhMucQuanLy from "./screens/DanhMucQuanLy";
import NpTin from "./screens/NpTin";
import Feedback from "./screens/Feedback";
import Sao from "./screens/Sao";
import Sao1 from "./screens/Sao1";
import Sao2 from "./screens/Sao2";
import Sao3 from "./screens/Sao3";
import Sao4 from "./screens/Sao4";
import AntenFeedback from "./screens/AntenFeedback";
import SaoAnTen from "./screens/SaoAnTen";
import SaoAnTen1 from "./screens/SaoAnTen1";
import SaoAnTen2 from "./screens/SaoAnTen2";
import SaoAnTen3 from "./screens/SaoAnTen3";
import SaoAnTen4 from "./screens/SaoAnTen4";
import TimBaiGuiXeConTrong from "./screens/TimBaiGuiXeConTrong";
import TimKiemThongTinXe from "./screens/TimKiemThongTinXe";
import SignInQuanLy from "./screens/SignInQuanLy";
import RememberQuanLy from "./screens/RememberQuanLy";
import XinChaoQuyKhach from "./screens/XinChaoQuyKhach";
import Frame from "./screens/Frame";
import Frame1 from "./screens/Frame1";
import Frame2 from "./screens/Frame2";
import Frame3 from "./screens/Frame3";
import Frame4 from "./screens/Frame4";
import KiemtraTaiKhoan from "./screens/KiemtraTaiKhoan";
import KiemtraC from "./screens/KiemtraC";
import KiemtraC1 from "./screens/KiemtraC1";
import KiemtraD from "./screens/KiemtraD";
import KiemtraTC from "./screens/KiemtraTC";
import KiemtraD1 from "./screens/KiemtraD1";
import KiemtraD2 from "./screens/KiemtraD2";
import KiemtraC2 from "./screens/KiemtraC2";
import TimBaiGuiXeKiemTra from "./screens/TimBaiGuiXeKiemTra";
import Frame5 from "./screens/Frame5";
import Frame6 from "./screens/Frame6";
import Frame7 from "./screens/Frame7";
import Frame8 from "./screens/Frame8";
import Frame9 from "./screens/Frame9";
import TimXe from "./screens/TimXe";
import C from "./screens/C";
import GroupInstance from "./screens/GroupInstance";
import C7B from "./screens/C7B";
import Frame10 from "./screens/Frame10";
import D from "./screens/D";
import GroupInstance1 from "./screens/GroupInstance1";
import D3B from "./screens/D3B";
import Frame11 from "./screens/Frame11";
import Tc from "./screens/Tc";
import GroupInstance2 from "./screens/GroupInstance2";
import TcB from "./screens/TcB";
import Frame12 from "./screens/Frame12";
import D1 from "./screens/D1";
import GroupInstance3 from "./screens/GroupInstance3";
import D8B from "./screens/D8B";
import Frame13 from "./screens/Frame13";
import C1 from "./screens/C1";
import GroupInstance4 from "./screens/GroupInstance4";
import C1B from "./screens/C1B";
import Frame14 from "./screens/Frame14";
import SignInSinhVien from "./screens/SignInSinhVien";
import RememberMe from "./screens/RememberMe";

import { createNativeStackNavigator } from "@react-navigation/native-stack";
import { View, Text, Pressable, TouchableOpacity } from "react-native";

const App = () => {
  const [hideSplashScreen, setHideSplashScreen] = React.useState(true);

  const [fontsLoaded, error] = useFonts({
    "Inter-Regular": require("./assets/fonts/Inter-Regular.ttf"),
    "Inter-Medium": require("./assets/fonts/Inter-Medium.ttf"),
    "Inter-SemiBold": require("./assets/fonts/Inter-SemiBold.ttf"),
    "Tienne-Bold": require("./assets/fonts/Tienne-Bold.ttf"),
  });

  if (!fontsLoaded && !error) {
    return null;
  }

  return (
    <>
      <NavigationContainer>
        {hideSplashScreen ? (
          <Stack.Navigator screenOptions={{ headerShown: false }}>
            <Stack.Screen
              name="DanhMucSinhVien"
              component={DanhMucSinhVien}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="DanhMucQuanLy"
              component={DanhMucQuanLy}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="NpTin"
              component={NpTin}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="Feedback"
              component={Feedback}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="Sao"
              component={Sao}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="Sao1"
              component={Sao1}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="Sao2"
              component={Sao2}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="Sao3"
              component={Sao3}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="Sao4"
              component={Sao4}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="AntenFeedback"
              component={AntenFeedback}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="SaoAnTen"
              component={SaoAnTen}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="SaoAnTen1"
              component={SaoAnTen1}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="SaoAnTen2"
              component={SaoAnTen2}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="SaoAnTen3"
              component={SaoAnTen3}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="SaoAnTen4"
              component={SaoAnTen4}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="TimBaiGuiXeConTrong"
              component={TimBaiGuiXeConTrong}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="TimKiemThongTinXe"
              component={TimKiemThongTinXe}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="SignInQuanLy"
              component={SignInQuanLy}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="RememberQuanLy"
              component={RememberQuanLy}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="XinChaoQuyKhach"
              component={XinChaoQuyKhach}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="Frame"
              component={Frame}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="Frame1"
              component={Frame1}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="Frame2"
              component={Frame2}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="Frame3"
              component={Frame3}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="Frame4"
              component={Frame4}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="KiemtraTaiKhoan"
              component={KiemtraTaiKhoan}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="KiemtraC"
              component={KiemtraC}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="KiemtraC1"
              component={KiemtraC1}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="KiemtraD"
              component={KiemtraD}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="KiemtraTC"
              component={KiemtraTC}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="KiemtraD1"
              component={KiemtraD1}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="KiemtraD2"
              component={KiemtraD2}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="KiemtraC2"
              component={KiemtraC2}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="TimBaiGuiXeKiemTra"
              component={TimBaiGuiXeKiemTra}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="Frame5"
              component={Frame5}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="Frame6"
              component={Frame6}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="Frame7"
              component={Frame7}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="Frame8"
              component={Frame8}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="Frame9"
              component={Frame9}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="TimXe"
              component={TimXe}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="C"
              component={C}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="GroupInstance"
              component={GroupInstance}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="C7B"
              component={C7B}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="Frame10"
              component={Frame10}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="D"
              component={D}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="GroupInstance1"
              component={GroupInstance1}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="D3B"
              component={D3B}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="Frame11"
              component={Frame11}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="Tc"
              component={Tc}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="GroupInstance2"
              component={GroupInstance2}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="TcB"
              component={TcB}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="Frame12"
              component={Frame12}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="D1"
              component={D1}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="GroupInstance3"
              component={GroupInstance3}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="D8B"
              component={D8B}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="Frame13"
              component={Frame13}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="C1"
              component={C1}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="GroupInstance4"
              component={GroupInstance4}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="C1B"
              component={C1B}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="Frame14"
              component={Frame14}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="SignInSinhVien"
              component={SignInSinhVien}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="RememberMe"
              component={RememberMe}
              options={{ headerShown: false }}
            />
          </Stack.Navigator>
        ) : null}
      </NavigationContainer>
    </>
  );
};
export default App;

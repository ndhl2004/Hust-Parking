import * as React from "react";
import { Text, StyleSheet, View, Pressable } from "react-native";
import { Padding, Color, FontSize, Border, FontFamily } from "../GlobalStyles";

export type ContentType = {
  /** Action props */
  onButtonPress?: () => void;
};

const Content = ({ onButtonPress }: ContentType) => {
  return (
    <View style={styles.content}>
      <View style={styles.inputAndButton}>
        <View style={[styles.field, styles.fieldBorder]}>
          <Text style={[styles.label, styles.labelTypo]} numberOfLines={1}>
            MSSV
          </Text>
        </View>
        <View style={[styles.field1, styles.field1FlexBox]}>
          <Text style={[styles.label1, styles.labelTypo]} numberOfLines={1}>
            Password
          </Text>
          <View style={styles.fieldChild} />
        </View>
        <Pressable
          style={[styles.button, styles.field1FlexBox]}
          onPress={onButtonPress}
        >
          <Text style={[styles.logInHust, styles.labelTypo]}>
            Log in Hust Parking
          </Text>
        </Pressable>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  fieldBorder: {
    paddingVertical: Padding.p_5xs,
    borderWidth: 1,
    borderColor: Color.colorGainsboro_200,
    borderStyle: "solid",
    backgroundColor: Color.colorWhite,
  },
  labelTypo: {
    textAlign: "left",
    lineHeight: 20,
    fontSize: FontSize.size_sm,
  },
  field1FlexBox: {
    marginTop: 16,
    paddingHorizontal: Padding.p_base,
    flexDirection: "row",
    height: 40,
    borderRadius: Border.br_5xs,
    alignSelf: "stretch",
    alignItems: "center",
  },
  label: {
    flex: 1,
    overflow: "hidden",
    color: Color.colorGray,
    fontFamily: FontFamily.presetsBody2,
    textAlign: "left",
    lineHeight: 20,
    fontSize: FontSize.size_sm,
  },
  field: {
    paddingHorizontal: Padding.p_base,
    flexDirection: "row",
    height: 40,
    borderRadius: Border.br_5xs,
    alignSelf: "stretch",
    paddingVertical: Padding.p_5xs,
    borderWidth: 1,
    borderColor: Color.colorGainsboro_200,
    borderStyle: "solid",
    backgroundColor: Color.colorWhite,
    alignItems: "center",
  },
  label1: {
    width: 186,
    overflow: "hidden",
    color: Color.colorGray,
    fontFamily: FontFamily.presetsBody2,
    textAlign: "left",
    lineHeight: 20,
    fontSize: FontSize.size_sm,
  },
  fieldChild: {
    width: 100,
    height: 100,
    marginLeft: 16,
    overflow: "hidden",
  },
  field1: {
    paddingVertical: Padding.p_5xs,
    borderWidth: 1,
    borderColor: Color.colorGainsboro_200,
    borderStyle: "solid",
    backgroundColor: Color.colorWhite,
    marginTop: 16,
  },
  logInHust: {
    fontWeight: "500",
    fontFamily: FontFamily.smallText,
    color: Color.colorWhite,
    textAlign: "left",
    lineHeight: 20,
    fontSize: FontSize.size_sm,
  },
  button: {
    backgroundColor: Color.colorSalmon,
    justifyContent: "center",
    paddingVertical: 0,
  },
  inputAndButton: {
    width: 327,
  },
  content: {
    position: "absolute",
    marginTop: -82,
    marginLeft: -187.5,
    top: "50%",
    left: "50%",
    height: 220,
    paddingHorizontal: Padding.p_5xl,
    paddingVertical: 0,
    alignItems: "center",
  },
});

export default Content;

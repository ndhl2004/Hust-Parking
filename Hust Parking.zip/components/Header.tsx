import * as React from "react";
import { Image } from "expo-image";
import { StyleSheet, Text, Pressable, View } from "react-native";
import { FontSize, FontFamily, Color, Padding } from "../GlobalStyles";

export type HeaderType = {
  /** Action props */
  onHustParkingPress?: () => void;
};

const Header = ({ onHustParkingPress }: HeaderType) => {
  return (
    <View style={styles.header}>
      <Image
        style={[styles.profileImageIcon, styles.iconLayout]}
        contentFit="cover"
        source={require("../assets/profile-image.png")}
      />
      <Pressable
        style={[styles.hustParking, styles.tabBarItemPosition]}
        onPress={onHustParkingPress}
      >
        <Text style={styles.hustParking1}>Hust Parking</Text>
      </Pressable>
      <View style={[styles.tabBarItem, styles.tabBarItemPosition]}>
        <Image
          style={[styles.homeIcon, styles.iconLayout]}
          contentFit="cover"
          source={require("../assets/home.png")}
        />
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  iconLayout: {
    height: 24,
    width: 24,
  },
  tabBarItemPosition: {
    left: "50%",
    position: "absolute",
  },
  profileImageIcon: {
    top: 16,
    left: 335,
    position: "absolute",
  },
  hustParking1: {
    marginLeft: -63.5,
    fontSize: FontSize.size_xl,
    letterSpacing: -0.4,
    lineHeight: 28,
    fontWeight: "600",
    fontFamily: FontFamily.interSemiBold,
    color: Color.colorRed,
    textAlign: "center",
  },
  hustParking: {
    top: 14,
  },
  homeIcon: {
    overflow: "hidden",
  },
  tabBarItem: {
    marginLeft: -198.5,
    top: 6,
    flexDirection: "row",
    paddingHorizontal: Padding.p_7xl,
    paddingTop: Padding.p_xs,
    paddingBottom: Padding.p_5xs,
  },
  header: {
    top: 44,
    left: 0,
    width: 375,
    height: 56,
    position: "absolute",
  },
});

export default Header;

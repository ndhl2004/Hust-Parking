/* fonts */
export const FontFamily = {
  interSemiBold: "Inter-SemiBold",
  smallText: "Inter-Medium",
  presetsBody2: "Inter-Regular",
  tienneBold: "Tienne-Bold",
};
/* font sizes */
export const FontSize = {
  size_xl: 20,
  size_5xl: 24,
  size_sm: 14,
  presetsBody2_size: 16,
};
/* Colors */
export const Color = {
  colorWhite: "#fff",
  colorRed: "#f61818",
  colorBlack: "#000",
  colorCrimson: "#eb3535",
  colorGainsboro_100: "#e6e6e6",
  colorGainsboro_200: "#e0e0e0",
  colorTomato_100: "#f74444",
  colorTomato_200: "#f53b3b",
  colorSalmon: "#f46b6b",
  colorGray: "#828282",
  colorLightseagreen: "#43b099",
  colorWhitesmoke_100: "#f4f4f4",
  colorWhitesmoke_200: "rgba(245, 245, 245, 0.55)",
  colorLimegreen: "#30e858",
};
/* Paddings */
export const Padding = {
  p_7xl: 26,
  p_xs: 12,
  p_5xs: 8,
  p_sm: 14,
  p_7xs: 6,
  p_5xl: 24,
  p_base: 16,
  p_11xl: 30,
};
/* border radiuses */
export const Border = {
  br_81xl: 100,
  br_xl: 20,
  br_5xs: 8,
  br_7xs: 6,
};

import * as React from "react";
import { StyleSheet, View, Text, Pressable } from "react-native";
import { Image } from "expo-image";
import { StackNavigationProp } from "@react-navigation/stack";
import { useNavigation, ParamListBase } from "@react-navigation/native";
import { FontFamily, FontSize, Color, Padding, Border } from "../GlobalStyles";

const NpTin = () => {
  const navigation = useNavigation<StackNavigationProp<ParamListBase>>();

  return (
    <View style={[styles.npTin, styles.npTinFlexBox]}>
      <View style={styles.homeIndicator}>
        <View style={styles.homeIndicator1} />
      </View>
      <View style={styles.statusBarIphoneXOrNewe}>
        <Image
          style={[styles.notchIcon, styles.iconPosition]}
          contentFit="cover"
          source={require("../assets/notch.png")}
        />
        <View style={styles.rightSide}>
          <Image
            style={styles.batteryIcon}
            contentFit="cover"
            source={require("../assets/battery.png")}
          />
          <Image
            style={styles.wifiIcon}
            contentFit="cover"
            source={require("../assets/wifi1.png")}
          />
          <Image
            style={styles.mobileSignalIcon}
            contentFit="cover"
            source={require("../assets/mobile-signal.png")}
          />
          <Image
            style={[styles.recordingIndicatorIcon, styles.iconPosition]}
            contentFit="cover"
            source={require("../assets/recording-indicator.png")}
          />
        </View>
        <Image
          style={styles.leftSideIcon}
          contentFit="cover"
          source={require("../assets/left-side.png")}
        />
      </View>
      <Text style={[styles.tiKhonHin, styles.npTin1Typo]}>{`Tài khoản hiện tại:
100,000 VND`}</Text>
      <Text style={[styles.nhpSTin, styles.nhpTypo]}>
        Nhập số tiền cần nạp:
      </Text>
      <Text style={[styles.nhpMtKhu, styles.nhpTypo]}>Nhập mật khẩu:</Text>
      <View style={[styles.inputField, styles.inputLayout]}>
        <Text style={[styles.label, styles.npTinFlexBox]} numberOfLines={1}>
          Boi so cua 1000
        </Text>
      </View>
      <View style={[styles.inputField1, styles.inputLayout]}>
        <Text style={[styles.label, styles.npTinFlexBox]} numberOfLines={1}>
          Password
        </Text>
      </View>
      <Pressable
        style={styles.buttonPrimary}
        onPress={() => navigation.navigate("Frame2")}
      >
        <Text style={styles.honThnh}>Hoàn thành</Text>
      </Pressable>
      <View style={styles.header}>
        <Pressable
          style={[styles.iconchevronLeft, styles.npTin1Position]}
          onPress={() => navigation.navigate("DanhMucSinhVien")}
        >
          <Image
            style={styles.icon}
            contentFit="cover"
            source={require("../assets/iconchevron-left.png")}
          />
        </Pressable>
        <Text style={[styles.npTin1, styles.npTin1Position]}>Nạp tiền</Text>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  npTinFlexBox: {
    flex: 1,
    overflow: "hidden",
  },
  iconPosition: {
    display: "none",
    position: "absolute",
  },
  npTin1Typo: {
    textAlign: "center",
    fontFamily: FontFamily.interSemiBold,
    fontWeight: "600",
    lineHeight: 34,
    letterSpacing: -0.5,
    fontSize: FontSize.size_5xl,
  },
  nhpTypo: {
    height: 42,
    textAlign: "center",
    color: Color.colorRed,
    fontFamily: FontFamily.interSemiBold,
    fontWeight: "600",
    lineHeight: 34,
    letterSpacing: -0.5,
    fontSize: FontSize.size_5xl,
    position: "absolute",
  },
  inputLayout: {
    paddingVertical: Padding.p_5xs,
    paddingHorizontal: Padding.p_base,
    height: 40,
    width: 327,
    borderWidth: 1,
    borderColor: Color.colorGainsboro_200,
    left: 24,
    alignItems: "center",
    flexDirection: "row",
    borderStyle: "solid",
    borderRadius: Border.br_5xs,
    position: "absolute",
    backgroundColor: Color.colorWhite,
  },
  npTin1Position: {
    top: "50%",
    position: "absolute",
  },
  homeIndicator1: {
    marginLeft: -66.5,
    bottom: 8,
    borderRadius: Border.br_81xl,
    backgroundColor: Color.colorBlack,
    width: 134,
    height: 5,
    left: "50%",
    position: "absolute",
  },
  homeIndicator: {
    marginLeft: -187.5,
    bottom: 0,
    height: 34,
    width: 375,
    left: "50%",
    position: "absolute",
  },
  notchIcon: {
    top: -2,
    right: 78,
    bottom: 16,
    left: 78,
    maxWidth: "100%",
    maxHeight: "100%",
    overflow: "hidden",
  },
  batteryIcon: {
    right: 0,
    width: 24,
    height: 11,
    top: 0,
    position: "absolute",
  },
  wifiIcon: {
    width: 15,
    height: 11,
  },
  mobileSignalIcon: {
    width: 17,
    height: 11,
  },
  recordingIndicatorIcon: {
    top: -9,
    right: 56,
    width: 6,
    height: 6,
  },
  rightSide: {
    top: 17,
    right: 15,
    width: 67,
    height: 11,
    position: "absolute",
  },
  leftSideIcon: {
    top: 12,
    left: 21,
    width: 54,
    height: 21,
    position: "absolute",
  },
  statusBarIphoneXOrNewe: {
    height: 44,
    left: 0,
    top: 0,
    width: 375,
    position: "absolute",
    overflow: "hidden",
  },
  tiKhonHin: {
    top: 128,
    left: 43,
    width: 289,
    height: 59,
    color: Color.colorRed,
    textAlign: "center",
    fontFamily: FontFamily.interSemiBold,
    fontWeight: "600",
    lineHeight: 34,
    letterSpacing: -0.5,
    position: "absolute",
  },
  nhpSTin: {
    top: 320,
    left: 47,
    width: 282,
  },
  nhpMtKhu: {
    top: 432,
    left: 93,
    width: 190,
  },
  label: {
    fontSize: FontSize.size_sm,
    lineHeight: 20,
    fontFamily: FontFamily.presetsBody2,
    color: Color.colorGray,
    textAlign: "left",
    overflow: "hidden",
  },
  inputField: {
    top: 366,
  },
  inputField1: {
    top: 478,
  },
  honThnh: {
    lineHeight: 36,
    fontWeight: "500",
    fontFamily: FontFamily.smallText,
    color: Color.colorWhite,
    textAlign: "left",
    fontSize: FontSize.size_5xl,
  },
  buttonPrimary: {
    top: 659,
    left: 94,
    backgroundColor: Color.colorSalmon,
    shadowColor: "rgba(0, 0, 0, 0.05)",
    shadowOffset: {
      width: 0,
      height: 1,
    },
    shadowRadius: 2,
    elevation: 2,
    shadowOpacity: 1,
    width: 188,
    justifyContent: "center",
    paddingHorizontal: Padding.p_5xl,
    paddingVertical: Padding.p_sm,
    alignItems: "center",
    flexDirection: "row",
    borderRadius: Border.br_5xs,
    position: "absolute",
  },
  icon: {
    height: "100%",
    marginTop: -12,
    width: "100%",
  },
  iconchevronLeft: {
    left: 16,
    height: 24,
    width: 24,
  },
  npTin1: {
    marginLeft: -57.5,
    color: Color.colorTomato_100,
    marginTop: -12,
    textAlign: "center",
    fontFamily: FontFamily.interSemiBold,
    fontWeight: "600",
    lineHeight: 34,
    letterSpacing: -0.5,
    fontSize: FontSize.size_5xl,
    top: "50%",
    left: "50%",
  },
  header: {
    top: 44,
    borderColor: Color.colorGainsboro_100,
    borderBottomWidth: 0.5,
    borderStyle: "solid",
    height: 42,
    left: 0,
    width: 375,
    position: "absolute",
    overflow: "hidden",
    backgroundColor: Color.colorWhite,
  },
  npTin: {
    height: 812,
    overflow: "hidden",
    width: "100%",
    backgroundColor: Color.colorWhite,
    flex: 1,
  },
});

export default NpTin;

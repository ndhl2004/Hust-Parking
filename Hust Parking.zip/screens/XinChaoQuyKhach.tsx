import * as React from "react";
import { StyleSheet, View, Text, Pressable } from "react-native";
import { Image } from "expo-image";
import { StackNavigationProp } from "@react-navigation/stack";
import { useNavigation, ParamListBase } from "@react-navigation/native";
import { Padding, Color, Border, FontFamily, FontSize } from "../GlobalStyles";

const XinChaoQuyKhach = () => {
  const navigation = useNavigation<StackNavigationProp<ParamListBase>>();

  return (
    <View style={styles.xinChaoQuyKhach}>
      <View style={[styles.homeIndicator, styles.homePosition]}>
        <View style={[styles.homeIndicator1, styles.homePosition]} />
      </View>
      <View style={styles.content}>
        <Pressable
          style={styles.inputAndButton}
          onPress={() => navigation.navigate("SignInSinhVien")}
        >
          <View style={[styles.button, styles.buttonFlexBox]}>
            <Text style={styles.sinhVin}>Sinh viên</Text>
          </View>
        </Pressable>
        <Pressable
          style={styles.inputAndButton1}
          onPress={() => navigation.navigate("SignInQuanLy")}
        >
          <View style={[styles.button1, styles.buttonFlexBox]}>
            <Text style={styles.sinhVin}>Quản lý</Text>
          </View>
        </Pressable>
      </View>
      <Text style={[styles.hustParking, styles.homePosition]}>
        Hust Parking
      </Text>
      <View style={[styles.statusBarIphoneXOrNewe, styles.batteryIconPosition]}>
        <Image
          style={[styles.notchIcon, styles.iconPosition]}
          contentFit="cover"
          source={require("../assets/notch.png")}
        />
        <View style={styles.rightSide}>
          <Image
            style={[styles.batteryIcon, styles.batteryIconPosition]}
            contentFit="cover"
            source={require("../assets/battery.png")}
          />
          <Image
            style={styles.wifiIcon}
            contentFit="cover"
            source={require("../assets/wifi4.png")}
          />
          <Image
            style={styles.mobileSignalIcon}
            contentFit="cover"
            source={require("../assets/mobile-signal.png")}
          />
          <Image
            style={[styles.recordingIndicatorIcon, styles.iconPosition]}
            contentFit="cover"
            source={require("../assets/recording-indicator.png")}
          />
        </View>
        <Image
          style={styles.leftSideIcon}
          contentFit="cover"
          source={require("../assets/left-side2.png")}
        />
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  homePosition: {
    left: "50%",
    position: "absolute",
  },
  buttonFlexBox: {
    paddingHorizontal: Padding.p_base,
    justifyContent: "center",
    flexDirection: "row",
    backgroundColor: Color.colorSalmon,
    borderRadius: Border.br_5xs,
    alignSelf: "stretch",
    paddingVertical: 0,
    alignItems: "center",
  },
  batteryIconPosition: {
    top: 0,
    position: "absolute",
  },
  iconPosition: {
    display: "none",
    position: "absolute",
  },
  homeIndicator1: {
    marginLeft: -66.5,
    bottom: 8,
    borderRadius: Border.br_81xl,
    backgroundColor: Color.colorBlack,
    width: 134,
    height: 5,
  },
  homeIndicator: {
    bottom: 0,
    height: 34,
    width: 375,
    marginLeft: -187.5,
    left: "50%",
  },
  sinhVin: {
    lineHeight: 34,
    fontWeight: "500",
    fontFamily: FontFamily.smallText,
    color: Color.colorWhite,
    textAlign: "left",
    fontSize: FontSize.size_5xl,
  },
  button: {
    height: 69,
  },
  inputAndButton: {
    height: 69,
    width: 327,
  },
  button1: {
    height: 72,
  },
  inputAndButton1: {
    marginTop: 24,
    width: 327,
  },
  content: {
    marginTop: -7,
    top: "50%",
    height: 220,
    paddingHorizontal: Padding.p_5xl,
    paddingVertical: 0,
    alignItems: "center",
    left: "50%",
    marginLeft: -187.5,
    position: "absolute",
  },
  hustParking: {
    marginLeft: -73.5,
    top: 251,
    letterSpacing: -0.2,
    lineHeight: 36,
    fontWeight: "600",
    fontFamily: FontFamily.interSemiBold,
    color: Color.colorRed,
    textAlign: "center",
    fontSize: FontSize.size_5xl,
  },
  notchIcon: {
    top: -2,
    right: 78,
    bottom: 16,
    left: 78,
    maxWidth: "100%",
    maxHeight: "100%",
    overflow: "hidden",
  },
  batteryIcon: {
    right: 0,
    width: 24,
    height: 11,
  },
  wifiIcon: {
    width: 15,
    height: 11,
  },
  mobileSignalIcon: {
    width: 17,
    height: 11,
  },
  recordingIndicatorIcon: {
    top: -9,
    right: 56,
    width: 6,
    height: 6,
  },
  rightSide: {
    top: 17,
    right: 15,
    width: 67,
    height: 11,
    position: "absolute",
  },
  leftSideIcon: {
    top: 12,
    left: 21,
    width: 54,
    height: 21,
    position: "absolute",
  },
  statusBarIphoneXOrNewe: {
    left: 0,
    height: 44,
    width: 375,
    overflow: "hidden",
  },
  xinChaoQuyKhach: {
    backgroundColor: Color.colorWhite,
    flex: 1,
    width: "100%",
    height: 812,
    overflow: "hidden",
  },
});

export default XinChaoQuyKhach;

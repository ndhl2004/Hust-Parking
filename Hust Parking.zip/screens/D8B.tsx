import * as React from "react";
import { StyleSheet, View, Pressable, Text } from "react-native";
import { Image } from "expo-image";
import { StackNavigationProp } from "@react-navigation/stack";
import { useNavigation, ParamListBase } from "@react-navigation/native";
import { Color, FontFamily, FontSize, Border } from "../GlobalStyles";

const D8B = () => {
  const navigation = useNavigation<StackNavigationProp<ParamListBase>>();

  return (
    <Pressable
      style={styles.d8B3}
      onPress={() => navigation.navigate("Frame13")}
    >
      <View style={styles.homeIndicator}>
        <View style={styles.homeIndicator1} />
      </View>
      <View style={styles.header}>
        <Pressable
          style={styles.iconchevronLeft}
          onPress={() => navigation.navigate("GroupInstance3")}
        >
          <Image
            style={styles.icon}
            contentFit="cover"
            source={require("../assets/iconchevron-left1.png")}
          />
        </Pressable>
        <Text style={styles.d8}>D8</Text>
      </View>
      <View style={styles.statusBarIphoneXOrNewe}>
        <Image
          style={[styles.notchIcon, styles.iconPosition]}
          contentFit="cover"
          source={require("../assets/notch.png")}
        />
        <View style={styles.rightSide}>
          <Image
            style={styles.batteryIcon}
            contentFit="cover"
            source={require("../assets/battery.png")}
          />
          <Image
            style={styles.wifiIcon}
            contentFit="cover"
            source={require("../assets/wifi6.png")}
          />
          <Image
            style={styles.mobileSignalIcon}
            contentFit="cover"
            source={require("../assets/mobile-signal.png")}
          />
          <Image
            style={[styles.recordingIndicatorIcon, styles.iconPosition]}
            contentFit="cover"
            source={require("../assets/recording-indicator.png")}
          />
        </View>
        <Image
          style={styles.leftSideIcon}
          contentFit="cover"
          source={require("../assets/left-side.png")}
        />
      </View>
      <Text style={[styles.xinHyDi, styles.xinHyDiTypo]}>
        Xin hãy di chuyển vào nhà xe...
      </Text>
      <Text style={[styles.nhnDinKhun, styles.xinHyDiTypo]}>
        Nhận diện khuôn mặt thành công...
      </Text>
      <Text style={[styles.qutBinS, styles.xinHyDiTypo]}>
        Quét biển số xe thành công...
      </Text>
      <Image
        style={styles.checkMark400px1Icon}
        contentFit="cover"
        source={require("../assets/372103860-check-mark-400px-1.png")}
      />
    </Pressable>
  );
};

const styles = StyleSheet.create({
  iconPosition: {
    display: "none",
    position: "absolute",
  },
  xinHyDiTypo: {
    width: 294,
    height: 44,
    textAlign: "center",
    color: Color.colorCrimson,
    fontFamily: FontFamily.interSemiBold,
    fontWeight: "600",
    lineHeight: 34,
    letterSpacing: -0.5,
    fontSize: FontSize.size_5xl,
    position: "absolute",
  },
  homeIndicator1: {
    marginLeft: -66.5,
    bottom: 8,
    borderRadius: Border.br_81xl,
    backgroundColor: Color.colorBlack,
    width: 134,
    height: 5,
    left: "50%",
    position: "absolute",
  },
  homeIndicator: {
    marginLeft: -187.5,
    bottom: 0,
    height: 34,
    width: 375,
    left: "50%",
    position: "absolute",
  },
  icon: {
    height: "100%",
    marginTop: -12,
    width: "100%",
  },
  iconchevronLeft: {
    left: 16,
    height: 24,
    width: 24,
    top: "50%",
    position: "absolute",
  },
  d8: {
    marginLeft: -26.5,
    textAlign: "center",
    color: Color.colorCrimson,
    fontFamily: FontFamily.interSemiBold,
    fontWeight: "600",
    lineHeight: 34,
    letterSpacing: -0.5,
    fontSize: FontSize.size_5xl,
    marginTop: -12,
    top: "50%",
    left: "50%",
    position: "absolute",
  },
  header: {
    top: 44,
    borderStyle: "solid",
    borderColor: Color.colorGainsboro_100,
    borderBottomWidth: 0.5,
    height: 42,
    left: 0,
    width: 375,
    position: "absolute",
    overflow: "hidden",
    backgroundColor: Color.colorWhite,
  },
  notchIcon: {
    top: -2,
    right: 78,
    bottom: 16,
    left: 78,
    maxWidth: "100%",
    maxHeight: "100%",
    overflow: "hidden",
  },
  batteryIcon: {
    right: 0,
    height: 11,
    top: 0,
    width: 24,
    position: "absolute",
  },
  wifiIcon: {
    width: 15,
    height: 11,
  },
  mobileSignalIcon: {
    width: 17,
    height: 11,
  },
  recordingIndicatorIcon: {
    top: -9,
    right: 56,
    width: 6,
    height: 6,
  },
  rightSide: {
    top: 17,
    right: 15,
    width: 67,
    height: 11,
    position: "absolute",
  },
  leftSideIcon: {
    top: 12,
    left: 21,
    width: 54,
    height: 21,
    position: "absolute",
  },
  statusBarIphoneXOrNewe: {
    height: 44,
    top: 0,
    left: 0,
    width: 375,
    position: "absolute",
    overflow: "hidden",
  },
  xinHyDi: {
    top: 173,
    left: 37,
  },
  nhnDinKhun: {
    top: 477,
    left: 32,
  },
  qutBinS: {
    top: 608,
    left: 34,
  },
  checkMark400px1Icon: {
    top: 334,
    left: 128,
    width: 111,
    height: 111,
    position: "absolute",
  },
  d8B3: {
    flex: 1,
    height: 812,
    overflow: "hidden",
    width: "100%",
    backgroundColor: Color.colorWhite,
  },
});

export default D8B;

import * as React from "react";
import { StyleSheet, View, Text } from "react-native";
import { Image } from "expo-image";
import { StackNavigationProp } from "@react-navigation/stack";
import { useNavigation, ParamListBase } from "@react-navigation/native";
import Header2 from "../components/Header2";
import { Border, FontSize, Color, FontFamily, Padding } from "../GlobalStyles";

const Frame6 = () => {
  const navigation = useNavigation<StackNavigationProp<ParamListBase>>();

  return (
    <View style={[styles.view, styles.viewFlexBox]}>
      <View style={styles.homeIndicator}>
        <View style={styles.homeIndicator1} />
      </View>
      <View style={[styles.iconfilter, styles.searchLayout]}>
        <View style={styles.container} />
        <Image
          style={[styles.filterIcon, styles.iconLayout]}
          contentFit="cover"
          source={require("../assets/filter.png")}
        />
      </View>
      <View style={[styles.search, styles.searchBorder]}>
        <Image
          style={styles.iconLayout}
          contentFit="cover"
          source={require("../assets/search.png")}
        />
        <Text style={[styles.label, styles.labelTypo]} numberOfLines={1}>
          Search
        </Text>
      </View>
      <View style={styles.statusBarIphoneXOrNewe}>
        <Image
          style={[styles.notchIcon, styles.iconPosition]}
          contentFit="cover"
          source={require("../assets/notch.png")}
        />
        <View style={styles.rightSide}>
          <Image
            style={styles.batteryIcon}
            contentFit="cover"
            source={require("../assets/battery.png")}
          />
          <Image
            style={styles.wifiIcon}
            contentFit="cover"
            source={require("../assets/wifi6.png")}
          />
          <Image
            style={styles.mobileSignalIcon}
            contentFit="cover"
            source={require("../assets/mobile-signal.png")}
          />
          <Image
            style={[styles.recordingIndicatorIcon, styles.iconPosition]}
            contentFit="cover"
            source={require("../assets/recording-indicator.png")}
          />
        </View>
        <Image
          style={styles.leftSideIcon}
          contentFit="cover"
          source={require("../assets/left-side.png")}
        />
      </View>
      <Header2 onHomePress={() => navigation.navigate("DanhMucQuanLy")} />
      <View style={[styles.buttonPrimary, styles.searchBorder]}>
        <Text style={[styles.nguynTinKhi, styles.labelTypo]}>{`Nguyễn Tiến Khải
Số điện thoại: 0769485944
MSSV: 20226810
Số dư:  -5,000 VND
Biển số xe: 29C1-888.88`}</Text>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  viewFlexBox: {
    flex: 1,
    overflow: "hidden",
  },
  searchLayout: {
    height: 40,
    top: 104,
  },
  iconLayout: {
    height: 24,
    width: 24,
    overflow: "hidden",
  },
  searchBorder: {
    flexDirection: "row",
    borderStyle: "solid",
    borderRadius: Border.br_5xs,
    position: "absolute",
  },
  labelTypo: {
    textAlign: "left",
    fontSize: FontSize.presetsBody2_size,
  },
  iconPosition: {
    display: "none",
    position: "absolute",
  },
  homeIndicator1: {
    marginLeft: -66.5,
    bottom: 8,
    borderRadius: Border.br_81xl,
    backgroundColor: Color.colorBlack,
    width: 134,
    height: 5,
    left: "50%",
    position: "absolute",
  },
  homeIndicator: {
    marginLeft: -187.5,
    bottom: 0,
    height: 34,
    width: 375,
    left: "50%",
    position: "absolute",
  },
  container: {
    backgroundColor: Color.colorWhitesmoke_100,
    borderRadius: Border.br_5xs,
    left: 0,
    top: 0,
    height: 40,
    width: 40,
    position: "absolute",
  },
  filterIcon: {
    top: 8,
    left: 8,
    position: "absolute",
  },
  iconfilter: {
    left: 319,
    width: 40,
    height: 40,
    top: 104,
    position: "absolute",
  },
  label: {
    lineHeight: 24,
    fontFamily: FontFamily.presetsBody2,
    color: Color.colorGray,
    marginLeft: 12,
    overflow: "hidden",
    flex: 1,
  },
  search: {
    left: 16,
    borderColor: Color.colorGainsboro_200,
    borderWidth: 1,
    width: 295,
    alignItems: "center",
    paddingLeft: Padding.p_xs,
    paddingTop: Padding.p_5xs,
    paddingRight: Padding.p_base,
    paddingBottom: Padding.p_5xs,
    height: 40,
    top: 104,
    flexDirection: "row",
    borderStyle: "solid",
    backgroundColor: Color.colorWhite,
  },
  notchIcon: {
    top: -2,
    right: 78,
    bottom: 16,
    left: 78,
    maxWidth: "100%",
    maxHeight: "100%",
    overflow: "hidden",
  },
  batteryIcon: {
    right: 0,
    height: 11,
    width: 24,
    top: 0,
    position: "absolute",
  },
  wifiIcon: {
    width: 15,
    height: 11,
  },
  mobileSignalIcon: {
    width: 17,
    height: 11,
  },
  recordingIndicatorIcon: {
    top: -9,
    right: 56,
    width: 6,
    height: 6,
  },
  rightSide: {
    top: 17,
    right: 15,
    width: 67,
    height: 11,
    position: "absolute",
  },
  leftSideIcon: {
    top: 12,
    left: 21,
    width: 54,
    height: 21,
    position: "absolute",
  },
  statusBarIphoneXOrNewe: {
    height: 44,
    left: 0,
    top: 0,
    width: 375,
    position: "absolute",
    overflow: "hidden",
  },
  nguynTinKhi: {
    lineHeight: 24,
    fontWeight: "500",
    fontFamily: FontFamily.smallText,
    color: Color.colorRed,
    width: 310,
    height: 149,
  },
  buttonPrimary: {
    top: 174,
    left: 13,
    backgroundColor: Color.colorWhitesmoke_200,
    borderColor: Color.colorSalmon,
    borderWidth: 3,
    width: 350,
    height: 151,
    justifyContent: "center",
    paddingHorizontal: Padding.p_5xl,
    paddingVertical: Padding.p_sm,
    shadowOpacity: 1,
    elevation: 4,
    shadowRadius: 4,
    shadowOffset: {
      width: 0,
      height: 4,
    },
    shadowColor: "rgba(0, 0, 0, 0.25)",
  },
  view: {
    width: "100%",
    height: 812,
    overflow: "hidden",
    shadowOpacity: 1,
    elevation: 4,
    shadowRadius: 4,
    shadowOffset: {
      width: 0,
      height: 4,
    },
    shadowColor: "rgba(0, 0, 0, 0.25)",
    backgroundColor: Color.colorWhite,
    flex: 1,
  },
});

export default Frame6;

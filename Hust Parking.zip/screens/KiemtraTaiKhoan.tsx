import * as React from "react";
import { Text, StyleSheet, View, Pressable } from "react-native";
import { Image } from "expo-image";
import { StackNavigationProp } from "@react-navigation/stack";
import { useNavigation, ParamListBase } from "@react-navigation/native";
import Header1 from "../components/Header1";
import { Padding, Border, Color, FontFamily, FontSize } from "../GlobalStyles";

const KiemtraTaiKhoan = () => {
  const navigation = useNavigation<StackNavigationProp<ParamListBase>>();

  return (
    <View style={[styles.kiemtraTaiKhoan, styles.labelFlexBox]}>
      <Pressable
        style={[styles.buttonPrimary, styles.buttonShadowBox15]}
        onPress={() => navigation.navigate("Frame8")}
      >
        <Text style={[styles.text, styles.textTypo]}>20224424</Text>
      </Pressable>
      <View style={[styles.buttonPrimary1, styles.buttonShadowBox15]}>
        <Text style={[styles.text1, styles.textTypo]}>20204937</Text>
      </View>
      <View style={[styles.buttonPrimary2, styles.buttonShadowBox15]}>
        <Text style={[styles.text1, styles.textTypo]}>20224344</Text>
      </View>
      <View style={[styles.buttonPrimary3, styles.buttonShadowBox15]}>
        <Text style={[styles.text1, styles.textTypo]}>20225545</Text>
      </View>
      <Pressable
        style={[styles.buttonPrimary4, styles.buttonShadowBox15]}
        onPress={() => navigation.navigate("Frame9")}
      >
        <Text style={[styles.text, styles.textTypo]}>20225148</Text>
      </Pressable>
      <View style={[styles.buttonPrimary5, styles.buttonShadowBox14]}>
        <Text style={[styles.text1, styles.textTypo]}>20194534</Text>
      </View>
      <View style={[styles.buttonPrimary6, styles.buttonShadowBox14]}>
        <Text style={[styles.text1, styles.textTypo]}>20224524</Text>
      </View>
      <View style={[styles.buttonPrimary7, styles.buttonShadowBox14]}>
        <Text style={[styles.text1, styles.textTypo]}>20212344</Text>
      </View>
      <View style={[styles.buttonPrimary8, styles.buttonShadowBox14]}>
        <Text style={[styles.text1, styles.textTypo]}>20238324</Text>
      </View>
      <View style={[styles.buttonPrimary9, styles.buttonShadowBox14]}>
        <Text style={[styles.text1, styles.textTypo]}>20227851</Text>
      </View>
      <View style={[styles.buttonPrimary10, styles.buttonShadowBox15]}>
        <Text style={[styles.text1, styles.textTypo]}>20223424</Text>
      </View>
      <View style={[styles.buttonPrimary11, styles.buttonShadowBox15]}>
        <Text style={[styles.text1, styles.textTypo]}>20224224</Text>
      </View>
      <View style={[styles.buttonPrimary12, styles.buttonShadowBox15]}>
        <Text style={[styles.text1, styles.textTypo]}>20205464</Text>
      </View>
      <View style={[styles.buttonPrimary13, styles.buttonShadowBox15]}>
        <Text style={[styles.text1, styles.textTypo]}>20204924</Text>
      </View>
      <View style={[styles.buttonPrimary14, styles.buttonShadowBox15]}>
        <Text style={[styles.text1, styles.textTypo]}>20225824</Text>
      </View>
      <View style={[styles.buttonPrimary15, styles.buttonShadowBox15]}>
        <Text style={[styles.text1, styles.textTypo]}>20222333</Text>
      </View>
      <View style={[styles.buttonPrimary16, styles.buttonShadowBox15]}>
        <Text style={[styles.text1, styles.textTypo]}>20184234</Text>
      </View>
      <View style={[styles.buttonPrimary17, styles.buttonShadowBox15]}>
        <Text style={[styles.text1, styles.textTypo]}>20234544</Text>
      </View>
      <View style={[styles.buttonPrimary18, styles.buttonShadowBox15]}>
        <Text style={[styles.text1, styles.textTypo]}>20225434</Text>
      </View>
      <View style={[styles.buttonPrimary19, styles.buttonShadowBox15]}>
        <Text style={[styles.text1, styles.textTypo]}>20234764</Text>
      </View>
      <Pressable
        style={[styles.buttonPrimary20, styles.buttonShadowBox14]}
        onPress={() => navigation.navigate("Frame6")}
      >
        <Text style={[styles.text, styles.textTypo]}>20226810</Text>
      </Pressable>
      <View style={[styles.buttonPrimary21, styles.buttonShadowBox14]}>
        <Text style={[styles.text1, styles.textTypo]}>20183945</Text>
      </View>
      <View style={[styles.buttonPrimary22, styles.buttonShadowBox14]}>
        <Text style={[styles.text1, styles.textTypo]}>20226434</Text>
      </View>
      <View style={[styles.buttonPrimary23, styles.buttonShadowBox14]}>
        <Text style={[styles.text1, styles.textTypo]}>20225745</Text>
      </View>
      <Pressable
        style={[styles.buttonPrimary24, styles.buttonShadowBox14]}
        onPress={() => navigation.navigate("Frame5")}
      >
        <Text style={[styles.text, styles.textTypo]}>20226869</Text>
      </Pressable>
      <View style={[styles.buttonPrimary25, styles.buttonShadowBox14]}>
        <Text style={[styles.text1, styles.textTypo]}>20222193</Text>
      </View>
      <View style={[styles.buttonPrimary26, styles.buttonShadowBox14]}>
        <Text style={[styles.text1, styles.textTypo]}>20224975</Text>
      </View>
      <Pressable
        style={[styles.buttonPrimary27, styles.buttonShadowBox14]}
        onPress={() => navigation.navigate("Frame7")}
      >
        <Text style={[styles.text, styles.textTypo]}>20226813</Text>
      </Pressable>
      <View style={[styles.buttonPrimary28, styles.buttonShadowBox14]}>
        <Text style={[styles.text1, styles.textTypo]}>20224453</Text>
      </View>
      <View style={[styles.buttonPrimary29, styles.buttonShadowBox14]}>
        <Text style={[styles.text1, styles.textTypo]}>20184234</Text>
      </View>
      <View style={[styles.buttonPrimary30, styles.buttonShadowBox14]}>
        <Text style={[styles.text1, styles.textTypo]}>20234544</Text>
      </View>
      <View style={[styles.buttonPrimary31, styles.buttonShadowBox14]}>
        <Text style={[styles.text1, styles.textTypo]}>20225434</Text>
      </View>
      <View style={[styles.buttonPrimary32, styles.buttonShadowBox14]}>
        <Text style={[styles.text1, styles.textTypo]}>20234764</Text>
      </View>
      <View style={[styles.buttonPrimary33, styles.buttonShadowBox13]}>
        <Text style={[styles.text1, styles.textTypo]}>20194534</Text>
      </View>
      <View style={[styles.buttonPrimary34, styles.buttonShadowBox13]}>
        <Text style={[styles.text1, styles.textTypo]}>20224524</Text>
      </View>
      <View style={[styles.buttonPrimary35, styles.buttonShadowBox13]}>
        <Text style={[styles.text1, styles.textTypo]}>20212344</Text>
      </View>
      <View style={[styles.buttonPrimary36, styles.buttonShadowBox13]}>
        <Text style={[styles.text1, styles.textTypo]}>20238324</Text>
      </View>
      <View style={[styles.buttonPrimary37, styles.buttonShadowBox12]}>
        <Text style={[styles.text1, styles.textTypo]}>20223424</Text>
      </View>
      <View style={[styles.buttonPrimary38, styles.buttonShadowBox12]}>
        <Text style={[styles.text1, styles.textTypo]}>20224224</Text>
      </View>
      <View style={[styles.buttonPrimary39, styles.buttonShadowBox12]}>
        <Text style={[styles.text1, styles.textTypo]}>20205464</Text>
      </View>
      <View style={[styles.buttonPrimary40, styles.buttonShadowBox12]}>
        <Text style={[styles.text1, styles.textTypo]}>20204924</Text>
      </View>
      <View style={[styles.buttonPrimary41, styles.buttonShadowBox12]}>
        <Text style={[styles.text1, styles.textTypo]}>20225824</Text>
      </View>
      <View style={[styles.buttonPrimary42, styles.buttonShadowBox12]}>
        <Text style={[styles.text1, styles.textTypo]}>20222333</Text>
      </View>
      <View style={[styles.buttonPrimary43, styles.buttonShadowBox12]}>
        <Text style={[styles.text1, styles.textTypo]}>20184234</Text>
      </View>
      <View style={[styles.buttonPrimary44, styles.buttonShadowBox12]}>
        <Text style={[styles.text1, styles.textTypo]}>20234544</Text>
      </View>
      <View style={[styles.buttonPrimary45, styles.buttonShadowBox12]}>
        <Text style={[styles.text1, styles.textTypo]}>20225434</Text>
      </View>
      <View style={[styles.buttonPrimary46, styles.buttonShadowBox12]}>
        <Text style={[styles.text1, styles.textTypo]}>20234764</Text>
      </View>
      <View style={[styles.buttonPrimary47, styles.buttonShadowBox12]}>
        <Text style={[styles.text1, styles.textTypo]}>20194534</Text>
      </View>
      <View style={[styles.buttonPrimary48, styles.buttonShadowBox12]}>
        <Text style={[styles.text1, styles.textTypo]}>20224524</Text>
      </View>
      <View style={[styles.buttonPrimary49, styles.buttonShadowBox12]}>
        <Text style={[styles.text1, styles.textTypo]}>20212344</Text>
      </View>
      <View style={[styles.buttonPrimary50, styles.buttonShadowBox12]}>
        <Text style={[styles.text1, styles.textTypo]}>20238324</Text>
      </View>
      <View style={[styles.buttonPrimary51, styles.buttonShadowBox11]}>
        <Text style={[styles.text1, styles.textTypo]}>20223424</Text>
      </View>
      <View style={[styles.buttonPrimary52, styles.buttonShadowBox11]}>
        <Text style={[styles.text1, styles.textTypo]}>20224224</Text>
      </View>
      <View style={[styles.buttonPrimary53, styles.buttonShadowBox11]}>
        <Text style={[styles.text1, styles.textTypo]}>20205464</Text>
      </View>
      <View style={[styles.buttonPrimary54, styles.buttonShadowBox11]}>
        <Text style={[styles.text1, styles.textTypo]}>20204924</Text>
      </View>
      <View style={[styles.buttonPrimary55, styles.buttonShadowBox11]}>
        <Text style={[styles.text1, styles.textTypo]}>20225824</Text>
      </View>
      <View style={[styles.buttonPrimary56, styles.buttonShadowBox11]}>
        <Text style={[styles.text1, styles.textTypo]}>20225434</Text>
      </View>
      <View style={[styles.buttonPrimary57, styles.buttonShadowBox11]}>
        <Text style={[styles.text1, styles.textTypo]}>20234764</Text>
      </View>
      <View style={styles.buttonShadowBox10}>
        <Text style={[styles.text1, styles.textTypo]}>20223424</Text>
      </View>
      <View style={styles.buttonShadowBox9}>
        <Text style={[styles.text1, styles.textTypo]}>20224224</Text>
      </View>
      <View style={styles.buttonShadowBox8}>
        <Text style={[styles.text1, styles.textTypo]}>20205464</Text>
      </View>
      <View style={styles.buttonShadowBox7}>
        <Text style={[styles.text1, styles.textTypo]}>20234544</Text>
      </View>
      <View style={styles.buttonShadowBox6}>
        <Text style={[styles.text1, styles.textTypo]}>20225434</Text>
      </View>
      <View style={styles.buttonShadowBox5}>
        <Text style={[styles.text1, styles.textTypo]}>20234764</Text>
      </View>
      <View style={styles.buttonShadowBox10}>
        <Text style={[styles.text1, styles.textTypo]}>20223424</Text>
      </View>
      <View style={styles.buttonShadowBox9}>
        <Text style={[styles.text1, styles.textTypo]}>20224224</Text>
      </View>
      <View style={styles.buttonShadowBox8}>
        <Text style={[styles.text1, styles.textTypo]}>20205464</Text>
      </View>
      <View style={styles.buttonShadowBox7}>
        <Text style={[styles.text1, styles.textTypo]}>20234544</Text>
      </View>
      <View style={styles.buttonShadowBox6}>
        <Text style={[styles.text1, styles.textTypo]}>20225434</Text>
      </View>
      <View style={styles.buttonShadowBox5}>
        <Text style={[styles.text1, styles.textTypo]}>20234764</Text>
      </View>
      <View style={styles.buttonShadowBox4}>
        <Text style={[styles.text1, styles.textTypo]}>20223424</Text>
      </View>
      <View style={styles.buttonShadowBox3}>
        <Text style={[styles.text1, styles.textTypo]}>20224224</Text>
      </View>
      <View style={styles.buttonShadowBox2}>
        <Text style={[styles.text1, styles.textTypo]}>20205464</Text>
      </View>
      <View style={styles.buttonShadowBox1}>
        <Text style={[styles.text1, styles.textTypo]}>20204924</Text>
      </View>
      <View style={styles.buttonShadowBox}>
        <Text style={[styles.text1, styles.textTypo]}>20234764</Text>
      </View>
      <View style={styles.buttonShadowBox4}>
        <Text style={[styles.text1, styles.textTypo]}>20223424</Text>
      </View>
      <View style={styles.buttonShadowBox3}>
        <Text style={[styles.text1, styles.textTypo]}>20224224</Text>
      </View>
      <View style={styles.buttonShadowBox2}>
        <Text style={[styles.text1, styles.textTypo]}>20205464</Text>
      </View>
      <View style={styles.buttonShadowBox1}>
        <Text style={[styles.text1, styles.textTypo]}>20204924</Text>
      </View>
      <View style={styles.buttonShadowBox}>
        <Text style={[styles.text1, styles.textTypo]}>20234764</Text>
      </View>
      <View style={[styles.homeIndicator, styles.homeIndicatorLayout]}>
        <View style={styles.homeIndicator1} />
      </View>
      <View style={[styles.kiemtraTaiKhoanChild, styles.containerPosition]} />
      <View style={[styles.iconfilter, styles.searchLayout]}>
        <View style={[styles.container, styles.searchLayout]} />
        <Image
          style={[styles.filterIcon, styles.iconLayout]}
          contentFit="cover"
          source={require("../assets/filter.png")}
        />
      </View>
      <View style={[styles.search, styles.searchLayout]}>
        <Image
          style={styles.iconLayout}
          contentFit="cover"
          source={require("../assets/search.png")}
        />
        <Text style={[styles.label, styles.labelFlexBox]} numberOfLines={1}>
          Search
        </Text>
      </View>
      <View style={[styles.statusBarIphoneXOrNewe, styles.containerPosition]}>
        <Image
          style={[styles.notchIcon, styles.iconPosition]}
          contentFit="cover"
          source={require("../assets/notch.png")}
        />
        <View style={styles.rightSide}>
          <Image
            style={styles.batteryIcon}
            contentFit="cover"
            source={require("../assets/battery.png")}
          />
          <Image
            style={styles.wifiIcon}
            contentFit="cover"
            source={require("../assets/wifi1.png")}
          />
          <Image
            style={styles.mobileSignalIcon}
            contentFit="cover"
            source={require("../assets/mobile-signal.png")}
          />
          <Image
            style={[styles.recordingIndicatorIcon, styles.iconPosition]}
            contentFit="cover"
            source={require("../assets/recording-indicator.png")}
          />
        </View>
        <Image
          style={styles.leftSideIcon}
          contentFit="cover"
          source={require("../assets/left-side1.png")}
        />
      </View>
      <Header1 onTabBarItemPress={() => navigation.navigate("DanhMucQuanLy")} />
    </View>
  );
};

const styles = StyleSheet.create({
  labelFlexBox: {
    flex: 1,
    overflow: "hidden",
  },
  buttonShadowBox15: {
    paddingVertical: Padding.p_sm,
    paddingHorizontal: Padding.p_5xl,
    justifyContent: "center",
    height: 53,
    width: 294,
    borderWidth: 3,
    elevation: 2,
    shadowRadius: 2,
    shadowColor: "rgba(0, 0, 0, 0.05)",
    left: 39,
    alignItems: "center",
    flexDirection: "row",
    borderStyle: "solid",
    borderRadius: Border.br_5xs,
    position: "absolute",
    shadowOpacity: 1,
    shadowOffset: {
      width: 0,
      height: 4,
    },
    backgroundColor: Color.colorWhite,
  },
  textTypo: {
    fontFamily: FontFamily.smallText,
    fontWeight: "500",
    lineHeight: 36,
    fontSize: FontSize.size_5xl,
    textAlign: "left",
  },
  buttonShadowBox14: {
    left: 41,
    paddingVertical: Padding.p_sm,
    paddingHorizontal: Padding.p_5xl,
    justifyContent: "center",
    alignItems: "center",
    flexDirection: "row",
    height: 53,
    width: 294,
    borderWidth: 3,
    borderStyle: "solid",
    elevation: 2,
    shadowRadius: 2,
    shadowColor: "rgba(0, 0, 0, 0.05)",
    borderRadius: Border.br_5xs,
    position: "absolute",
    shadowOpacity: 1,
    shadowOffset: {
      width: 0,
      height: 4,
    },
    backgroundColor: Color.colorWhite,
  },
  buttonShadowBox13: {
    left: 42,
    borderColor: Color.colorLightseagreen,
    paddingVertical: Padding.p_sm,
    paddingHorizontal: Padding.p_5xl,
    justifyContent: "center",
    alignItems: "center",
    flexDirection: "row",
    height: 53,
    width: 294,
    borderWidth: 3,
    borderStyle: "solid",
    elevation: 2,
    shadowRadius: 2,
    shadowColor: "rgba(0, 0, 0, 0.05)",
    borderRadius: Border.br_5xs,
    position: "absolute",
    shadowOpacity: 1,
    shadowOffset: {
      width: 0,
      height: 4,
    },
    backgroundColor: Color.colorWhite,
  },
  buttonShadowBox12: {
    left: 40,
    borderColor: Color.colorLightseagreen,
    paddingVertical: Padding.p_sm,
    paddingHorizontal: Padding.p_5xl,
    justifyContent: "center",
    alignItems: "center",
    flexDirection: "row",
    height: 53,
    width: 294,
    borderWidth: 3,
    borderStyle: "solid",
    elevation: 2,
    shadowRadius: 2,
    shadowColor: "rgba(0, 0, 0, 0.05)",
    borderRadius: Border.br_5xs,
    position: "absolute",
    shadowOpacity: 1,
    shadowOffset: {
      width: 0,
      height: 4,
    },
    backgroundColor: Color.colorWhite,
  },
  buttonShadowBox11: {
    left: 38,
    borderColor: Color.colorLightseagreen,
    paddingVertical: Padding.p_sm,
    paddingHorizontal: Padding.p_5xl,
    justifyContent: "center",
    alignItems: "center",
    flexDirection: "row",
    height: 53,
    width: 294,
    borderWidth: 3,
    borderStyle: "solid",
    elevation: 2,
    shadowRadius: 2,
    shadowColor: "rgba(0, 0, 0, 0.05)",
    borderRadius: Border.br_5xs,
    position: "absolute",
    shadowOpacity: 1,
    shadowOffset: {
      width: 0,
      height: 4,
    },
    backgroundColor: Color.colorWhite,
  },
  homeIndicatorLayout: {
    width: 375,
    position: "absolute",
  },
  containerPosition: {
    top: 0,
    left: 0,
  },
  searchLayout: {
    height: 40,
    position: "absolute",
  },
  iconLayout: {
    height: 24,
    width: 24,
    overflow: "hidden",
  },
  iconPosition: {
    display: "none",
    position: "absolute",
  },
  text: {
    color: Color.colorSalmon,
    textAlign: "left",
  },
  buttonPrimary: {
    top: 176,
    borderColor: Color.colorSalmon,
  },
  text1: {
    color: Color.colorLightseagreen,
    textAlign: "left",
  },
  buttonPrimary1: {
    top: 259,
    borderColor: Color.colorLightseagreen,
  },
  buttonPrimary2: {
    top: 342,
    borderColor: Color.colorLightseagreen,
  },
  buttonPrimary3: {
    top: 425,
    borderColor: Color.colorLightseagreen,
  },
  buttonPrimary4: {
    top: 508,
    borderColor: Color.colorSalmon,
  },
  buttonPrimary5: {
    top: 1420,
    borderColor: Color.colorLightseagreen,
  },
  buttonPrimary6: {
    top: 1503,
    borderColor: Color.colorLightseagreen,
  },
  buttonPrimary7: {
    top: 1586,
    borderColor: Color.colorLightseagreen,
  },
  buttonPrimary8: {
    top: 1669,
    borderColor: Color.colorLightseagreen,
  },
  buttonPrimary9: {
    top: 1752,
    borderColor: Color.colorLightseagreen,
  },
  buttonPrimary10: {
    top: 1005,
    borderColor: Color.colorLightseagreen,
  },
  buttonPrimary11: {
    top: 1088,
    borderColor: Color.colorLightseagreen,
  },
  buttonPrimary12: {
    top: 1171,
    borderColor: Color.colorLightseagreen,
  },
  buttonPrimary13: {
    top: 1254,
    borderColor: Color.colorLightseagreen,
  },
  buttonPrimary14: {
    top: 1337,
    borderColor: Color.colorLightseagreen,
  },
  buttonPrimary15: {
    top: 591,
    borderColor: Color.colorLightseagreen,
  },
  buttonPrimary16: {
    top: 674,
    borderColor: Color.colorLightseagreen,
  },
  buttonPrimary17: {
    top: 757,
    borderColor: Color.colorLightseagreen,
  },
  buttonPrimary18: {
    top: 840,
    borderColor: Color.colorLightseagreen,
  },
  buttonPrimary19: {
    top: 923,
    borderColor: Color.colorLightseagreen,
  },
  buttonPrimary20: {
    top: 1835,
    borderColor: Color.colorSalmon,
  },
  buttonPrimary21: {
    top: 1918,
    borderColor: Color.colorLightseagreen,
  },
  buttonPrimary22: {
    top: 2001,
    borderColor: Color.colorLightseagreen,
  },
  buttonPrimary23: {
    top: 2084,
    borderColor: Color.colorLightseagreen,
  },
  buttonPrimary24: {
    top: 2167,
    borderColor: Color.colorSalmon,
  },
  buttonPrimary25: {
    top: 2250,
    borderColor: Color.colorLightseagreen,
  },
  buttonPrimary26: {
    top: 2665,
    borderColor: Color.colorLightseagreen,
  },
  buttonPrimary27: {
    top: 2748,
    borderColor: Color.colorSalmon,
  },
  buttonPrimary28: {
    top: 2831,
    borderColor: Color.colorLightseagreen,
  },
  buttonPrimary29: {
    top: 2333,
    borderColor: Color.colorLightseagreen,
  },
  buttonPrimary30: {
    top: 2416,
    borderColor: Color.colorLightseagreen,
  },
  buttonPrimary31: {
    top: 2499,
    borderColor: Color.colorLightseagreen,
  },
  buttonPrimary32: {
    top: 2582,
    borderColor: Color.colorLightseagreen,
  },
  buttonPrimary33: {
    top: 3743,
  },
  buttonPrimary34: {
    top: 3826,
  },
  buttonPrimary35: {
    top: 3909,
  },
  buttonPrimary36: {
    top: 3992,
  },
  buttonPrimary37: {
    top: 3328,
  },
  buttonPrimary38: {
    top: 3411,
  },
  buttonPrimary39: {
    top: 3494,
  },
  buttonPrimary40: {
    top: 3577,
  },
  buttonPrimary41: {
    top: 3660,
  },
  buttonPrimary42: {
    top: 2914,
  },
  buttonPrimary43: {
    top: 2997,
  },
  buttonPrimary44: {
    top: 3080,
  },
  buttonPrimary45: {
    top: 3163,
  },
  buttonPrimary46: {
    top: 3246,
  },
  buttonPrimary47: {
    top: 4655,
  },
  buttonPrimary48: {
    top: 4738,
  },
  buttonPrimary49: {
    top: 4821,
  },
  buttonPrimary50: {
    top: 4904,
  },
  buttonPrimary51: {
    top: 4240,
  },
  buttonPrimary52: {
    top: 4323,
  },
  buttonPrimary53: {
    top: 4406,
  },
  buttonPrimary54: {
    top: 4489,
  },
  buttonPrimary55: {
    top: 4572,
  },
  buttonPrimary56: {
    top: 4075,
  },
  buttonPrimary57: {
    top: 4158,
  },
  buttonShadowBox10: {
    top: 5235,
    left: 42,
    borderColor: Color.colorLightseagreen,
    paddingVertical: Padding.p_sm,
    paddingHorizontal: Padding.p_5xl,
    justifyContent: "center",
    alignItems: "center",
    flexDirection: "row",
    height: 53,
    width: 294,
    borderWidth: 3,
    borderStyle: "solid",
    elevation: 2,
    shadowRadius: 2,
    shadowColor: "rgba(0, 0, 0, 0.05)",
    borderRadius: Border.br_5xs,
    position: "absolute",
    shadowOpacity: 1,
    shadowOffset: {
      width: 0,
      height: 4,
    },
    backgroundColor: Color.colorWhite,
  },
  buttonShadowBox9: {
    top: 5318,
    left: 42,
    borderColor: Color.colorLightseagreen,
    paddingVertical: Padding.p_sm,
    paddingHorizontal: Padding.p_5xl,
    justifyContent: "center",
    alignItems: "center",
    flexDirection: "row",
    height: 53,
    width: 294,
    borderWidth: 3,
    borderStyle: "solid",
    elevation: 2,
    shadowRadius: 2,
    shadowColor: "rgba(0, 0, 0, 0.05)",
    borderRadius: Border.br_5xs,
    position: "absolute",
    shadowOpacity: 1,
    shadowOffset: {
      width: 0,
      height: 4,
    },
    backgroundColor: Color.colorWhite,
  },
  buttonShadowBox8: {
    top: 5401,
    left: 42,
    borderColor: Color.colorLightseagreen,
    paddingVertical: Padding.p_sm,
    paddingHorizontal: Padding.p_5xl,
    justifyContent: "center",
    alignItems: "center",
    flexDirection: "row",
    height: 53,
    width: 294,
    borderWidth: 3,
    borderStyle: "solid",
    elevation: 2,
    shadowRadius: 2,
    shadowColor: "rgba(0, 0, 0, 0.05)",
    borderRadius: Border.br_5xs,
    position: "absolute",
    shadowOpacity: 1,
    shadowOffset: {
      width: 0,
      height: 4,
    },
    backgroundColor: Color.colorWhite,
  },
  buttonShadowBox7: {
    top: 4987,
    left: 42,
    borderColor: Color.colorLightseagreen,
    paddingVertical: Padding.p_sm,
    paddingHorizontal: Padding.p_5xl,
    justifyContent: "center",
    alignItems: "center",
    flexDirection: "row",
    height: 53,
    width: 294,
    borderWidth: 3,
    borderStyle: "solid",
    elevation: 2,
    shadowRadius: 2,
    shadowColor: "rgba(0, 0, 0, 0.05)",
    borderRadius: Border.br_5xs,
    position: "absolute",
    shadowOpacity: 1,
    shadowOffset: {
      width: 0,
      height: 4,
    },
    backgroundColor: Color.colorWhite,
  },
  buttonShadowBox6: {
    top: 5070,
    left: 42,
    borderColor: Color.colorLightseagreen,
    paddingVertical: Padding.p_sm,
    paddingHorizontal: Padding.p_5xl,
    justifyContent: "center",
    alignItems: "center",
    flexDirection: "row",
    height: 53,
    width: 294,
    borderWidth: 3,
    borderStyle: "solid",
    elevation: 2,
    shadowRadius: 2,
    shadowColor: "rgba(0, 0, 0, 0.05)",
    borderRadius: Border.br_5xs,
    position: "absolute",
    shadowOpacity: 1,
    shadowOffset: {
      width: 0,
      height: 4,
    },
    backgroundColor: Color.colorWhite,
  },
  buttonShadowBox5: {
    top: 5153,
    left: 42,
    borderColor: Color.colorLightseagreen,
    paddingVertical: Padding.p_sm,
    paddingHorizontal: Padding.p_5xl,
    justifyContent: "center",
    alignItems: "center",
    flexDirection: "row",
    height: 53,
    width: 294,
    borderWidth: 3,
    borderStyle: "solid",
    elevation: 2,
    shadowRadius: 2,
    shadowColor: "rgba(0, 0, 0, 0.05)",
    borderRadius: Border.br_5xs,
    position: "absolute",
    shadowOpacity: 1,
    shadowOffset: {
      width: 0,
      height: 4,
    },
    backgroundColor: Color.colorWhite,
  },
  buttonShadowBox4: {
    top: 5562,
    left: 42,
    borderColor: Color.colorLightseagreen,
    paddingVertical: Padding.p_sm,
    paddingHorizontal: Padding.p_5xl,
    justifyContent: "center",
    alignItems: "center",
    flexDirection: "row",
    height: 53,
    width: 294,
    borderWidth: 3,
    borderStyle: "solid",
    elevation: 2,
    shadowRadius: 2,
    shadowColor: "rgba(0, 0, 0, 0.05)",
    borderRadius: Border.br_5xs,
    position: "absolute",
    shadowOpacity: 1,
    shadowOffset: {
      width: 0,
      height: 4,
    },
    backgroundColor: Color.colorWhite,
  },
  buttonShadowBox3: {
    top: 5645,
    left: 42,
    borderColor: Color.colorLightseagreen,
    paddingVertical: Padding.p_sm,
    paddingHorizontal: Padding.p_5xl,
    justifyContent: "center",
    alignItems: "center",
    flexDirection: "row",
    height: 53,
    width: 294,
    borderWidth: 3,
    borderStyle: "solid",
    elevation: 2,
    shadowRadius: 2,
    shadowColor: "rgba(0, 0, 0, 0.05)",
    borderRadius: Border.br_5xs,
    position: "absolute",
    shadowOpacity: 1,
    shadowOffset: {
      width: 0,
      height: 4,
    },
    backgroundColor: Color.colorWhite,
  },
  buttonShadowBox2: {
    top: 5728,
    left: 42,
    borderColor: Color.colorLightseagreen,
    paddingVertical: Padding.p_sm,
    paddingHorizontal: Padding.p_5xl,
    justifyContent: "center",
    alignItems: "center",
    flexDirection: "row",
    height: 53,
    width: 294,
    borderWidth: 3,
    borderStyle: "solid",
    elevation: 2,
    shadowRadius: 2,
    shadowColor: "rgba(0, 0, 0, 0.05)",
    borderRadius: Border.br_5xs,
    position: "absolute",
    shadowOpacity: 1,
    shadowOffset: {
      width: 0,
      height: 4,
    },
    backgroundColor: Color.colorWhite,
  },
  buttonShadowBox1: {
    top: 5811,
    left: 42,
    borderColor: Color.colorLightseagreen,
    paddingVertical: Padding.p_sm,
    paddingHorizontal: Padding.p_5xl,
    justifyContent: "center",
    alignItems: "center",
    flexDirection: "row",
    height: 53,
    width: 294,
    borderWidth: 3,
    borderStyle: "solid",
    elevation: 2,
    shadowRadius: 2,
    shadowColor: "rgba(0, 0, 0, 0.05)",
    borderRadius: Border.br_5xs,
    position: "absolute",
    shadowOpacity: 1,
    shadowOffset: {
      width: 0,
      height: 4,
    },
    backgroundColor: Color.colorWhite,
  },
  buttonShadowBox: {
    top: 5480,
    left: 42,
    borderColor: Color.colorLightseagreen,
    paddingVertical: Padding.p_sm,
    paddingHorizontal: Padding.p_5xl,
    justifyContent: "center",
    alignItems: "center",
    flexDirection: "row",
    height: 53,
    width: 294,
    borderWidth: 3,
    borderStyle: "solid",
    elevation: 2,
    shadowRadius: 2,
    shadowColor: "rgba(0, 0, 0, 0.05)",
    borderRadius: Border.br_5xs,
    position: "absolute",
    shadowOpacity: 1,
    shadowOffset: {
      width: 0,
      height: 4,
    },
    backgroundColor: Color.colorWhite,
  },
  homeIndicator1: {
    marginLeft: -66.5,
    bottom: 8,
    left: "50%",
    borderRadius: Border.br_81xl,
    backgroundColor: Color.colorBlack,
    width: 134,
    height: 5,
    position: "absolute",
  },
  homeIndicator: {
    bottom: 0,
    height: 34,
    left: 0,
    width: 375,
    backgroundColor: Color.colorWhite,
  },
  kiemtraTaiKhoanChild: {
    height: 164,
    width: 375,
    position: "absolute",
    backgroundColor: Color.colorWhite,
    top: 0,
  },
  container: {
    backgroundColor: Color.colorWhitesmoke_100,
    width: 40,
    height: 40,
    top: 0,
    left: 0,
    borderRadius: Border.br_5xs,
  },
  filterIcon: {
    top: 8,
    left: 8,
    position: "absolute",
  },
  iconfilter: {
    left: 319,
    width: 40,
    height: 40,
    top: 104,
  },
  label: {
    fontSize: FontSize.presetsBody2_size,
    lineHeight: 24,
    fontFamily: FontFamily.presetsBody2,
    color: Color.colorGray,
    marginLeft: 12,
    textAlign: "left",
    overflow: "hidden",
  },
  search: {
    left: 16,
    borderColor: Color.colorGainsboro_200,
    borderWidth: 1,
    width: 295,
    paddingLeft: Padding.p_xs,
    paddingTop: Padding.p_5xs,
    paddingRight: Padding.p_base,
    paddingBottom: Padding.p_5xs,
    top: 104,
    height: 40,
    alignItems: "center",
    flexDirection: "row",
    borderStyle: "solid",
    borderRadius: Border.br_5xs,
    backgroundColor: Color.colorWhite,
  },
  notchIcon: {
    top: -2,
    right: 78,
    bottom: 16,
    left: 78,
    maxWidth: "100%",
    maxHeight: "100%",
    overflow: "hidden",
  },
  batteryIcon: {
    right: 0,
    height: 11,
    width: 24,
    top: 0,
    position: "absolute",
  },
  wifiIcon: {
    width: 15,
    height: 11,
  },
  mobileSignalIcon: {
    width: 17,
    height: 11,
  },
  recordingIndicatorIcon: {
    top: -9,
    right: 56,
    width: 6,
    height: 6,
  },
  rightSide: {
    top: 17,
    right: 15,
    width: 67,
    height: 11,
    position: "absolute",
  },
  leftSideIcon: {
    top: 12,
    left: 21,
    width: 54,
    height: 21,
    position: "absolute",
  },
  statusBarIphoneXOrNewe: {
    height: 44,
    width: 375,
    position: "absolute",
    overflow: "hidden",
  },
  kiemtraTaiKhoan: {
    shadowColor: "rgba(0, 0, 0, 0.25)",
    shadowRadius: 4,
    elevation: 4,
    width: "100%",
    height: 5923,
    overflow: "hidden",
    shadowOpacity: 1,
    shadowOffset: {
      width: 0,
      height: 4,
    },
    flex: 1,
    backgroundColor: Color.colorWhite,
  },
});

export default KiemtraTaiKhoan;

import * as React from "react";
import { StyleSheet, View, Pressable, Text } from "react-native";
import { Image } from "expo-image";
import { StackNavigationProp } from "@react-navigation/stack";
import { useNavigation, ParamListBase } from "@react-navigation/native";
import { Padding, Color, Border, FontFamily, FontSize } from "../GlobalStyles";

const SaoAnTen1 = () => {
  const navigation = useNavigation<StackNavigationProp<ParamListBase>>();

  return (
    <View style={styles.saoAnTen}>
      <View style={styles.homeIndicator}>
        <View style={styles.homeIndicator1} />
      </View>
      <View style={styles.statusBarIphoneXOrNewe}>
        <Image
          style={[styles.notchIcon, styles.iconPosition]}
          contentFit="cover"
          source={require("../assets/notch.png")}
        />
        <View style={styles.rightSide}>
          <Image
            style={styles.batteryIcon}
            contentFit="cover"
            source={require("../assets/battery.png")}
          />
          <Image
            style={styles.wifiIcon}
            contentFit="cover"
            source={require("../assets/wifi4.png")}
          />
          <Image
            style={styles.mobileSignalIcon}
            contentFit="cover"
            source={require("../assets/mobile-signal.png")}
          />
          <Image
            style={[styles.recordingIndicatorIcon, styles.iconPosition]}
            contentFit="cover"
            source={require("../assets/recording-indicator.png")}
          />
        </View>
        <Image
          style={styles.leftSideIcon}
          contentFit="cover"
          source={require("../assets/left-side3.png")}
        />
      </View>
      <View style={styles.header}>
        <Pressable
          style={styles.iconchevronLeft}
          onPress={() => navigation.navigate("DanhMucSinhVien")}
        >
          <Image
            style={[styles.icon, styles.iconLayout1]}
            contentFit="cover"
            source={require("../assets/iconchevron-left.png")}
          />
        </Pressable>
        <Text style={styles.feedback}>Feedback</Text>
      </View>
      <Text style={styles.chtLngNh}>Chất lượng nhà xe</Text>
      <Pressable
        style={[styles.pressable, styles.iconLayout]}
        onPress={() => navigation.navigate("SaoAnTen4")}
      >
        <Image
          style={styles.iconLayout1}
          contentFit="cover"
          source={require("../assets/149220-1.png")}
        />
      </Pressable>
      <Pressable
        style={[styles.pressable1, styles.iconLayout]}
        onPress={() => navigation.navigate("SaoAnTen3")}
      >
        <Image
          style={styles.iconLayout1}
          contentFit="cover"
          source={require("../assets/149220-1.png")}
        />
      </Pressable>
      <Image
        style={[styles.pressable1, styles.iconLayout]}
        contentFit="cover"
        source={require("../assets/1828884-5.png")}
      />
      <Pressable
        style={[styles.pressable2, styles.iconLayout]}
        onPress={() => navigation.navigate("SaoAnTen2")}
      >
        <Image
          style={styles.iconLayout1}
          contentFit="cover"
          source={require("../assets/149220-1.png")}
        />
      </Pressable>
      <Image
        style={[styles.icon5, styles.iconLayout]}
        contentFit="cover"
        source={require("../assets/149220-1.png")}
      />
      <Pressable
        style={[styles.pressable3, styles.iconLayout]}
        onPress={() => navigation.navigate("SaoAnTen")}
      >
        <Image
          style={styles.iconLayout1}
          contentFit="cover"
          source={require("../assets/149220-1.png")}
        />
      </Pressable>
      <View style={[styles.buttonPrimary, styles.buttonShadowBox]}>
        <Text style={styles.thmHnhNh}>Thêm hình ảnh</Text>
        <Image
          style={[styles.icon7, styles.iconLayout]}
          contentFit="cover"
          source={require("../assets/7779866-1.png")}
        />
      </View>
      <View style={[styles.buttonPrimary1, styles.buttonShadowBox]}>
        <Text style={styles.thmHnhNh}>Thêm video</Text>
        <Image
          style={[styles.icon7, styles.iconLayout]}
          contentFit="cover"
          source={require("../assets/10309522-1.png")}
        />
      </View>
      <View style={styles.inputField}>
        <Text style={[styles.hyChiaS, styles.hyChiaSTypo]}>
          Hãy chia sẻ nhận xét cho nhà xe bạn gửi nhé!
        </Text>
      </View>
      <Text style={[styles.hinThTnContainer, styles.hyChiaSTypo]}>
        <Text style={styles.hinThTn}>{`Hiển thị tên đăng nhập trên đánh giá này
`}</Text>
        <Text style={styles.tnTiKhon}>
          Tên tài khoản của bạn sẽ hiển thị như sau
        </Text>
      </Text>
      <Image
        style={[
          styles.z532491552190143824ce5dedc083Icon,
          styles.z5324915521473E7aaf6071bf604ePosition,
        ]}
        contentFit="cover"
        source={require("../assets/z5324915521901-43824ce5dedc0838a7b80e6ae912c854-1.png")}
      />
      <Pressable
        style={styles.pressable4}
        onPress={() => navigation.navigate("Frame1")}
      >
        <Image
          style={styles.iconLayout1}
          contentFit="cover"
          source={require("../assets/5045622-1.png")}
        />
      </Pressable>
      <Image
        style={[styles.pressable, styles.iconLayout]}
        contentFit="cover"
        source={require("../assets/1828884-5.png")}
      />
      <Image
        style={[styles.icon5, styles.iconLayout]}
        contentFit="cover"
        source={require("../assets/1828884-5.png")}
      />
      <Image
        style={[styles.pressable2, styles.iconLayout]}
        contentFit="cover"
        source={require("../assets/1828884-5.png")}
      />
      <Text style={[styles.hiLng, styles.lkFlexBox]}>Hài lòng</Text>
      <Pressable
        style={[
          styles.z5324915521473E7aaf6071bf604e,
          styles.z5324915521473E7aaf6071bf604ePosition,
        ]}
        onPress={() => navigation.navigate("Sao1")}
      >
        <Image
          style={styles.iconLayout1}
          contentFit="cover"
          source={require("../assets/z5324915521473-e7aaf6071bf604ea0707ac4a59be31f6-1.png")}
        />
      </Pressable>
      <Text style={[styles.lk, styles.lkFlexBox]}>l*******k</Text>
    </View>
  );
};

const styles = StyleSheet.create({
  iconPosition: {
    display: "none",
    position: "absolute",
  },
  iconLayout1: {
    height: "100%",
    width: "100%",
  },
  iconLayout: {
    height: 30,
    width: 30,
  },
  buttonShadowBox: {
    paddingVertical: Padding.p_sm,
    paddingHorizontal: Padding.p_5xl,
    height: 75,
    width: 153,
    shadowOpacity: 1,
    elevation: 2,
    shadowRadius: 2,
    shadowOffset: {
      width: 0,
      height: 1,
    },
    shadowColor: "rgba(0, 0, 0, 0.05)",
    top: 258,
    justifyContent: "center",
    flexDirection: "row",
    borderWidth: 3,
    borderColor: Color.colorSalmon,
    borderRadius: Border.br_5xs,
    alignItems: "center",
    borderStyle: "solid",
    position: "absolute",
    backgroundColor: Color.colorWhite,
  },
  hyChiaSTypo: {
    fontFamily: FontFamily.presetsBody2,
    lineHeight: 20,
    fontSize: FontSize.size_sm,
    textAlign: "left",
  },
  z5324915521473E7aaf6071bf604ePosition: {
    height: 35,
    top: 623,
    position: "absolute",
  },
  lkFlexBox: {
    justifyContent: "center",
    alignItems: "center",
    display: "flex",
    fontFamily: FontFamily.smallText,
    fontWeight: "500",
    textAlign: "center",
    position: "absolute",
  },
  homeIndicator1: {
    marginLeft: -66.5,
    bottom: 8,
    borderRadius: Border.br_81xl,
    backgroundColor: Color.colorBlack,
    width: 134,
    height: 5,
    left: "50%",
    position: "absolute",
  },
  homeIndicator: {
    marginLeft: -187.5,
    bottom: 0,
    height: 34,
    width: 375,
    left: "50%",
    position: "absolute",
  },
  notchIcon: {
    top: -2,
    right: 78,
    bottom: 16,
    left: 78,
    maxWidth: "100%",
    maxHeight: "100%",
    overflow: "hidden",
  },
  batteryIcon: {
    right: 0,
    width: 24,
    height: 11,
    top: 0,
    position: "absolute",
  },
  wifiIcon: {
    width: 15,
    height: 11,
  },
  mobileSignalIcon: {
    width: 17,
    height: 11,
  },
  recordingIndicatorIcon: {
    top: -9,
    right: 56,
    width: 6,
    height: 6,
  },
  rightSide: {
    top: 17,
    right: 15,
    width: 67,
    height: 11,
    position: "absolute",
  },
  leftSideIcon: {
    top: 12,
    left: 21,
    width: 54,
    height: 21,
    position: "absolute",
  },
  statusBarIphoneXOrNewe: {
    height: 44,
    left: 0,
    top: 0,
    width: 375,
    position: "absolute",
    overflow: "hidden",
  },
  icon: {
    marginTop: -12,
    height: "100%",
  },
  iconchevronLeft: {
    left: 16,
    height: 24,
    top: "50%",
    width: 24,
    position: "absolute",
  },
  feedback: {
    marginLeft: -65.5,
    letterSpacing: -0.5,
    lineHeight: 34,
    fontWeight: "600",
    fontFamily: FontFamily.interSemiBold,
    color: Color.colorTomato_100,
    textAlign: "center",
    fontSize: FontSize.size_5xl,
    marginTop: -12,
    top: "50%",
    left: "50%",
    position: "absolute",
  },
  header: {
    top: 44,
    borderColor: Color.colorGainsboro_100,
    borderBottomWidth: 0.5,
    height: 42,
    borderStyle: "solid",
    left: 0,
    width: 375,
    position: "absolute",
    overflow: "hidden",
    backgroundColor: Color.colorWhite,
  },
  chtLngNh: {
    top: 93,
    left: 75,
    width: 226,
    height: 45,
    alignItems: "center",
    display: "flex",
    textAlign: "left",
    fontFamily: FontFamily.smallText,
    fontWeight: "500",
    color: Color.colorSalmon,
    lineHeight: 36,
    fontSize: FontSize.size_5xl,
    position: "absolute",
  },
  pressable: {
    left: 79,
    top: 150,
    width: 30,
    position: "absolute",
  },
  pressable1: {
    left: 126,
    top: 150,
    width: 30,
    position: "absolute",
  },
  pressable2: {
    left: 173,
    top: 150,
    width: 30,
    position: "absolute",
  },
  icon5: {
    left: 220,
    top: 150,
    width: 30,
    position: "absolute",
  },
  pressable3: {
    left: 267,
    top: 150,
    width: 30,
    position: "absolute",
  },
  thmHnhNh: {
    lineHeight: 21,
    fontSize: FontSize.size_sm,
    textAlign: "left",
    color: Color.colorSalmon,
    fontFamily: FontFamily.smallText,
    fontWeight: "500",
  },
  icon7: {
    marginLeft: 8,
  },
  buttonPrimary: {
    left: 19,
    paddingVertical: Padding.p_sm,
    paddingHorizontal: Padding.p_5xl,
    height: 75,
    width: 153,
    shadowOpacity: 1,
    elevation: 2,
    shadowRadius: 2,
    shadowOffset: {
      width: 0,
      height: 1,
    },
    shadowColor: "rgba(0, 0, 0, 0.05)",
    top: 258,
  },
  buttonPrimary1: {
    left: 197,
    paddingVertical: Padding.p_sm,
    paddingHorizontal: Padding.p_5xl,
    height: 75,
    width: 153,
    shadowOpacity: 1,
    elevation: 2,
    shadowRadius: 2,
    shadowOffset: {
      width: 0,
      height: 1,
    },
    shadowColor: "rgba(0, 0, 0, 0.05)",
    top: 258,
  },
  hyChiaS: {
    width: 300,
    height: 218,
    color: Color.colorSalmon,
  },
  inputField: {
    top: 354,
    width: 331,
    height: 241,
    paddingHorizontal: Padding.p_base,
    paddingVertical: Padding.p_5xs,
    flexDirection: "row",
    borderWidth: 3,
    borderColor: Color.colorSalmon,
    borderRadius: Border.br_5xs,
    left: 19,
    alignItems: "center",
    borderStyle: "solid",
    position: "absolute",
    backgroundColor: Color.colorWhite,
  },
  hinThTn: {
    color: Color.colorRed,
  },
  tnTiKhon: {
    color: Color.colorSalmon,
  },
  hinThTnContainer: {
    top: 618,
    left: 27,
    width: 275,
    height: 40,
    position: "absolute",
  },
  z532491552190143824ce5dedc083Icon: {
    left: 306,
    width: 52,
  },
  pressable4: {
    left: 153,
    top: 710,
    width: 70,
    height: 70,
    position: "absolute",
  },
  hiLng: {
    top: 198,
    left: 133,
    width: 109,
    color: Color.colorRed,
    lineHeight: 36,
    justifyContent: "center",
    fontSize: FontSize.size_5xl,
    height: 44,
  },
  z5324915521473E7aaf6071bf604e: {
    left: 308,
    width: 48,
  },
  lk: {
    top: 658,
    left: 108,
    fontSize: FontSize.size_xl,
    lineHeight: 30,
    width: 147,
    height: 29,
    color: Color.colorSalmon,
  },
  saoAnTen: {
    flex: 1,
    height: 812,
    overflow: "hidden",
    width: "100%",
    backgroundColor: Color.colorWhite,
  },
});

export default SaoAnTen1;

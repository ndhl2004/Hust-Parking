import * as React from "react";
import { StyleSheet, View, Text, Pressable } from "react-native";
import { Image } from "expo-image";
import { StackNavigationProp } from "@react-navigation/stack";
import { useNavigation, ParamListBase } from "@react-navigation/native";
import Header1 from "../components/Header1";
import { Padding, Color, Border, FontFamily, FontSize } from "../GlobalStyles";

const TimBaiGuiXeConTrong = () => {
  const navigation = useNavigation<StackNavigationProp<ParamListBase>>();

  return (
    <View style={[styles.timBaiGuiXeConTrong, styles.labelFlexBox]}>
      <View style={[styles.homeIndicator, styles.homePosition]}>
        <View style={[styles.homeIndicator1, styles.homePosition]} />
      </View>
      <View style={styles.iconfilter}>
        <View style={styles.container} />
        <Image
          style={[styles.filterIcon, styles.iconLayout]}
          contentFit="cover"
          source={require("../assets/filter.png")}
        />
      </View>
      <View style={styles.search}>
        <Image
          style={styles.iconLayout}
          contentFit="cover"
          source={require("../assets/search.png")}
        />
        <Text style={[styles.label, styles.labelFlexBox]} numberOfLines={1}>
          Search
        </Text>
      </View>
      <View style={[styles.statusBarIphoneXOrNewe, styles.inputField3Position]}>
        <Image
          style={[styles.notchIcon, styles.iconPosition]}
          contentFit="cover"
          source={require("../assets/notch.png")}
        />
        <View style={styles.rightSide}>
          <Image
            style={styles.batteryIcon}
            contentFit="cover"
            source={require("../assets/battery.png")}
          />
          <Image
            style={styles.wifiIcon}
            contentFit="cover"
            source={require("../assets/wifi1.png")}
          />
          <Image
            style={styles.mobileSignalIcon}
            contentFit="cover"
            source={require("../assets/mobile-signal.png")}
          />
          <Image
            style={[styles.recordingIndicatorIcon, styles.iconPosition]}
            contentFit="cover"
            source={require("../assets/recording-indicator.png")}
          />
        </View>
        <Image
          style={styles.leftSideIcon}
          contentFit="cover"
          source={require("../assets/left-side.png")}
        />
      </View>
      <Header1
        onTabBarItemPress={() => navigation.navigate("DanhMucSinhVien")}
      />
      <Pressable
        style={[styles.inputField, styles.inputBorder3]}
        onPress={() => navigation.navigate("C")}
      >
        <Text style={[styles.label1, styles.labelTypo]} numberOfLines={1}>
          73%
        </Text>
      </Pressable>
      <View style={[styles.inputField1, styles.inputSpaceBlock]}>
        <Text style={[styles.label2, styles.labelTypo]} numberOfLines={1}>
          27%
        </Text>
      </View>
      <Pressable
        style={[styles.inputField2, styles.inputBorder2]}
        onPress={() => navigation.navigate("D")}
      >
        <Text style={[styles.label1, styles.labelTypo]} numberOfLines={1}>
          45%
        </Text>
      </Pressable>
      <Pressable
        style={[styles.inputFieldWrapper, styles.inputPosition]}
        onPress={() => navigation.navigate("Tc")}
      >
        <View style={[styles.inputField3, styles.inputBorder3]}>
          <Text style={[styles.label1, styles.labelTypo]} numberOfLines={1}>
            30%
          </Text>
        </View>
      </Pressable>
      <Pressable
        style={[styles.inputFieldContainer, styles.inputLayout]}
        onPress={() => navigation.navigate("Frame4")}
      >
        <View style={[styles.inputField3, styles.inputBorder3]}>
          <Text style={[styles.label1, styles.labelTypo]} numberOfLines={1}>
            100%
          </Text>
        </View>
      </Pressable>
      <View style={[styles.inputField5, styles.inputBorder2]}>
        <Text style={[styles.label2, styles.labelTypo]} numberOfLines={1}>
          55%
        </Text>
      </View>
      <Pressable
        style={[styles.inputField6, styles.inputBorder1]}
        onPress={() => navigation.navigate("D1")}
      >
        <Text style={[styles.label1, styles.labelTypo]} numberOfLines={1}>
          40%
        </Text>
      </Pressable>
      <View style={[styles.inputField7, styles.inputBorder1]}>
        <Text style={[styles.label2, styles.labelTypo]} numberOfLines={1}>
          60%
        </Text>
      </View>
      <Pressable
        style={[styles.inputField8, styles.inputBorder]}
        onPress={() => navigation.navigate("C1")}
      >
        <Text style={[styles.label1, styles.labelTypo]} numberOfLines={1}>
          10%
        </Text>
      </Pressable>
      <View style={[styles.inputField9, styles.inputPosition]}>
        <Text style={[styles.label2, styles.labelTypo]} numberOfLines={1}>
          70%
        </Text>
      </View>
      <Pressable
        style={[styles.inputField10, styles.inputBorder3]}
        onPress={() => navigation.navigate("Frame3")}
      >
        <Text style={[styles.label1, styles.labelTypo]} numberOfLines={1}>
          100%
        </Text>
      </Pressable>
      <View style={[styles.inputField11, styles.inputBorder]}>
        <Text style={[styles.label1, styles.labelTypo]} numberOfLines={1}>
          90%
        </Text>
      </View>
      <Text style={[styles.c9, styles.c9Typo]}>C9</Text>
      <Text style={[styles.c7, styles.c9Typo]}>C7</Text>
      <Text style={[styles.c1, styles.c9Typo]}>C1</Text>
      <Text style={[styles.d7, styles.c9Typo]}>D7</Text>
      <Text style={[styles.d8, styles.c9Typo]}>D8</Text>
      <Text style={[styles.tc, styles.c9Typo]}>TC</Text>
      <Text style={[styles.d3, styles.c9Typo]}>D3</Text>
    </View>
  );
};

const styles = StyleSheet.create({
  labelFlexBox: {
    flex: 1,
    overflow: "hidden",
  },
  homePosition: {
    left: "50%",
    position: "absolute",
  },
  iconLayout: {
    height: 24,
    width: 24,
    overflow: "hidden",
  },
  inputField3Position: {
    left: 0,
    top: 0,
    position: "absolute",
  },
  iconPosition: {
    display: "none",
    position: "absolute",
  },
  inputBorder3: {
    paddingVertical: Padding.p_5xs,
    alignItems: "center",
    flexDirection: "row",
    borderWidth: 1,
    borderColor: Color.colorGainsboro_200,
    borderStyle: "solid",
    borderRadius: Border.br_5xs,
  },
  labelTypo: {
    color: Color.colorWhite,
    fontFamily: FontFamily.tienneBold,
    fontWeight: "700",
    lineHeight: 20,
    fontSize: FontSize.size_sm,
    overflow: "hidden",
    flex: 1,
  },
  inputSpaceBlock: {
    paddingHorizontal: Padding.p_11xl,
    justifyContent: "space-between",
    backgroundColor: Color.colorLightseagreen,
  },
  inputBorder2: {
    top: 263,
    paddingVertical: Padding.p_5xs,
    alignItems: "center",
    flexDirection: "row",
    borderWidth: 1,
    borderColor: Color.colorGainsboro_200,
    borderStyle: "solid",
    borderRadius: Border.br_5xs,
    height: 40,
    position: "absolute",
  },
  inputPosition: {
    top: 333,
    height: 40,
    position: "absolute",
  },
  inputLayout: {
    width: 304,
    left: 52,
  },
  inputBorder1: {
    top: 403,
    paddingVertical: Padding.p_5xs,
    alignItems: "center",
    flexDirection: "row",
    borderWidth: 1,
    borderColor: Color.colorGainsboro_200,
    borderStyle: "solid",
    borderRadius: Border.br_5xs,
    height: 40,
    position: "absolute",
  },
  inputBorder: {
    top: 543,
    paddingVertical: Padding.p_5xs,
    alignItems: "center",
    flexDirection: "row",
    borderWidth: 1,
    borderColor: Color.colorGainsboro_200,
    borderStyle: "solid",
    borderRadius: Border.br_5xs,
    height: 40,
    position: "absolute",
  },
  c9Typo: {
    height: 29,
    width: 38,
    color: Color.colorRed,
    lineHeight: 34,
    fontSize: FontSize.size_5xl,
    fontFamily: FontFamily.tienneBold,
    fontWeight: "700",
    textAlign: "left",
    position: "absolute",
  },
  homeIndicator1: {
    marginLeft: -66.5,
    bottom: 8,
    borderRadius: Border.br_81xl,
    backgroundColor: Color.colorBlack,
    width: 134,
    height: 5,
  },
  homeIndicator: {
    marginLeft: -187.5,
    bottom: 0,
    height: 34,
    width: 375,
  },
  container: {
    backgroundColor: Color.colorWhitesmoke_100,
    borderRadius: Border.br_5xs,
    left: 0,
    top: 0,
    height: 40,
    width: 40,
    position: "absolute",
  },
  filterIcon: {
    top: 8,
    left: 8,
    position: "absolute",
  },
  iconfilter: {
    left: 319,
    height: 40,
    width: 40,
    top: 104,
    position: "absolute",
  },
  label: {
    fontSize: FontSize.presetsBody2_size,
    lineHeight: 24,
    fontFamily: FontFamily.presetsBody2,
    color: Color.colorGray,
    marginLeft: 12,
    textAlign: "left",
    overflow: "hidden",
  },
  search: {
    left: 16,
    width: 295,
    paddingLeft: Padding.p_xs,
    paddingTop: Padding.p_5xs,
    paddingRight: Padding.p_base,
    paddingBottom: Padding.p_5xs,
    alignItems: "center",
    flexDirection: "row",
    borderWidth: 1,
    borderColor: Color.colorGainsboro_200,
    borderStyle: "solid",
    borderRadius: Border.br_5xs,
    height: 40,
    top: 104,
    position: "absolute",
    backgroundColor: Color.colorWhite,
  },
  notchIcon: {
    top: -2,
    right: 78,
    bottom: 16,
    left: 78,
    maxWidth: "100%",
    maxHeight: "100%",
    overflow: "hidden",
  },
  batteryIcon: {
    right: 0,
    height: 11,
    width: 24,
    top: 0,
    position: "absolute",
  },
  wifiIcon: {
    width: 15,
    height: 11,
  },
  mobileSignalIcon: {
    width: 17,
    height: 11,
  },
  recordingIndicatorIcon: {
    top: -9,
    right: 56,
    width: 6,
    height: 6,
  },
  rightSide: {
    top: 17,
    right: 15,
    width: 67,
    height: 11,
    position: "absolute",
  },
  leftSideIcon: {
    top: 12,
    left: 21,
    width: 54,
    height: 21,
    position: "absolute",
  },
  statusBarIphoneXOrNewe: {
    height: 44,
    width: 375,
    overflow: "hidden",
  },
  label1: {
    textAlign: "left",
  },
  inputField: {
    paddingHorizontal: Padding.p_base,
    backgroundColor: Color.colorSalmon,
    width: 304,
    left: 52,
    top: 193,
    paddingVertical: Padding.p_5xs,
    height: 40,
    position: "absolute",
  },
  label2: {
    textAlign: "right",
  },
  inputField1: {
    left: 254,
    width: 102,
    paddingVertical: Padding.p_5xs,
    alignItems: "center",
    flexDirection: "row",
    borderWidth: 1,
    borderColor: Color.colorGainsboro_200,
    borderStyle: "solid",
    borderRadius: Border.br_5xs,
    top: 193,
    height: 40,
    position: "absolute",
  },
  inputField2: {
    paddingHorizontal: Padding.p_base,
    backgroundColor: Color.colorSalmon,
    width: 304,
    left: 52,
  },
  inputField3: {
    paddingHorizontal: Padding.p_base,
    backgroundColor: Color.colorSalmon,
    width: 304,
    left: 0,
    top: 0,
    position: "absolute",
    height: 40,
  },
  inputFieldWrapper: {
    width: 304,
    left: 52,
  },
  inputFieldContainer: {
    top: 613,
    height: 40,
    position: "absolute",
  },
  inputField5: {
    left: 194,
    width: 162,
    paddingHorizontal: Padding.p_11xl,
    justifyContent: "space-between",
    backgroundColor: Color.colorLightseagreen,
  },
  inputField6: {
    paddingHorizontal: Padding.p_base,
    backgroundColor: Color.colorSalmon,
    width: 304,
    left: 52,
  },
  inputField7: {
    left: 170,
    width: 186,
    paddingHorizontal: Padding.p_11xl,
    justifyContent: "space-between",
    backgroundColor: Color.colorLightseagreen,
  },
  inputField8: {
    paddingHorizontal: Padding.p_base,
    backgroundColor: Color.colorSalmon,
    width: 304,
    left: 52,
  },
  inputField9: {
    left: 146,
    width: 210,
    paddingHorizontal: Padding.p_11xl,
    justifyContent: "space-between",
    backgroundColor: Color.colorLightseagreen,
    paddingVertical: Padding.p_5xs,
    alignItems: "center",
    flexDirection: "row",
    borderWidth: 1,
    borderColor: Color.colorGainsboro_200,
    borderStyle: "solid",
    borderRadius: Border.br_5xs,
  },
  inputField10: {
    top: 473,
    paddingHorizontal: Padding.p_base,
    backgroundColor: Color.colorSalmon,
    width: 304,
    left: 52,
    height: 40,
    position: "absolute",
  },
  inputField11: {
    left: 98,
    width: 258,
    paddingHorizontal: Padding.p_11xl,
    justifyContent: "space-between",
    backgroundColor: Color.colorLightseagreen,
  },
  c9: {
    top: 619,
    left: 8,
  },
  c7: {
    top: 194,
    left: 9,
  },
  c1: {
    top: 549,
    left: 8,
  },
  d7: {
    top: 479,
    left: 8,
  },
  d8: {
    top: 409,
    left: 8,
  },
  tc: {
    top: 339,
    left: 8,
  },
  d3: {
    top: 269,
    left: 7,
  },
  timBaiGuiXeConTrong: {
    shadowColor: "rgba(0, 0, 0, 0.25)",
    shadowOffset: {
      width: 0,
      height: 4,
    },
    shadowRadius: 4,
    elevation: 4,
    shadowOpacity: 1,
    width: "100%",
    height: 812,
    overflow: "hidden",
    backgroundColor: Color.colorWhite,
    flex: 1,
  },
});

export default TimBaiGuiXeConTrong;

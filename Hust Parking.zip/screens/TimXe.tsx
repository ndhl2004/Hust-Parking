import * as React from "react";
import { Image } from "expo-image";
import { StyleSheet, View, Pressable, Text } from "react-native";
import { StackNavigationProp } from "@react-navigation/stack";
import { useNavigation, ParamListBase } from "@react-navigation/native";
import { Border, Color, FontFamily, FontSize, Padding } from "../GlobalStyles";

const TimXe = () => {
  const navigation = useNavigation<StackNavigationProp<ParamListBase>>();

  return (
    <View style={styles.timXe}>
      <Image
        style={styles.timXeChild}
        contentFit="cover"
        source={require("../assets/ellipse-3.png")}
      />
      <Image
        style={styles.timXeItem}
        contentFit="cover"
        source={require("../assets/ellipse-4.png")}
      />
      <Image
        style={styles.timXeInner}
        contentFit="cover"
        source={require("../assets/ellipse-2.png")}
      />
      <View style={styles.homeIndicator}>
        <View style={styles.homeIndicator1} />
      </View>
      <View style={[styles.header, styles.headerPosition]}>
        <Pressable
          style={[styles.iconchevronLeft, styles.tmXePosition]}
          onPress={() => navigation.navigate("TimKiemThongTinXe")}
        >
          <Image
            style={styles.icon}
            contentFit="cover"
            source={require("../assets/iconchevron-left.png")}
          />
        </Pressable>
        <Text style={[styles.tmXe, styles.tmXePosition]}>Tìm xe</Text>
      </View>
      <View style={[styles.statusBarIphoneXOrNewe, styles.batteryIconPosition]}>
        <Image
          style={[styles.notchIcon, styles.iconPosition]}
          contentFit="cover"
          source={require("../assets/notch.png")}
        />
        <View style={styles.rightSide}>
          <Image
            style={[styles.batteryIcon, styles.batteryIconPosition]}
            contentFit="cover"
            source={require("../assets/battery.png")}
          />
          <Image
            style={styles.wifiIcon}
            contentFit="cover"
            source={require("../assets/wifi3.png")}
          />
          <Image
            style={styles.mobileSignalIcon}
            contentFit="cover"
            source={require("../assets/mobile-signal.png")}
          />
          <Image
            style={[styles.recordingIndicatorIcon, styles.iconPosition]}
            contentFit="cover"
            source={require("../assets/recording-indicator.png")}
          />
        </View>
        <Image
          style={styles.leftSideIcon}
          contentFit="cover"
          source={require("../assets/left-side.png")}
        />
      </View>
      <Image
        style={styles.images2Icon}
        contentFit="cover"
        source={require("../assets/images-2.png")}
      />
      <Image
        style={styles.ellipseIcon}
        contentFit="cover"
        source={require("../assets/ellipse-5.png")}
      />
      <Pressable
        style={styles.buttonPrimary}
        onPress={() => navigation.navigate("Frame")}
      >
        <Text style={styles.honThnh}>Hoàn thành</Text>
      </Pressable>
    </View>
  );
};

const styles = StyleSheet.create({
  headerPosition: {
    left: 0,
    width: 375,
    overflow: "hidden",
  },
  tmXePosition: {
    top: "50%",
    position: "absolute",
  },
  batteryIconPosition: {
    top: 0,
    position: "absolute",
  },
  iconPosition: {
    display: "none",
    position: "absolute",
  },
  timXeChild: {
    top: 246,
    width: 336,
    height: 336,
    left: 16,
    position: "absolute",
  },
  timXeItem: {
    top: 274,
    left: 44,
    width: 280,
    height: 280,
    position: "absolute",
  },
  timXeInner: {
    top: 348,
    left: 118,
    width: 132,
    height: 132,
    position: "absolute",
  },
  homeIndicator1: {
    marginLeft: -66.5,
    bottom: 8,
    borderRadius: Border.br_81xl,
    backgroundColor: Color.colorBlack,
    width: 134,
    height: 5,
    left: "50%",
    position: "absolute",
  },
  homeIndicator: {
    marginLeft: -187.5,
    bottom: 0,
    height: 34,
    width: 375,
    left: "50%",
    position: "absolute",
  },
  icon: {
    height: "100%",
    marginTop: -12,
    width: "100%",
  },
  iconchevronLeft: {
    height: 24,
    width: 24,
    left: 16,
  },
  tmXe: {
    marginLeft: -47.5,
    letterSpacing: -0.5,
    lineHeight: 34,
    fontWeight: "600",
    fontFamily: FontFamily.interSemiBold,
    color: Color.colorTomato_100,
    textAlign: "center",
    fontSize: FontSize.size_5xl,
    marginTop: -12,
    left: "50%",
  },
  header: {
    top: 44,
    borderStyle: "solid",
    borderColor: Color.colorGainsboro_100,
    borderBottomWidth: 0.5,
    height: 42,
    position: "absolute",
    backgroundColor: Color.colorWhite,
  },
  notchIcon: {
    top: -2,
    right: 78,
    bottom: 16,
    left: 78,
    maxWidth: "100%",
    maxHeight: "100%",
    overflow: "hidden",
  },
  batteryIcon: {
    right: 0,
    height: 11,
    width: 24,
  },
  wifiIcon: {
    width: 15,
    height: 11,
  },
  mobileSignalIcon: {
    width: 17,
    height: 11,
  },
  recordingIndicatorIcon: {
    top: -9,
    right: 56,
    width: 6,
    height: 6,
  },
  rightSide: {
    top: 17,
    right: 15,
    width: 67,
    height: 11,
    position: "absolute",
  },
  leftSideIcon: {
    top: 12,
    left: 21,
    width: 54,
    height: 21,
    position: "absolute",
  },
  statusBarIphoneXOrNewe: {
    height: 44,
    left: 0,
    width: 375,
    overflow: "hidden",
  },
  images2Icon: {
    top: 372,
    left: 140,
    width: 88,
    height: 85,
    position: "absolute",
  },
  ellipseIcon: {
    top: 296,
    left: 282,
    width: 29,
    height: 29,
    position: "absolute",
  },
  honThnh: {
    lineHeight: 36,
    fontWeight: "500",
    fontFamily: FontFamily.smallText,
    color: Color.colorWhite,
    textAlign: "left",
    fontSize: FontSize.size_5xl,
  },
  buttonPrimary: {
    top: 659,
    left: 94,
    borderRadius: Border.br_5xs,
    backgroundColor: Color.colorSalmon,
    shadowColor: "rgba(0, 0, 0, 0.05)",
    shadowOffset: {
      width: 0,
      height: 1,
    },
    shadowRadius: 2,
    elevation: 2,
    shadowOpacity: 1,
    width: 188,
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    paddingHorizontal: Padding.p_5xl,
    paddingVertical: Padding.p_sm,
    position: "absolute",
  },
  timXe: {
    flex: 1,
    height: 812,
    overflow: "hidden",
    width: "100%",
    backgroundColor: Color.colorWhite,
  },
});

export default TimXe;

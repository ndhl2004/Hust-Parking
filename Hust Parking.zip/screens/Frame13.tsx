import * as React from "react";
import { StyleSheet, View, Pressable, Text } from "react-native";
import { Image } from "expo-image";
import { StackNavigationProp } from "@react-navigation/stack";
import { useNavigation, ParamListBase } from "@react-navigation/native";
import { Color, FontFamily, FontSize, Border, Padding } from "../GlobalStyles";

const Frame13 = () => {
  const navigation = useNavigation<StackNavigationProp<ParamListBase>>();

  return (
    <View style={styles.view}>
      <View style={styles.homeIndicator}>
        <View style={styles.homeIndicator1} />
      </View>
      <View style={[styles.header, styles.headerPosition]}>
        <Pressable
          style={styles.iconchevronLeft}
          onPress={() => navigation.navigate("D8B")}
        >
          <Image
            style={styles.icon}
            contentFit="cover"
            source={require("../assets/iconchevron-left1.png")}
          />
        </Pressable>
        <Text style={[styles.d8, styles.d8Typo]}>D8</Text>
      </View>
      <View style={[styles.statusBarIphoneXOrNewe, styles.batteryIconPosition]}>
        <Image
          style={[styles.notchIcon, styles.iconPosition]}
          contentFit="cover"
          source={require("../assets/notch.png")}
        />
        <View style={styles.rightSide}>
          <Image
            style={[styles.batteryIcon, styles.batteryIconPosition]}
            contentFit="cover"
            source={require("../assets/battery.png")}
          />
          <Image
            style={styles.wifiIcon}
            contentFit="cover"
            source={require("../assets/wifi6.png")}
          />
          <Image
            style={styles.mobileSignalIcon}
            contentFit="cover"
            source={require("../assets/mobile-signal.png")}
          />
          <Image
            style={[styles.recordingIndicatorIcon, styles.iconPosition]}
            contentFit="cover"
            source={require("../assets/recording-indicator.png")}
          />
        </View>
        <Image
          style={styles.leftSideIcon}
          contentFit="cover"
          source={require("../assets/left-side.png")}
        />
      </View>
      <Text style={[styles.chcMngBn, styles.d8Typo]}>
        Chúc mừng bạn đã gửi xe thành công...
      </Text>
      <Image
        style={styles.icon1}
        contentFit="cover"
        source={require("../assets/1160-1.png")}
      />
      <Pressable
        style={styles.buttonPrimary}
        onPress={() => navigation.navigate("DanhMucSinhVien")}
      >
        <Text style={styles.ktThc}>Kết thúc</Text>
      </Pressable>
    </View>
  );
};

const styles = StyleSheet.create({
  headerPosition: {
    left: 0,
    width: 375,
    overflow: "hidden",
  },
  d8Typo: {
    textAlign: "center",
    color: Color.colorCrimson,
    fontFamily: FontFamily.interSemiBold,
    fontWeight: "600",
    lineHeight: 34,
    letterSpacing: -0.5,
    fontSize: FontSize.size_5xl,
    position: "absolute",
  },
  batteryIconPosition: {
    top: 0,
    position: "absolute",
  },
  iconPosition: {
    display: "none",
    position: "absolute",
  },
  homeIndicator1: {
    marginLeft: -66.5,
    bottom: 8,
    borderRadius: Border.br_81xl,
    backgroundColor: Color.colorBlack,
    width: 134,
    height: 5,
    left: "50%",
    position: "absolute",
  },
  homeIndicator: {
    marginLeft: -187.5,
    bottom: 0,
    height: 34,
    width: 375,
    left: "50%",
    position: "absolute",
  },
  icon: {
    height: "100%",
    marginTop: -12,
    width: "100%",
  },
  iconchevronLeft: {
    left: 16,
    height: 24,
    width: 24,
    top: "50%",
    position: "absolute",
  },
  d8: {
    marginLeft: -26.5,
    marginTop: -12,
    top: "50%",
    left: "50%",
  },
  header: {
    top: 44,
    borderStyle: "solid",
    borderColor: Color.colorGainsboro_100,
    borderBottomWidth: 0.5,
    height: 42,
    position: "absolute",
    backgroundColor: Color.colorWhite,
  },
  notchIcon: {
    top: -2,
    right: 78,
    bottom: 16,
    left: 78,
    maxWidth: "100%",
    maxHeight: "100%",
    overflow: "hidden",
  },
  batteryIcon: {
    right: 0,
    height: 11,
    width: 24,
  },
  wifiIcon: {
    width: 15,
    height: 11,
  },
  mobileSignalIcon: {
    width: 17,
    height: 11,
  },
  recordingIndicatorIcon: {
    top: -9,
    right: 56,
    width: 6,
    height: 6,
  },
  rightSide: {
    top: 17,
    right: 15,
    width: 67,
    height: 11,
    position: "absolute",
  },
  leftSideIcon: {
    top: 12,
    left: 21,
    width: 54,
    height: 21,
    position: "absolute",
  },
  statusBarIphoneXOrNewe: {
    height: 44,
    left: 0,
    width: 375,
    overflow: "hidden",
  },
  chcMngBn: {
    top: 477,
    left: 32,
    width: 294,
    height: 68,
  },
  icon1: {
    top: 313,
    left: 130,
    width: 107,
    height: 107,
    position: "absolute",
  },
  ktThc: {
    lineHeight: 36,
    fontWeight: "500",
    fontFamily: FontFamily.smallText,
    color: Color.colorWhite,
    textAlign: "left",
    fontSize: FontSize.size_5xl,
  },
  buttonPrimary: {
    top: 659,
    left: 94,
    borderRadius: Border.br_5xs,
    backgroundColor: Color.colorSalmon,
    shadowColor: "rgba(0, 0, 0, 0.05)",
    shadowOffset: {
      width: 0,
      height: 1,
    },
    shadowRadius: 2,
    elevation: 2,
    shadowOpacity: 1,
    width: 188,
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    paddingHorizontal: Padding.p_5xl,
    paddingVertical: Padding.p_sm,
    position: "absolute",
  },
  view: {
    flex: 1,
    height: 812,
    overflow: "hidden",
    width: "100%",
    backgroundColor: Color.colorWhite,
  },
});

export default Frame13;

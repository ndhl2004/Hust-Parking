import * as React from "react";
import { Text, StyleSheet, View } from "react-native";
import { Image } from "expo-image";
import { StackNavigationProp } from "@react-navigation/stack";
import { useNavigation, ParamListBase } from "@react-navigation/native";
import Header1 from "../components/Header1";
import { Padding, Color, Border, FontSize, FontFamily } from "../GlobalStyles";

const KiemtraC2 = () => {
  const navigation = useNavigation<StackNavigationProp<ParamListBase>>();

  return (
    <View style={[styles.kiemtraC1, styles.labelFlexBox]}>
      <View style={[styles.buttonPrimary, styles.buttonShadowBox]}>
        <Text style={styles.guest}>Guest</Text>
      </View>
      <View style={[styles.buttonPrimary1, styles.buttonShadowBox]}>
        <Text style={styles.guest}>20204937</Text>
      </View>
      <View style={[styles.buttonPrimary2, styles.buttonShadowBox]}>
        <Text style={styles.guest}>20224344</Text>
      </View>
      <View style={[styles.buttonPrimary3, styles.buttonShadowBox]}>
        <Text style={styles.guest}>20225545</Text>
      </View>
      <View style={[styles.buttonPrimary4, styles.buttonShadowBox]}>
        <Text style={styles.guest}>Guest</Text>
      </View>
      <View style={[styles.buttonPrimary5, styles.buttonShadowBox]}>
        <Text style={styles.guest}>20222333</Text>
      </View>
      <View style={[styles.homeIndicator, styles.homeIndicatorLayout]}>
        <View style={styles.homeIndicator1} />
      </View>
      <View style={[styles.kiemtraC1Child, styles.containerPosition]} />
      <View style={[styles.iconfilter, styles.searchLayout]}>
        <View style={[styles.container, styles.searchLayout]} />
        <Image
          style={[styles.filterIcon, styles.iconLayout]}
          contentFit="cover"
          source={require("../assets/filter.png")}
        />
      </View>
      <View style={[styles.search, styles.searchLayout]}>
        <Image
          style={styles.iconLayout}
          contentFit="cover"
          source={require("../assets/search.png")}
        />
        <Text style={[styles.label, styles.labelFlexBox]} numberOfLines={1}>
          Search
        </Text>
      </View>
      <View style={[styles.statusBarIphoneXOrNewe, styles.containerPosition]}>
        <Image
          style={[styles.notchIcon, styles.iconPosition]}
          contentFit="cover"
          source={require("../assets/notch.png")}
        />
        <View style={styles.rightSide}>
          <Image
            style={styles.batteryIcon}
            contentFit="cover"
            source={require("../assets/battery.png")}
          />
          <Image
            style={styles.wifiIcon}
            contentFit="cover"
            source={require("../assets/wifi3.png")}
          />
          <Image
            style={styles.mobileSignalIcon}
            contentFit="cover"
            source={require("../assets/mobile-signal.png")}
          />
          <Image
            style={[styles.recordingIndicatorIcon, styles.iconPosition]}
            contentFit="cover"
            source={require("../assets/recording-indicator.png")}
          />
        </View>
        <Image
          style={styles.leftSideIcon}
          contentFit="cover"
          source={require("../assets/left-side.png")}
        />
      </View>
      <Header1 onTabBarItemPress={() => navigation.navigate("DanhMucQuanLy")} />
    </View>
  );
};

const styles = StyleSheet.create({
  labelFlexBox: {
    flex: 1,
    overflow: "hidden",
  },
  buttonShadowBox: {
    paddingVertical: Padding.p_sm,
    paddingHorizontal: Padding.p_5xl,
    justifyContent: "center",
    height: 53,
    width: 294,
    borderWidth: 3,
    borderColor: Color.colorLightseagreen,
    elevation: 2,
    shadowRadius: 2,
    shadowColor: "rgba(0, 0, 0, 0.05)",
    left: 39,
    alignItems: "center",
    flexDirection: "row",
    borderStyle: "solid",
    borderRadius: Border.br_5xs,
    position: "absolute",
    shadowOpacity: 1,
    shadowOffset: {
      width: 0,
      height: 4,
    },
    backgroundColor: Color.colorWhite,
  },
  homeIndicatorLayout: {
    width: 375,
    position: "absolute",
  },
  containerPosition: {
    top: 0,
    left: 0,
  },
  searchLayout: {
    height: 40,
    position: "absolute",
  },
  iconLayout: {
    height: 24,
    width: 24,
    overflow: "hidden",
  },
  iconPosition: {
    display: "none",
    position: "absolute",
  },
  guest: {
    fontSize: FontSize.size_5xl,
    lineHeight: 36,
    fontWeight: "500",
    fontFamily: FontFamily.smallText,
    color: Color.colorLightseagreen,
    textAlign: "left",
  },
  buttonPrimary: {
    top: 176,
  },
  buttonPrimary1: {
    top: 259,
  },
  buttonPrimary2: {
    top: 342,
  },
  buttonPrimary3: {
    top: 425,
  },
  buttonPrimary4: {
    top: 508,
  },
  buttonPrimary5: {
    top: 591,
  },
  homeIndicator1: {
    marginLeft: -66.5,
    bottom: 8,
    left: "50%",
    borderRadius: Border.br_81xl,
    backgroundColor: Color.colorBlack,
    width: 134,
    height: 5,
    position: "absolute",
  },
  homeIndicator: {
    bottom: 0,
    height: 34,
    left: 0,
    width: 375,
    backgroundColor: Color.colorWhite,
  },
  kiemtraC1Child: {
    height: 164,
    width: 375,
    position: "absolute",
    backgroundColor: Color.colorWhite,
    top: 0,
  },
  container: {
    backgroundColor: Color.colorWhitesmoke_100,
    width: 40,
    height: 40,
    top: 0,
    left: 0,
    borderRadius: Border.br_5xs,
  },
  filterIcon: {
    top: 8,
    left: 8,
    position: "absolute",
  },
  iconfilter: {
    left: 319,
    width: 40,
    height: 40,
    top: 104,
  },
  label: {
    fontSize: FontSize.presetsBody2_size,
    lineHeight: 24,
    fontFamily: FontFamily.presetsBody2,
    color: Color.colorGray,
    marginLeft: 12,
    textAlign: "left",
    overflow: "hidden",
  },
  search: {
    left: 16,
    borderColor: Color.colorGainsboro_200,
    borderWidth: 1,
    width: 295,
    paddingLeft: Padding.p_xs,
    paddingTop: Padding.p_5xs,
    paddingRight: Padding.p_base,
    paddingBottom: Padding.p_5xs,
    top: 104,
    height: 40,
    alignItems: "center",
    flexDirection: "row",
    borderStyle: "solid",
    borderRadius: Border.br_5xs,
    backgroundColor: Color.colorWhite,
  },
  notchIcon: {
    top: -2,
    right: 78,
    bottom: 16,
    left: 78,
    maxWidth: "100%",
    maxHeight: "100%",
    overflow: "hidden",
  },
  batteryIcon: {
    right: 0,
    height: 11,
    width: 24,
    top: 0,
    position: "absolute",
  },
  wifiIcon: {
    width: 15,
    height: 11,
  },
  mobileSignalIcon: {
    width: 17,
    height: 11,
  },
  recordingIndicatorIcon: {
    top: -9,
    right: 56,
    width: 6,
    height: 6,
  },
  rightSide: {
    top: 17,
    right: 15,
    width: 67,
    height: 11,
    position: "absolute",
  },
  leftSideIcon: {
    top: 12,
    left: 21,
    width: 54,
    height: 21,
    position: "absolute",
  },
  statusBarIphoneXOrNewe: {
    height: 44,
    width: 375,
    position: "absolute",
    overflow: "hidden",
  },
  kiemtraC1: {
    shadowColor: "rgba(0, 0, 0, 0.25)",
    shadowRadius: 4,
    elevation: 4,
    width: "100%",
    height: 812,
    overflow: "hidden",
    shadowOpacity: 1,
    shadowOffset: {
      width: 0,
      height: 4,
    },
    flex: 1,
    backgroundColor: Color.colorWhite,
  },
});

export default KiemtraC2;

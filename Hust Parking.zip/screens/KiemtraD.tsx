import * as React from "react";
import { Text, StyleSheet, View, Pressable } from "react-native";
import { Image } from "expo-image";
import { StackNavigationProp } from "@react-navigation/stack";
import { useNavigation, ParamListBase } from "@react-navigation/native";
import Header1 from "../components/Header1";
import { Padding, Border, Color, FontFamily, FontSize } from "../GlobalStyles";

const KiemtraD = () => {
  const navigation = useNavigation<StackNavigationProp<ParamListBase>>();

  return (
    <View style={[styles.kiemtraD3, styles.labelFlexBox]}>
      <View style={[styles.buttonPrimary, styles.buttonShadowBox7]}>
        <Text style={[styles.guest, styles.guestTypo]}>Guest</Text>
      </View>
      <View style={[styles.buttonPrimary1, styles.buttonShadowBox7]}>
        <Text style={[styles.guest, styles.guestTypo]}>20204937</Text>
      </View>
      <View style={[styles.buttonPrimary2, styles.buttonShadowBox7]}>
        <Text style={[styles.guest, styles.guestTypo]}>20224344</Text>
      </View>
      <View style={[styles.buttonPrimary3, styles.buttonShadowBox7]}>
        <Text style={[styles.guest, styles.guestTypo]}>20225545</Text>
      </View>
      <Pressable
        style={[styles.buttonPrimary4, styles.buttonShadowBox7]}
        onPress={() => navigation.navigate("Frame6")}
      >
        <Text style={[styles.text3, styles.guestTypo]}>20226810</Text>
      </Pressable>
      <View style={[styles.buttonPrimary5, styles.buttonShadowBox6]}>
        <Text style={[styles.guest, styles.guestTypo]}>20194534</Text>
      </View>
      <View style={[styles.buttonPrimary6, styles.buttonShadowBox6]}>
        <Text style={[styles.guest, styles.guestTypo]}>20224524</Text>
      </View>
      <View style={[styles.buttonPrimary7, styles.buttonShadowBox6]}>
        <Text style={[styles.guest, styles.guestTypo]}>20212344</Text>
      </View>
      <View style={styles.buttonShadowBox5}>
        <Text style={[styles.guest, styles.guestTypo]}>20238324</Text>
      </View>
      <View style={[styles.buttonPrimary9, styles.buttonShadowBox7]}>
        <Text style={[styles.guest, styles.guestTypo]}>20223424</Text>
      </View>
      <View style={[styles.buttonPrimary10, styles.buttonShadowBox7]}>
        <Text style={[styles.guest, styles.guestTypo]}>20224224</Text>
      </View>
      <View style={[styles.buttonPrimary11, styles.buttonShadowBox7]}>
        <Text style={[styles.guest, styles.guestTypo]}>20205464</Text>
      </View>
      <View style={[styles.buttonPrimary12, styles.buttonShadowBox7]}>
        <Text style={[styles.guest, styles.guestTypo]}>20204924</Text>
      </View>
      <View style={[styles.buttonPrimary13, styles.buttonShadowBox7]}>
        <Text style={[styles.guest, styles.guestTypo]}>20225824</Text>
      </View>
      <View style={[styles.buttonPrimary14, styles.buttonShadowBox7]}>
        <Text style={[styles.guest, styles.guestTypo]}>20222333</Text>
      </View>
      <View style={[styles.buttonPrimary15, styles.buttonShadowBox7]}>
        <Text style={[styles.guest, styles.guestTypo]}>20184234</Text>
      </View>
      <View style={[styles.buttonPrimary16, styles.buttonShadowBox7]}>
        <Text style={[styles.guest, styles.guestTypo]}>20234544</Text>
      </View>
      <View style={[styles.buttonPrimary17, styles.buttonShadowBox7]}>
        <Text style={[styles.guest, styles.guestTypo]}>20225434</Text>
      </View>
      <View style={[styles.buttonPrimary18, styles.buttonShadowBox7]}>
        <Text style={[styles.guest, styles.guestTypo]}>20234764</Text>
      </View>
      <View style={styles.buttonShadowBox4}>
        <Text style={[styles.guest, styles.guestTypo]}>20222333</Text>
      </View>
      <View style={styles.buttonShadowBox3}>
        <Text style={[styles.guest, styles.guestTypo]}>20184234</Text>
      </View>
      <View style={styles.buttonShadowBox2}>
        <Text style={[styles.guest, styles.guestTypo]}>20234544</Text>
      </View>
      <View style={styles.buttonShadowBox1}>
        <Text style={[styles.guest, styles.guestTypo]}>20225434</Text>
      </View>
      <View style={styles.buttonShadowBox}>
        <Text style={[styles.guest, styles.guestTypo]}>20234764</Text>
      </View>
      <View style={styles.buttonShadowBox5}>
        <Text style={[styles.guest, styles.guestTypo]}>20238324</Text>
      </View>
      <View style={styles.buttonShadowBox4}>
        <Text style={[styles.guest, styles.guestTypo]}>20222333</Text>
      </View>
      <View style={styles.buttonShadowBox3}>
        <Text style={[styles.guest, styles.guestTypo]}>20184234</Text>
      </View>
      <View style={styles.buttonShadowBox2}>
        <Text style={[styles.guest, styles.guestTypo]}>20234544</Text>
      </View>
      <View style={styles.buttonShadowBox1}>
        <Text style={[styles.guest, styles.guestTypo]}>20225434</Text>
      </View>
      <View style={styles.buttonShadowBox}>
        <Text style={[styles.guest, styles.guestTypo]}>20234764</Text>
      </View>
      <View style={[styles.homeIndicator, styles.homeIndicatorLayout]}>
        <View style={styles.homeIndicator1} />
      </View>
      <View style={[styles.kiemtraD3Child, styles.containerPosition]} />
      <View style={[styles.iconfilter, styles.searchLayout]}>
        <View style={[styles.container, styles.searchLayout]} />
        <Image
          style={[styles.filterIcon, styles.iconLayout]}
          contentFit="cover"
          source={require("../assets/filter.png")}
        />
      </View>
      <View style={[styles.search, styles.searchLayout]}>
        <Image
          style={styles.iconLayout}
          contentFit="cover"
          source={require("../assets/search.png")}
        />
        <Text style={[styles.label, styles.labelFlexBox]} numberOfLines={1}>
          Search
        </Text>
      </View>
      <View style={[styles.statusBarIphoneXOrNewe, styles.containerPosition]}>
        <Image
          style={[styles.notchIcon, styles.iconPosition]}
          contentFit="cover"
          source={require("../assets/notch.png")}
        />
        <View style={styles.rightSide}>
          <Image
            style={styles.batteryIcon}
            contentFit="cover"
            source={require("../assets/battery.png")}
          />
          <Image
            style={styles.wifiIcon}
            contentFit="cover"
            source={require("../assets/wifi5.png")}
          />
          <Image
            style={styles.mobileSignalIcon}
            contentFit="cover"
            source={require("../assets/mobile-signal.png")}
          />
          <Image
            style={[styles.recordingIndicatorIcon, styles.iconPosition]}
            contentFit="cover"
            source={require("../assets/recording-indicator.png")}
          />
        </View>
        <Image
          style={styles.leftSideIcon}
          contentFit="cover"
          source={require("../assets/left-side.png")}
        />
      </View>
      <Header1 onTabBarItemPress={() => navigation.navigate("DanhMucQuanLy")} />
    </View>
  );
};

const styles = StyleSheet.create({
  labelFlexBox: {
    flex: 1,
    overflow: "hidden",
  },
  buttonShadowBox7: {
    paddingVertical: Padding.p_sm,
    paddingHorizontal: Padding.p_5xl,
    justifyContent: "center",
    height: 53,
    width: 294,
    borderWidth: 3,
    elevation: 2,
    shadowRadius: 2,
    shadowColor: "rgba(0, 0, 0, 0.05)",
    left: 41,
    alignItems: "center",
    flexDirection: "row",
    borderStyle: "solid",
    borderRadius: Border.br_5xs,
    position: "absolute",
    shadowOpacity: 1,
    shadowOffset: {
      width: 0,
      height: 4,
    },
    backgroundColor: Color.colorWhite,
  },
  guestTypo: {
    fontFamily: FontFamily.smallText,
    fontWeight: "500",
    lineHeight: 36,
    fontSize: FontSize.size_5xl,
    textAlign: "left",
  },
  buttonShadowBox6: {
    left: 43,
    paddingVertical: Padding.p_sm,
    paddingHorizontal: Padding.p_5xl,
    justifyContent: "center",
    alignItems: "center",
    flexDirection: "row",
    height: 53,
    width: 294,
    borderWidth: 3,
    borderColor: Color.colorLightseagreen,
    borderStyle: "solid",
    elevation: 2,
    shadowRadius: 2,
    shadowColor: "rgba(0, 0, 0, 0.05)",
    borderRadius: Border.br_5xs,
    position: "absolute",
    shadowOpacity: 1,
    shadowOffset: {
      width: 0,
      height: 4,
    },
    backgroundColor: Color.colorWhite,
  },
  homeIndicatorLayout: {
    width: 375,
    position: "absolute",
  },
  containerPosition: {
    left: 0,
    top: 0,
  },
  searchLayout: {
    height: 40,
    position: "absolute",
  },
  iconLayout: {
    height: 24,
    width: 24,
    overflow: "hidden",
  },
  iconPosition: {
    display: "none",
    position: "absolute",
  },
  guest: {
    color: Color.colorLightseagreen,
    textAlign: "left",
  },
  buttonPrimary: {
    top: 184,
    borderColor: Color.colorLightseagreen,
    paddingVertical: Padding.p_sm,
    paddingHorizontal: Padding.p_5xl,
    justifyContent: "center",
    height: 53,
    width: 294,
    borderWidth: 3,
    elevation: 2,
    shadowRadius: 2,
    shadowColor: "rgba(0, 0, 0, 0.05)",
    left: 41,
  },
  buttonPrimary1: {
    top: 267,
    borderColor: Color.colorLightseagreen,
    paddingVertical: Padding.p_sm,
    paddingHorizontal: Padding.p_5xl,
    justifyContent: "center",
    height: 53,
    width: 294,
    borderWidth: 3,
    elevation: 2,
    shadowRadius: 2,
    shadowColor: "rgba(0, 0, 0, 0.05)",
    left: 41,
  },
  buttonPrimary2: {
    top: 350,
    borderColor: Color.colorLightseagreen,
    paddingVertical: Padding.p_sm,
    paddingHorizontal: Padding.p_5xl,
    justifyContent: "center",
    height: 53,
    width: 294,
    borderWidth: 3,
    elevation: 2,
    shadowRadius: 2,
    shadowColor: "rgba(0, 0, 0, 0.05)",
    left: 41,
  },
  buttonPrimary3: {
    top: 433,
    borderColor: Color.colorLightseagreen,
    paddingVertical: Padding.p_sm,
    paddingHorizontal: Padding.p_5xl,
    justifyContent: "center",
    height: 53,
    width: 294,
    borderWidth: 3,
    elevation: 2,
    shadowRadius: 2,
    shadowColor: "rgba(0, 0, 0, 0.05)",
    left: 41,
  },
  text3: {
    color: Color.colorSalmon,
    textAlign: "left",
  },
  buttonPrimary4: {
    top: 516,
    borderColor: Color.colorSalmon,
    paddingVertical: Padding.p_sm,
    paddingHorizontal: Padding.p_5xl,
    justifyContent: "center",
    height: 53,
    width: 294,
    borderWidth: 3,
    elevation: 2,
    shadowRadius: 2,
    shadowColor: "rgba(0, 0, 0, 0.05)",
    left: 41,
  },
  buttonPrimary5: {
    top: 1428,
  },
  buttonPrimary6: {
    top: 1511,
  },
  buttonPrimary7: {
    top: 1594,
  },
  buttonShadowBox5: {
    top: 1677,
    left: 43,
    paddingVertical: Padding.p_sm,
    paddingHorizontal: Padding.p_5xl,
    justifyContent: "center",
    alignItems: "center",
    flexDirection: "row",
    height: 53,
    width: 294,
    borderWidth: 3,
    borderColor: Color.colorLightseagreen,
    borderStyle: "solid",
    elevation: 2,
    shadowRadius: 2,
    shadowColor: "rgba(0, 0, 0, 0.05)",
    borderRadius: Border.br_5xs,
    position: "absolute",
    shadowOpacity: 1,
    shadowOffset: {
      width: 0,
      height: 4,
    },
    backgroundColor: Color.colorWhite,
  },
  buttonPrimary9: {
    top: 1013,
    borderColor: Color.colorLightseagreen,
    paddingVertical: Padding.p_sm,
    paddingHorizontal: Padding.p_5xl,
    justifyContent: "center",
    height: 53,
    width: 294,
    borderWidth: 3,
    elevation: 2,
    shadowRadius: 2,
    shadowColor: "rgba(0, 0, 0, 0.05)",
    left: 41,
  },
  buttonPrimary10: {
    top: 1096,
    borderColor: Color.colorLightseagreen,
    paddingVertical: Padding.p_sm,
    paddingHorizontal: Padding.p_5xl,
    justifyContent: "center",
    height: 53,
    width: 294,
    borderWidth: 3,
    elevation: 2,
    shadowRadius: 2,
    shadowColor: "rgba(0, 0, 0, 0.05)",
    left: 41,
  },
  buttonPrimary11: {
    top: 1179,
    borderColor: Color.colorLightseagreen,
    paddingVertical: Padding.p_sm,
    paddingHorizontal: Padding.p_5xl,
    justifyContent: "center",
    height: 53,
    width: 294,
    borderWidth: 3,
    elevation: 2,
    shadowRadius: 2,
    shadowColor: "rgba(0, 0, 0, 0.05)",
    left: 41,
  },
  buttonPrimary12: {
    top: 1262,
    borderColor: Color.colorLightseagreen,
    paddingVertical: Padding.p_sm,
    paddingHorizontal: Padding.p_5xl,
    justifyContent: "center",
    height: 53,
    width: 294,
    borderWidth: 3,
    elevation: 2,
    shadowRadius: 2,
    shadowColor: "rgba(0, 0, 0, 0.05)",
    left: 41,
  },
  buttonPrimary13: {
    top: 1345,
    borderColor: Color.colorLightseagreen,
    paddingVertical: Padding.p_sm,
    paddingHorizontal: Padding.p_5xl,
    justifyContent: "center",
    height: 53,
    width: 294,
    borderWidth: 3,
    elevation: 2,
    shadowRadius: 2,
    shadowColor: "rgba(0, 0, 0, 0.05)",
    left: 41,
  },
  buttonPrimary14: {
    top: 599,
    borderColor: Color.colorLightseagreen,
    paddingVertical: Padding.p_sm,
    paddingHorizontal: Padding.p_5xl,
    justifyContent: "center",
    height: 53,
    width: 294,
    borderWidth: 3,
    elevation: 2,
    shadowRadius: 2,
    shadowColor: "rgba(0, 0, 0, 0.05)",
    left: 41,
  },
  buttonPrimary15: {
    top: 682,
    borderColor: Color.colorLightseagreen,
    paddingVertical: Padding.p_sm,
    paddingHorizontal: Padding.p_5xl,
    justifyContent: "center",
    height: 53,
    width: 294,
    borderWidth: 3,
    elevation: 2,
    shadowRadius: 2,
    shadowColor: "rgba(0, 0, 0, 0.05)",
    left: 41,
  },
  buttonPrimary16: {
    top: 765,
    borderColor: Color.colorLightseagreen,
    paddingVertical: Padding.p_sm,
    paddingHorizontal: Padding.p_5xl,
    justifyContent: "center",
    height: 53,
    width: 294,
    borderWidth: 3,
    elevation: 2,
    shadowRadius: 2,
    shadowColor: "rgba(0, 0, 0, 0.05)",
    left: 41,
  },
  buttonPrimary17: {
    top: 848,
    borderColor: Color.colorLightseagreen,
    paddingVertical: Padding.p_sm,
    paddingHorizontal: Padding.p_5xl,
    justifyContent: "center",
    height: 53,
    width: 294,
    borderWidth: 3,
    elevation: 2,
    shadowRadius: 2,
    shadowColor: "rgba(0, 0, 0, 0.05)",
    left: 41,
  },
  buttonPrimary18: {
    top: 931,
    borderColor: Color.colorLightseagreen,
    paddingVertical: Padding.p_sm,
    paddingHorizontal: Padding.p_5xl,
    justifyContent: "center",
    height: 53,
    width: 294,
    borderWidth: 3,
    elevation: 2,
    shadowRadius: 2,
    shadowColor: "rgba(0, 0, 0, 0.05)",
    left: 41,
  },
  buttonShadowBox4: {
    left: 39,
    top: 1760,
    paddingVertical: Padding.p_sm,
    paddingHorizontal: Padding.p_5xl,
    justifyContent: "center",
    alignItems: "center",
    flexDirection: "row",
    height: 53,
    width: 294,
    borderWidth: 3,
    borderColor: Color.colorLightseagreen,
    borderStyle: "solid",
    elevation: 2,
    shadowRadius: 2,
    shadowColor: "rgba(0, 0, 0, 0.05)",
    borderRadius: Border.br_5xs,
    position: "absolute",
    shadowOpacity: 1,
    shadowOffset: {
      width: 0,
      height: 4,
    },
    backgroundColor: Color.colorWhite,
  },
  buttonShadowBox3: {
    top: 1843,
    left: 39,
    paddingVertical: Padding.p_sm,
    paddingHorizontal: Padding.p_5xl,
    justifyContent: "center",
    alignItems: "center",
    flexDirection: "row",
    height: 53,
    width: 294,
    borderWidth: 3,
    borderColor: Color.colorLightseagreen,
    borderStyle: "solid",
    elevation: 2,
    shadowRadius: 2,
    shadowColor: "rgba(0, 0, 0, 0.05)",
    borderRadius: Border.br_5xs,
    position: "absolute",
    shadowOpacity: 1,
    shadowOffset: {
      width: 0,
      height: 4,
    },
    backgroundColor: Color.colorWhite,
  },
  buttonShadowBox2: {
    top: 1926,
    left: 39,
    paddingVertical: Padding.p_sm,
    paddingHorizontal: Padding.p_5xl,
    justifyContent: "center",
    alignItems: "center",
    flexDirection: "row",
    height: 53,
    width: 294,
    borderWidth: 3,
    borderColor: Color.colorLightseagreen,
    borderStyle: "solid",
    elevation: 2,
    shadowRadius: 2,
    shadowColor: "rgba(0, 0, 0, 0.05)",
    borderRadius: Border.br_5xs,
    position: "absolute",
    shadowOpacity: 1,
    shadowOffset: {
      width: 0,
      height: 4,
    },
    backgroundColor: Color.colorWhite,
  },
  buttonShadowBox1: {
    top: 2009,
    left: 39,
    paddingVertical: Padding.p_sm,
    paddingHorizontal: Padding.p_5xl,
    justifyContent: "center",
    alignItems: "center",
    flexDirection: "row",
    height: 53,
    width: 294,
    borderWidth: 3,
    borderColor: Color.colorLightseagreen,
    borderStyle: "solid",
    elevation: 2,
    shadowRadius: 2,
    shadowColor: "rgba(0, 0, 0, 0.05)",
    borderRadius: Border.br_5xs,
    position: "absolute",
    shadowOpacity: 1,
    shadowOffset: {
      width: 0,
      height: 4,
    },
    backgroundColor: Color.colorWhite,
  },
  buttonShadowBox: {
    top: 2092,
    left: 39,
    paddingVertical: Padding.p_sm,
    paddingHorizontal: Padding.p_5xl,
    justifyContent: "center",
    alignItems: "center",
    flexDirection: "row",
    height: 53,
    width: 294,
    borderWidth: 3,
    borderColor: Color.colorLightseagreen,
    borderStyle: "solid",
    elevation: 2,
    shadowRadius: 2,
    shadowColor: "rgba(0, 0, 0, 0.05)",
    borderRadius: Border.br_5xs,
    position: "absolute",
    shadowOpacity: 1,
    shadowOffset: {
      width: 0,
      height: 4,
    },
    backgroundColor: Color.colorWhite,
  },
  homeIndicator1: {
    marginLeft: -66.5,
    bottom: 8,
    borderRadius: Border.br_81xl,
    backgroundColor: Color.colorBlack,
    width: 134,
    height: 5,
    left: "50%",
    position: "absolute",
  },
  homeIndicator: {
    marginLeft: -187.5,
    bottom: 0,
    height: 34,
    left: "50%",
    backgroundColor: Color.colorWhite,
    width: 375,
  },
  kiemtraD3Child: {
    height: 164,
    width: 375,
    position: "absolute",
    backgroundColor: Color.colorWhite,
  },
  container: {
    backgroundColor: Color.colorWhitesmoke_100,
    width: 40,
    height: 40,
    left: 0,
    top: 0,
    borderRadius: Border.br_5xs,
  },
  filterIcon: {
    top: 8,
    left: 8,
    position: "absolute",
  },
  iconfilter: {
    left: 319,
    width: 40,
    height: 40,
    top: 104,
  },
  label: {
    fontSize: FontSize.presetsBody2_size,
    lineHeight: 24,
    fontFamily: FontFamily.presetsBody2,
    color: Color.colorGray,
    marginLeft: 12,
    textAlign: "left",
    overflow: "hidden",
  },
  search: {
    left: 16,
    borderColor: Color.colorGainsboro_200,
    borderWidth: 1,
    width: 295,
    paddingLeft: Padding.p_xs,
    paddingTop: Padding.p_5xs,
    paddingRight: Padding.p_base,
    paddingBottom: Padding.p_5xs,
    top: 104,
    height: 40,
    alignItems: "center",
    flexDirection: "row",
    borderStyle: "solid",
    borderRadius: Border.br_5xs,
    backgroundColor: Color.colorWhite,
  },
  notchIcon: {
    top: -2,
    right: 78,
    bottom: 16,
    left: 78,
    maxWidth: "100%",
    maxHeight: "100%",
    overflow: "hidden",
  },
  batteryIcon: {
    right: 0,
    height: 11,
    width: 24,
    top: 0,
    position: "absolute",
  },
  wifiIcon: {
    width: 15,
    height: 11,
  },
  mobileSignalIcon: {
    width: 17,
    height: 11,
  },
  recordingIndicatorIcon: {
    top: -9,
    right: 56,
    width: 6,
    height: 6,
  },
  rightSide: {
    top: 17,
    right: 15,
    width: 67,
    height: 11,
    position: "absolute",
  },
  leftSideIcon: {
    top: 12,
    left: 21,
    width: 54,
    height: 21,
    position: "absolute",
  },
  statusBarIphoneXOrNewe: {
    height: 44,
    width: 375,
    position: "absolute",
    overflow: "hidden",
  },
  kiemtraD3: {
    shadowColor: "rgba(0, 0, 0, 0.25)",
    shadowRadius: 4,
    elevation: 4,
    width: "100%",
    height: 2249,
    overflow: "hidden",
    shadowOpacity: 1,
    shadowOffset: {
      width: 0,
      height: 4,
    },
    flex: 1,
    backgroundColor: Color.colorWhite,
  },
});

export default KiemtraD;

import * as React from "react";
import { StyleSheet, View, Pressable, Text } from "react-native";
import { Image } from "expo-image";
import { StackNavigationProp } from "@react-navigation/stack";
import { useNavigation, ParamListBase } from "@react-navigation/native";
import Content from "../components/Content";
import { Color, FontFamily, Border, FontSize } from "../GlobalStyles";

const SignInQuanLy = () => {
  const navigation = useNavigation<StackNavigationProp<ParamListBase>>();

  return (
    <View style={styles.signInQuanLy}>
      <View style={[styles.homeIndicator, styles.homePosition]}>
        <View style={[styles.homeIndicator1, styles.homePosition]} />
      </View>
      <Content onButtonPress={() => navigation.navigate("DanhMucQuanLy")} />
      <Pressable
        style={[styles.screenshot202404071527531, styles.dividerPosition]}
        onPress={() => navigation.navigate("RememberQuanLy")}
      >
        <Image
          style={styles.icon}
          contentFit="cover"
          source={require("../assets/screenshot-20240407-152753-1.png")}
        />
      </Pressable>
      <Text style={[styles.rememberMe, styles.rememberMeLayout]}>
        Remember me
      </Text>
      <View style={[styles.divider, styles.dividerPosition]}>
        <View style={styles.dividerLayout} />
        <Text style={[styles.chMt, styles.chMtClr]}>
          Chú ý: Mật khẩu trên ctt-sis.hust.edu.vn
        </Text>
        <View style={[styles.divider2, styles.dividerLayout]} />
      </View>
      <Pressable
        style={[styles.hustParking, styles.homePosition]}
        onPress={() => navigation.navigate("XinChaoQuyKhach")}
      >
        <Text style={styles.hustParking1}>Hust Parking</Text>
      </Pressable>
      <View style={[styles.statusBarIphoneXOrNewe, styles.batteryIconPosition]}>
        <Image
          style={[styles.notchIcon, styles.iconPosition]}
          contentFit="cover"
          source={require("../assets/notch.png")}
        />
        <View style={styles.rightSide}>
          <Image
            style={[styles.batteryIcon, styles.batteryIconPosition]}
            contentFit="cover"
            source={require("../assets/battery.png")}
          />
          <Image
            style={styles.wifiIcon}
            contentFit="cover"
            source={require("../assets/wifi1.png")}
          />
          <Image
            style={styles.mobileSignalIcon}
            contentFit="cover"
            source={require("../assets/mobile-signal.png")}
          />
          <Image
            style={[styles.recordingIndicatorIcon, styles.iconPosition]}
            contentFit="cover"
            source={require("../assets/recording-indicator.png")}
          />
        </View>
        <Image
          style={[styles.leftSideIcon, styles.rememberMeLayout]}
          contentFit="cover"
          source={require("../assets/left-side1.png")}
        />
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  homePosition: {
    left: "50%",
    position: "absolute",
  },
  dividerPosition: {
    left: 24,
    position: "absolute",
  },
  rememberMeLayout: {
    height: 21,
    position: "absolute",
  },
  chMtClr: {
    color: Color.colorSalmon,
    fontFamily: FontFamily.presetsBody2,
  },
  dividerLayout: {
    height: 1,
    backgroundColor: Color.colorSalmon,
    flex: 1,
  },
  batteryIconPosition: {
    top: 0,
    position: "absolute",
  },
  iconPosition: {
    display: "none",
    position: "absolute",
  },
  homeIndicator1: {
    marginLeft: -66.5,
    bottom: 8,
    borderRadius: Border.br_81xl,
    backgroundColor: Color.colorBlack,
    width: 134,
    height: 5,
  },
  homeIndicator: {
    marginLeft: -187.5,
    bottom: 0,
    height: 34,
    width: 375,
  },
  icon: {
    height: "100%",
    width: "100%",
  },
  screenshot202404071527531: {
    top: 533,
    width: 38,
    height: 38,
  },
  rememberMe: {
    top: 542,
    left: 76,
    fontSize: FontSize.size_xl,
    lineHeight: 28,
    textAlign: "left",
    width: 150,
    color: Color.colorSalmon,
    fontFamily: FontFamily.presetsBody2,
  },
  chMt: {
    fontSize: FontSize.size_sm,
    lineHeight: 20,
    marginLeft: 8,
    textAlign: "center",
  },
  divider2: {
    marginLeft: 8,
  },
  divider: {
    top: 641,
    width: 327,
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
  },
  hustParking1: {
    marginLeft: -73.5,
    fontSize: FontSize.size_5xl,
    letterSpacing: -0.2,
    lineHeight: 36,
    fontWeight: "600",
    fontFamily: FontFamily.interSemiBold,
    color: Color.colorRed,
    textAlign: "center",
  },
  hustParking: {
    top: 251,
  },
  notchIcon: {
    top: -2,
    right: 78,
    bottom: 16,
    left: 78,
    maxWidth: "100%",
    maxHeight: "100%",
    overflow: "hidden",
  },
  batteryIcon: {
    right: 0,
    width: 24,
    height: 11,
  },
  wifiIcon: {
    width: 15,
    height: 11,
  },
  mobileSignalIcon: {
    width: 17,
    height: 11,
  },
  recordingIndicatorIcon: {
    top: -9,
    right: 56,
    width: 6,
    height: 6,
  },
  rightSide: {
    top: 17,
    right: 15,
    width: 67,
    height: 11,
    position: "absolute",
  },
  leftSideIcon: {
    top: 12,
    left: 21,
    width: 54,
  },
  statusBarIphoneXOrNewe: {
    left: 0,
    height: 44,
    width: 375,
    overflow: "hidden",
  },
  signInQuanLy: {
    backgroundColor: Color.colorWhite,
    height: 812,
    overflow: "hidden",
    width: "100%",
    flex: 1,
  },
});

export default SignInQuanLy;

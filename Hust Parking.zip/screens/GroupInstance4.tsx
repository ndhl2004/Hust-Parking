import * as React from "react";
import { Text, StyleSheet, View, Pressable } from "react-native";
import { Image } from "expo-image";
import { StackNavigationProp } from "@react-navigation/stack";
import { useNavigation, ParamListBase } from "@react-navigation/native";
import { Color, FontFamily, FontSize, Border, Padding } from "../GlobalStyles";

const GroupInstance4 = () => {
  const navigation = useNavigation<StackNavigationProp<ParamListBase>>();

  return (
    <View style={styles.profile2Parent}>
      <View style={[styles.profile2, styles.headerBg]}>
        <Pressable
          style={styles.buttonPrimary}
          onPress={() => navigation.navigate("C1B")}
        >
          <Text style={styles.honThnh}>Hoàn thành</Text>
        </Pressable>
        <View style={styles.homeIndicator}>
          <View style={[styles.homeIndicator1, styles.d7Position]} />
        </View>
        <View style={[styles.header, styles.headerPosition]}>
          <Pressable
            style={[styles.iconchevronLeft, styles.batteryIconLayout]}
            onPress={() => navigation.navigate("C1")}
          >
            <Image
              style={[styles.icon, styles.iconLayout1]}
              contentFit="cover"
              source={require("../assets/iconchevron-left1.png")}
            />
          </Pressable>
          <Text style={[styles.d7, styles.d7Typo]}>C1</Text>
        </View>
        <View style={[styles.statusBarIphoneXOrNewe, styles.tmChTrngLayout]}>
          <Image
            style={[styles.notchIcon, styles.iconPosition]}
            contentFit="cover"
            source={require("../assets/notch.png")}
          />
          <View style={styles.rightSide}>
            <Image
              style={[styles.batteryIcon, styles.batteryIconLayout]}
              contentFit="cover"
              source={require("../assets/battery.png")}
            />
            <Image
              style={styles.wifiIcon}
              contentFit="cover"
              source={require("../assets/wifi6.png")}
            />
            <Image
              style={styles.mobileSignalIcon}
              contentFit="cover"
              source={require("../assets/mobile-signal.png")}
            />
            <Image
              style={[styles.recordingIndicatorIcon, styles.iconPosition]}
              contentFit="cover"
              source={require("../assets/recording-indicator.png")}
            />
          </View>
          <Image
            style={styles.leftSideIcon}
            contentFit="cover"
            source={require("../assets/left-side.png")}
          />
        </View>
        <Image
          style={[styles.icon1, styles.iconLayout]}
          contentFit="cover"
          source={require("../assets/1494899200-1.png")}
        />
        <Text style={[styles.tmChTrng, styles.tmChTrngLayout]}>
          Tìm chỗ trống...
        </Text>
        <Image
          style={[styles.icon2, styles.iconLayout]}
          contentFit="cover"
          source={require("../assets/1494899200-2.png")}
        />
        <View style={[styles.profile2Child, styles.profile2Layout]} />
        <View style={[styles.profile2Item, styles.profile2Layout]} />
        <View style={styles.ellipseParent}>
          <Image
            style={styles.frameChild}
            contentFit="cover"
            source={require("../assets/ellipse-1.png")}
          />
          <Image
            style={styles.images1Icon}
            contentFit="cover"
            source={require("../assets/images-1.png")}
          />
        </View>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  headerBg: {
    backgroundColor: Color.colorWhite,
    position: "absolute",
  },
  d7Position: {
    left: "50%",
    position: "absolute",
  },
  headerPosition: {
    left: 0,
    width: 375,
    overflow: "hidden",
  },
  batteryIconLayout: {
    width: 24,
    position: "absolute",
  },
  iconLayout1: {
    height: "100%",
    width: "100%",
  },
  d7Typo: {
    textAlign: "center",
    color: Color.colorCrimson,
    fontFamily: FontFamily.interSemiBold,
    fontWeight: "600",
    lineHeight: 34,
    letterSpacing: -0.5,
    fontSize: FontSize.size_5xl,
  },
  tmChTrngLayout: {
    height: 44,
    position: "absolute",
  },
  iconPosition: {
    display: "none",
    position: "absolute",
  },
  iconLayout: {
    height: 176,
    width: 186,
    borderRadius: Border.br_7xs,
    top: 336,
    position: "absolute",
  },
  profile2Layout: {
    height: 283,
    width: 21,
    top: 307,
    position: "absolute",
  },
  honThnh: {
    lineHeight: 36,
    fontWeight: "500",
    fontFamily: FontFamily.smallText,
    color: Color.colorWhite,
    textAlign: "left",
    fontSize: FontSize.size_5xl,
  },
  buttonPrimary: {
    top: 661,
    left: 90,
    borderRadius: Border.br_5xs,
    backgroundColor: Color.colorSalmon,
    shadowColor: "rgba(0, 0, 0, 0.05)",
    shadowOffset: {
      width: 0,
      height: 1,
    },
    shadowRadius: 2,
    elevation: 2,
    shadowOpacity: 1,
    width: 196,
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    paddingHorizontal: Padding.p_5xl,
    paddingVertical: Padding.p_sm,
    position: "absolute",
  },
  homeIndicator1: {
    marginLeft: -66.5,
    bottom: 8,
    borderRadius: Border.br_81xl,
    backgroundColor: Color.colorBlack,
    width: 134,
    height: 5,
  },
  homeIndicator: {
    marginLeft: -187.5,
    bottom: 0,
    height: 34,
    width: 375,
    left: "50%",
    position: "absolute",
  },
  icon: {
    marginTop: -12,
  },
  iconchevronLeft: {
    left: 16,
    height: 24,
    top: "50%",
  },
  d7: {
    marginLeft: -24.5,
    marginTop: -12,
    top: "50%",
    left: "50%",
    position: "absolute",
  },
  header: {
    top: 44,
    borderStyle: "solid",
    borderColor: Color.colorGainsboro_100,
    borderBottomWidth: 0.5,
    height: 42,
    backgroundColor: Color.colorWhite,
    position: "absolute",
  },
  notchIcon: {
    top: -2,
    right: 78,
    bottom: 16,
    left: 78,
    maxWidth: "100%",
    maxHeight: "100%",
    overflow: "hidden",
  },
  batteryIcon: {
    right: 0,
    height: 11,
    top: 0,
  },
  wifiIcon: {
    width: 15,
    height: 11,
  },
  mobileSignalIcon: {
    width: 17,
    height: 11,
  },
  recordingIndicatorIcon: {
    top: -9,
    right: 56,
    width: 6,
    height: 6,
  },
  rightSide: {
    top: 17,
    right: 15,
    width: 67,
    height: 11,
    position: "absolute",
  },
  leftSideIcon: {
    top: 12,
    width: 54,
    height: 21,
    left: 21,
    position: "absolute",
  },
  statusBarIphoneXOrNewe: {
    top: 0,
    left: 0,
    width: 375,
    overflow: "hidden",
  },
  icon1: {
    left: 188,
  },
  tmChTrng: {
    top: 173,
    left: 37,
    width: 294,
    textAlign: "center",
    color: Color.colorCrimson,
    fontFamily: FontFamily.interSemiBold,
    fontWeight: "600",
    lineHeight: 34,
    letterSpacing: -0.5,
    fontSize: FontSize.size_5xl,
  },
  icon2: {
    left: 2,
  },
  profile2Child: {
    backgroundColor: Color.colorTomato_200,
    left: 21,
  },
  profile2Item: {
    left: 335,
    backgroundColor: Color.colorLimegreen,
  },
  frameChild: {
    width: 118,
    height: 118,
    zIndex: 0,
  },
  images1Icon: {
    top: 11,
    left: 7,
    width: 103,
    height: 103,
    zIndex: 1,
    position: "absolute",
  },
  ellipseParent: {
    top: 428,
    left: 129,
    width: 119,
    height: 121,
    position: "absolute",
  },
  profile2: {
    top: "0%",
    right: "0%",
    bottom: "0%",
    left: "0%",
    overflow: "hidden",
    height: "100%",
    width: "100%",
  },
  profile2Parent: {
    flex: 1,
    height: 812,
    width: "100%",
  },
});

export default GroupInstance4;

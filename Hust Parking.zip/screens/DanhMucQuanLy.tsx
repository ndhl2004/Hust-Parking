import * as React from "react";
import { Text, StyleSheet, View, Pressable } from "react-native";
import { Image } from "expo-image";
import { StackNavigationProp } from "@react-navigation/stack";
import { useNavigation, ParamListBase } from "@react-navigation/native";
import Header from "../components/Header";
import { Padding, Color, Border, FontSize, FontFamily } from "../GlobalStyles";

const DanhMucQuanLy = () => {
  const navigation = useNavigation<StackNavigationProp<ParamListBase>>();

  return (
    <View style={styles.danhMucQuanLy}>
      <Pressable
        style={[styles.pill, styles.pillFlexBox]}
        onPress={() => navigation.navigate("KiemtraTaiKhoan")}
      >
        <Text style={styles.tiKhon}>Tài khoản</Text>
      </Pressable>
      <Pressable
        style={[styles.pill1, styles.pillFlexBox]}
        onPress={() => navigation.navigate("TimBaiGuiXeKiemTra")}
      >
        <Text style={styles.tiKhon}>Nhà xe</Text>
      </Pressable>
      <View style={[styles.homeIndicator, styles.homePosition]}>
        <View style={[styles.homeIndicator1, styles.homePosition]} />
      </View>
      <Header
        onHustParkingPress={() => navigation.navigate("XinChaoQuyKhach")}
      />
      <View style={[styles.statusBarIphoneXOrNewe, styles.batteryIconPosition]}>
        <Image
          style={[styles.notchIcon, styles.iconPosition]}
          contentFit="cover"
          source={require("../assets/notch.png")}
        />
        <View style={styles.rightSide}>
          <Image
            style={[styles.batteryIcon, styles.batteryIconPosition]}
            contentFit="cover"
            source={require("../assets/battery.png")}
          />
          <Image
            style={styles.wifiIcon}
            contentFit="cover"
            source={require("../assets/wifi.png")}
          />
          <Image
            style={styles.mobileSignalIcon}
            contentFit="cover"
            source={require("../assets/mobile-signal.png")}
          />
          <Image
            style={[styles.recordingIndicatorIcon, styles.iconPosition]}
            contentFit="cover"
            source={require("../assets/recording-indicator.png")}
          />
        </View>
        <Image
          style={styles.leftSideIcon}
          contentFit="cover"
          source={require("../assets/left-side1.png")}
        />
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  pillFlexBox: {
    paddingHorizontal: Padding.p_sm,
    justifyContent: "center",
    alignItems: "center",
    flexDirection: "row",
    height: 62,
    width: 220,
    backgroundColor: Color.colorCrimson,
    borderRadius: Border.br_xl,
    left: 74,
    position: "absolute",
  },
  homePosition: {
    left: "50%",
    position: "absolute",
  },
  batteryIconPosition: {
    top: 0,
    position: "absolute",
  },
  iconPosition: {
    display: "none",
    position: "absolute",
  },
  tiKhon: {
    fontSize: FontSize.size_5xl,
    lineHeight: 34,
    fontWeight: "500",
    fontFamily: FontFamily.smallText,
    color: Color.colorWhite,
    textAlign: "left",
  },
  pill: {
    top: 450,
    paddingTop: Padding.p_7xs,
  },
  pill1: {
    top: 344,
    paddingVertical: Padding.p_7xs,
  },
  homeIndicator1: {
    marginLeft: -66.5,
    bottom: 8,
    borderRadius: Border.br_81xl,
    backgroundColor: Color.colorBlack,
    width: 134,
    height: 5,
  },
  homeIndicator: {
    marginLeft: -187.5,
    bottom: 0,
    height: 34,
    width: 375,
  },
  notchIcon: {
    top: -2,
    right: 78,
    bottom: 16,
    left: 78,
    maxWidth: "100%",
    maxHeight: "100%",
    overflow: "hidden",
  },
  batteryIcon: {
    right: 0,
    width: 24,
    height: 11,
  },
  wifiIcon: {
    width: 15,
    height: 11,
  },
  mobileSignalIcon: {
    width: 17,
    height: 11,
  },
  recordingIndicatorIcon: {
    top: -9,
    right: 56,
    width: 6,
    height: 6,
  },
  rightSide: {
    top: 17,
    right: 15,
    width: 67,
    height: 11,
    position: "absolute",
  },
  leftSideIcon: {
    top: 12,
    left: 21,
    width: 54,
    height: 21,
    position: "absolute",
  },
  statusBarIphoneXOrNewe: {
    left: 0,
    height: 44,
    width: 375,
    overflow: "hidden",
  },
  danhMucQuanLy: {
    backgroundColor: Color.colorWhite,
    flex: 1,
    width: "100%",
    height: 812,
    overflow: "hidden",
  },
});

export default DanhMucQuanLy;

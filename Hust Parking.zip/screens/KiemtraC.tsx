import * as React from "react";
import { Text, StyleSheet, View, Pressable } from "react-native";
import { Image } from "expo-image";
import { StackNavigationProp } from "@react-navigation/stack";
import { useNavigation, ParamListBase } from "@react-navigation/native";
import Header1 from "../components/Header1";
import { Padding, Color, Border, FontFamily, FontSize } from "../GlobalStyles";

const KiemtraC = () => {
  const navigation = useNavigation<StackNavigationProp<ParamListBase>>();

  return (
    <View style={[styles.kiemtraC9, styles.labelFlexBox]}>
      <Pressable
        style={[styles.buttonPrimary, styles.buttonShadowBox36]}
        onPress={() => navigation.navigate("Frame8")}
      >
        <Text style={[styles.text, styles.textTypo]}>20224424</Text>
      </Pressable>
      <View style={[styles.buttonPrimary1, styles.buttonShadowBox35]}>
        <Text style={[styles.text1, styles.textTypo]}>20204937</Text>
      </View>
      <View style={[styles.buttonPrimary2, styles.buttonShadowBox35]}>
        <Text style={[styles.text1, styles.textTypo]}>20224344</Text>
      </View>
      <View style={[styles.buttonPrimary3, styles.buttonShadowBox35]}>
        <Text style={[styles.text1, styles.textTypo]}>20225545</Text>
      </View>
      <Pressable
        style={[styles.buttonPrimary4, styles.buttonShadowBox36]}
        onPress={() => navigation.navigate("Frame9")}
      >
        <Text style={[styles.text, styles.textTypo]}>20225148</Text>
      </Pressable>
      <View style={[styles.buttonPrimary5, styles.buttonShadowBox34]}>
        <Text style={[styles.text1, styles.textTypo]}>20194534</Text>
      </View>
      <View style={[styles.buttonPrimary6, styles.buttonShadowBox34]}>
        <Text style={[styles.text1, styles.textTypo]}>20224524</Text>
      </View>
      <View style={[styles.buttonPrimary7, styles.buttonShadowBox34]}>
        <Text style={[styles.text1, styles.textTypo]}>20212344</Text>
      </View>
      <View style={styles.buttonShadowBox33}>
        <Text style={[styles.text1, styles.textTypo]}>20238324</Text>
      </View>
      <View style={[styles.buttonPrimary9, styles.buttonShadowBox35]}>
        <Text style={[styles.text1, styles.textTypo]}>20223424</Text>
      </View>
      <View style={[styles.buttonPrimary10, styles.buttonShadowBox35]}>
        <Text style={[styles.text1, styles.textTypo]}>20224224</Text>
      </View>
      <View style={[styles.buttonPrimary11, styles.buttonShadowBox35]}>
        <Text style={[styles.text1, styles.textTypo]}>20205464</Text>
      </View>
      <View style={[styles.buttonPrimary12, styles.buttonShadowBox35]}>
        <Text style={[styles.text1, styles.textTypo]}>20204924</Text>
      </View>
      <View style={[styles.buttonPrimary13, styles.buttonShadowBox35]}>
        <Text style={[styles.text1, styles.textTypo]}>20225824</Text>
      </View>
      <View style={[styles.buttonPrimary14, styles.buttonShadowBox35]}>
        <Text style={[styles.text1, styles.textTypo]}>20222333</Text>
      </View>
      <View style={[styles.buttonPrimary15, styles.buttonShadowBox35]}>
        <Text style={[styles.text1, styles.textTypo]}>20184234</Text>
      </View>
      <View style={[styles.buttonPrimary16, styles.buttonShadowBox35]}>
        <Text style={[styles.text1, styles.textTypo]}>20234544</Text>
      </View>
      <View style={[styles.buttonPrimary17, styles.buttonShadowBox35]}>
        <Text style={[styles.text1, styles.textTypo]}>20225434</Text>
      </View>
      <View style={[styles.buttonPrimary18, styles.buttonShadowBox35]}>
        <Text style={[styles.text1, styles.textTypo]}>20234764</Text>
      </View>
      <View style={styles.buttonShadowBox32}>
        <Text style={[styles.text1, styles.textTypo]}>20194534</Text>
      </View>
      <View style={styles.buttonShadowBox31}>
        <Text style={[styles.text1, styles.textTypo]}>20224524</Text>
      </View>
      <View style={styles.buttonShadowBox30}>
        <Text style={[styles.text1, styles.textTypo]}>20212344</Text>
      </View>
      <View style={styles.buttonShadowBox29}>
        <Text style={[styles.text1, styles.textTypo]}>20238324</Text>
      </View>
      <View style={[styles.buttonPrimary23, styles.buttonShadowBox28]}>
        <Text style={[styles.text1, styles.textTypo]}>20223424</Text>
      </View>
      <View style={styles.buttonShadowBox27}>
        <Text style={[styles.text1, styles.textTypo]}>20224224</Text>
      </View>
      <View style={styles.buttonShadowBox26}>
        <Text style={[styles.text1, styles.textTypo]}>20205464</Text>
      </View>
      <View style={styles.buttonShadowBox25}>
        <Text style={[styles.text1, styles.textTypo]}>20204924</Text>
      </View>
      <View style={styles.buttonShadowBox24}>
        <Text style={[styles.text1, styles.textTypo]}>20225824</Text>
      </View>
      <View style={styles.buttonShadowBox23}>
        <Text style={[styles.text1, styles.textTypo]}>20222333</Text>
      </View>
      <View style={styles.buttonShadowBox22}>
        <Text style={[styles.text1, styles.textTypo]}>20184234</Text>
      </View>
      <View style={styles.buttonShadowBox21}>
        <Text style={[styles.text1, styles.textTypo]}>20234544</Text>
      </View>
      <View style={styles.buttonShadowBox20}>
        <Text style={[styles.text1, styles.textTypo]}>20225434</Text>
      </View>
      <View style={styles.buttonShadowBox19}>
        <Text style={[styles.text1, styles.textTypo]}>20234764</Text>
      </View>
      <View style={styles.buttonShadowBox33}>
        <Text style={[styles.text1, styles.textTypo]}>20238324</Text>
      </View>
      <View style={styles.buttonShadowBox32}>
        <Text style={[styles.text1, styles.textTypo]}>20194534</Text>
      </View>
      <View style={styles.buttonShadowBox31}>
        <Text style={[styles.text1, styles.textTypo]}>20224524</Text>
      </View>
      <View style={styles.buttonShadowBox30}>
        <Text style={[styles.text1, styles.textTypo]}>20212344</Text>
      </View>
      <View style={styles.buttonShadowBox29}>
        <Text style={[styles.text1, styles.textTypo]}>20238324</Text>
      </View>
      <View style={[styles.buttonPrimary38, styles.buttonShadowBox28]}>
        <Text style={[styles.text1, styles.textTypo]}>20223424</Text>
      </View>
      <View style={styles.buttonShadowBox27}>
        <Text style={[styles.text1, styles.textTypo]}>20224224</Text>
      </View>
      <View style={styles.buttonShadowBox26}>
        <Text style={[styles.text1, styles.textTypo]}>20205464</Text>
      </View>
      <View style={styles.buttonShadowBox25}>
        <Text style={[styles.text1, styles.textTypo]}>20204924</Text>
      </View>
      <View style={styles.buttonShadowBox24}>
        <Text style={[styles.text1, styles.textTypo]}>20225824</Text>
      </View>
      <View style={styles.buttonShadowBox23}>
        <Text style={[styles.text1, styles.textTypo]}>20222333</Text>
      </View>
      <View style={styles.buttonShadowBox22}>
        <Text style={[styles.text1, styles.textTypo]}>20184234</Text>
      </View>
      <View style={styles.buttonShadowBox21}>
        <Text style={[styles.text1, styles.textTypo]}>20234544</Text>
      </View>
      <View style={styles.buttonShadowBox20}>
        <Text style={[styles.text1, styles.textTypo]}>20225434</Text>
      </View>
      <View style={styles.buttonShadowBox19}>
        <Text style={[styles.text1, styles.textTypo]}>20234764</Text>
      </View>
      <View style={styles.buttonPrimary48}>
        <Text style={[styles.text1, styles.textTypo]}>20238324</Text>
      </View>
      <View style={styles.buttonShadowBox18}>
        <Text style={[styles.text1, styles.textTypo]}>20194534</Text>
      </View>
      <View style={styles.buttonShadowBox17}>
        <Text style={[styles.text1, styles.textTypo]}>20224524</Text>
      </View>
      <View style={styles.buttonShadowBox16}>
        <Text style={[styles.text1, styles.textTypo]}>20212344</Text>
      </View>
      <View style={styles.buttonShadowBox15}>
        <Text style={[styles.text1, styles.textTypo]}>20238324</Text>
      </View>
      <View style={styles.buttonShadowBox14}>
        <Text style={[styles.text1, styles.textTypo]}>20223424</Text>
      </View>
      <View style={styles.buttonShadowBox13}>
        <Text style={[styles.text1, styles.textTypo]}>20224224</Text>
      </View>
      <View style={styles.buttonShadowBox12}>
        <Text style={[styles.text1, styles.textTypo]}>20205464</Text>
      </View>
      <View style={styles.buttonShadowBox11}>
        <Text style={[styles.text1, styles.textTypo]}>20204924</Text>
      </View>
      <View style={styles.buttonShadowBox10}>
        <Text style={[styles.text1, styles.textTypo]}>20225824</Text>
      </View>
      <View style={styles.buttonShadowBox9}>
        <Text style={[styles.text1, styles.textTypo]}>20222333</Text>
      </View>
      <View style={styles.buttonShadowBox8}>
        <Text style={[styles.text1, styles.textTypo]}>20184234</Text>
      </View>
      <View style={styles.buttonShadowBox7}>
        <Text style={[styles.text1, styles.textTypo]}>20234544</Text>
      </View>
      <View style={styles.buttonShadowBox6}>
        <Text style={[styles.text1, styles.textTypo]}>20225434</Text>
      </View>
      <View style={styles.buttonShadowBox5}>
        <Text style={[styles.text1, styles.textTypo]}>20234764</Text>
      </View>
      <View style={styles.buttonShadowBox18}>
        <Text style={[styles.text1, styles.textTypo]}>20194534</Text>
      </View>
      <View style={styles.buttonShadowBox17}>
        <Text style={[styles.text1, styles.textTypo]}>20224524</Text>
      </View>
      <View style={styles.buttonShadowBox16}>
        <Text style={[styles.text1, styles.textTypo]}>20212344</Text>
      </View>
      <View style={styles.buttonShadowBox15}>
        <Text style={[styles.text1, styles.textTypo]}>20238324</Text>
      </View>
      <View style={styles.buttonShadowBox14}>
        <Text style={[styles.text1, styles.textTypo]}>20223424</Text>
      </View>
      <View style={styles.buttonShadowBox13}>
        <Text style={[styles.text1, styles.textTypo]}>20224224</Text>
      </View>
      <View style={styles.buttonShadowBox12}>
        <Text style={[styles.text1, styles.textTypo]}>20205464</Text>
      </View>
      <View style={styles.buttonShadowBox11}>
        <Text style={[styles.text1, styles.textTypo]}>20204924</Text>
      </View>
      <View style={styles.buttonShadowBox10}>
        <Text style={[styles.text1, styles.textTypo]}>20225824</Text>
      </View>
      <View style={styles.buttonShadowBox4}>
        <Text style={[styles.text1, styles.textTypo]}>20194534</Text>
      </View>
      <View style={styles.buttonShadowBox3}>
        <Text style={[styles.text1, styles.textTypo]}>20224524</Text>
      </View>
      <View style={styles.buttonShadowBox2}>
        <Text style={[styles.text1, styles.textTypo]}>20212344</Text>
      </View>
      <View style={styles.buttonShadowBox1}>
        <Text style={[styles.text1, styles.textTypo]}>20238324</Text>
      </View>
      <View style={styles.buttonShadowBox}>
        <Text style={[styles.text1, styles.textTypo]}>20225824</Text>
      </View>
      <View style={styles.buttonShadowBox4}>
        <Text style={[styles.text1, styles.textTypo]}>20194534</Text>
      </View>
      <View style={styles.buttonShadowBox3}>
        <Text style={[styles.text1, styles.textTypo]}>20224524</Text>
      </View>
      <View style={styles.buttonShadowBox2}>
        <Text style={[styles.text1, styles.textTypo]}>20212344</Text>
      </View>
      <View style={styles.buttonShadowBox1}>
        <Text style={[styles.text1, styles.textTypo]}>20238324</Text>
      </View>
      <View style={styles.buttonShadowBox}>
        <Text style={[styles.text1, styles.textTypo]}>20225824</Text>
      </View>
      <View style={styles.buttonShadowBox9}>
        <Text style={[styles.text1, styles.textTypo]}>20222333</Text>
      </View>
      <View style={styles.buttonShadowBox8}>
        <Text style={[styles.text1, styles.textTypo]}>20184234</Text>
      </View>
      <View style={styles.buttonShadowBox7}>
        <Text style={[styles.text1, styles.textTypo]}>20234544</Text>
      </View>
      <View style={styles.buttonShadowBox6}>
        <Text style={[styles.text1, styles.textTypo]}>20225434</Text>
      </View>
      <View style={styles.buttonShadowBox5}>
        <Text style={[styles.text1, styles.textTypo]}>20234764</Text>
      </View>
      <View style={[styles.buttonPrimary87, styles.buttonShadowBox28]}>
        <Text style={[styles.text1, styles.textTypo]}>20224975</Text>
      </View>
      <View style={[styles.buttonPrimary88, styles.buttonShadowBox28]}>
        <Text style={[styles.text1, styles.textTypo]}>20234764</Text>
      </View>
      <View style={[styles.kiemtraC9Child, styles.homeIndicatorLayout]} />
      <View style={[styles.iconfilter, styles.searchLayout]}>
        <View style={[styles.container, styles.searchLayout]} />
        <Image
          style={[styles.filterIcon, styles.iconLayout]}
          contentFit="cover"
          source={require("../assets/filter.png")}
        />
      </View>
      <View style={[styles.search, styles.searchLayout]}>
        <Image
          style={styles.iconLayout}
          contentFit="cover"
          source={require("../assets/search.png")}
        />
        <Text style={[styles.label, styles.labelFlexBox]} numberOfLines={1}>
          Search
        </Text>
      </View>
      <View style={[styles.statusBarIphoneXOrNewe, styles.homeIndicatorLayout]}>
        <Image
          style={[styles.notchIcon, styles.iconPosition]}
          contentFit="cover"
          source={require("../assets/notch.png")}
        />
        <View style={styles.rightSide}>
          <Image
            style={styles.batteryIcon}
            contentFit="cover"
            source={require("../assets/battery.png")}
          />
          <Image
            style={styles.wifiIcon}
            contentFit="cover"
            source={require("../assets/wifi3.png")}
          />
          <Image
            style={styles.mobileSignalIcon}
            contentFit="cover"
            source={require("../assets/mobile-signal.png")}
          />
          <Image
            style={[styles.recordingIndicatorIcon, styles.iconPosition]}
            contentFit="cover"
            source={require("../assets/recording-indicator.png")}
          />
        </View>
        <Image
          style={styles.leftSideIcon}
          contentFit="cover"
          source={require("../assets/left-side.png")}
        />
      </View>
      <Header1 onTabBarItemPress={() => navigation.navigate("DanhMucQuanLy")} />
      <View style={[styles.homeIndicator, styles.homeIndicatorLayout]}>
        <View style={styles.homeIndicator1} />
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  labelFlexBox: {
    flex: 1,
    overflow: "hidden",
  },
  buttonShadowBox36: {
    paddingVertical: Padding.p_sm,
    paddingHorizontal: Padding.p_5xl,
    justifyContent: "center",
    height: 53,
    width: 294,
    borderWidth: 3,
    borderColor: Color.colorSalmon,
    elevation: 2,
    shadowRadius: 2,
    shadowColor: "rgba(0, 0, 0, 0.05)",
    left: 39,
    alignItems: "center",
    flexDirection: "row",
    borderStyle: "solid",
    borderRadius: Border.br_5xs,
    position: "absolute",
    shadowOpacity: 1,
    shadowOffset: {
      width: 0,
      height: 4,
    },
    backgroundColor: Color.colorWhite,
  },
  textTypo: {
    fontFamily: FontFamily.smallText,
    fontWeight: "500",
    lineHeight: 36,
    fontSize: FontSize.size_5xl,
    textAlign: "left",
  },
  buttonShadowBox35: {
    borderColor: Color.colorLightseagreen,
    paddingVertical: Padding.p_sm,
    paddingHorizontal: Padding.p_5xl,
    justifyContent: "center",
    alignItems: "center",
    flexDirection: "row",
    height: 53,
    width: 294,
    borderWidth: 3,
    borderStyle: "solid",
    elevation: 2,
    shadowRadius: 2,
    shadowColor: "rgba(0, 0, 0, 0.05)",
    borderRadius: Border.br_5xs,
    left: 39,
    position: "absolute",
    shadowOpacity: 1,
    shadowOffset: {
      width: 0,
      height: 4,
    },
    backgroundColor: Color.colorWhite,
  },
  buttonShadowBox34: {
    left: 41,
    borderColor: Color.colorLightseagreen,
    paddingVertical: Padding.p_sm,
    paddingHorizontal: Padding.p_5xl,
    justifyContent: "center",
    alignItems: "center",
    flexDirection: "row",
    height: 53,
    width: 294,
    borderWidth: 3,
    borderStyle: "solid",
    elevation: 2,
    shadowRadius: 2,
    shadowColor: "rgba(0, 0, 0, 0.05)",
    borderRadius: Border.br_5xs,
    position: "absolute",
    shadowOpacity: 1,
    shadowOffset: {
      width: 0,
      height: 4,
    },
    backgroundColor: Color.colorWhite,
  },
  buttonShadowBox28: {
    left: 37,
    borderColor: Color.colorLightseagreen,
    paddingVertical: Padding.p_sm,
    paddingHorizontal: Padding.p_5xl,
    justifyContent: "center",
    alignItems: "center",
    flexDirection: "row",
    height: 53,
    width: 294,
    borderWidth: 3,
    borderStyle: "solid",
    elevation: 2,
    shadowRadius: 2,
    shadowColor: "rgba(0, 0, 0, 0.05)",
    borderRadius: Border.br_5xs,
    position: "absolute",
    shadowOpacity: 1,
    shadowOffset: {
      width: 0,
      height: 4,
    },
    backgroundColor: Color.colorWhite,
  },
  homeIndicatorLayout: {
    width: 375,
    position: "absolute",
  },
  searchLayout: {
    height: 40,
    position: "absolute",
  },
  iconLayout: {
    height: 24,
    width: 24,
    overflow: "hidden",
  },
  iconPosition: {
    display: "none",
    position: "absolute",
  },
  text: {
    color: Color.colorSalmon,
    textAlign: "left",
  },
  buttonPrimary: {
    top: 176,
  },
  text1: {
    color: Color.colorLightseagreen,
    textAlign: "left",
  },
  buttonPrimary1: {
    top: 259,
  },
  buttonPrimary2: {
    top: 342,
  },
  buttonPrimary3: {
    top: 425,
  },
  buttonPrimary4: {
    top: 508,
  },
  buttonPrimary5: {
    top: 1420,
  },
  buttonPrimary6: {
    top: 1503,
  },
  buttonPrimary7: {
    top: 1586,
  },
  buttonShadowBox33: {
    top: 1669,
    left: 41,
    borderColor: Color.colorLightseagreen,
    paddingVertical: Padding.p_sm,
    paddingHorizontal: Padding.p_5xl,
    justifyContent: "center",
    alignItems: "center",
    flexDirection: "row",
    height: 53,
    width: 294,
    borderWidth: 3,
    borderStyle: "solid",
    elevation: 2,
    shadowRadius: 2,
    shadowColor: "rgba(0, 0, 0, 0.05)",
    borderRadius: Border.br_5xs,
    position: "absolute",
    shadowOpacity: 1,
    shadowOffset: {
      width: 0,
      height: 4,
    },
    backgroundColor: Color.colorWhite,
  },
  buttonPrimary9: {
    top: 1005,
  },
  buttonPrimary10: {
    top: 1088,
  },
  buttonPrimary11: {
    top: 1171,
  },
  buttonPrimary12: {
    top: 1254,
  },
  buttonPrimary13: {
    top: 1337,
  },
  buttonPrimary14: {
    top: 591,
  },
  buttonPrimary15: {
    top: 674,
  },
  buttonPrimary16: {
    top: 757,
  },
  buttonPrimary17: {
    top: 840,
  },
  buttonPrimary18: {
    top: 923,
  },
  buttonShadowBox32: {
    top: 2581,
    borderColor: Color.colorLightseagreen,
    paddingVertical: Padding.p_sm,
    paddingHorizontal: Padding.p_5xl,
    justifyContent: "center",
    alignItems: "center",
    flexDirection: "row",
    height: 53,
    width: 294,
    borderWidth: 3,
    borderStyle: "solid",
    elevation: 2,
    shadowRadius: 2,
    shadowColor: "rgba(0, 0, 0, 0.05)",
    borderRadius: Border.br_5xs,
    left: 39,
    position: "absolute",
    shadowOpacity: 1,
    shadowOffset: {
      width: 0,
      height: 4,
    },
    backgroundColor: Color.colorWhite,
  },
  buttonShadowBox31: {
    top: 2664,
    borderColor: Color.colorLightseagreen,
    paddingVertical: Padding.p_sm,
    paddingHorizontal: Padding.p_5xl,
    justifyContent: "center",
    alignItems: "center",
    flexDirection: "row",
    height: 53,
    width: 294,
    borderWidth: 3,
    borderStyle: "solid",
    elevation: 2,
    shadowRadius: 2,
    shadowColor: "rgba(0, 0, 0, 0.05)",
    borderRadius: Border.br_5xs,
    left: 39,
    position: "absolute",
    shadowOpacity: 1,
    shadowOffset: {
      width: 0,
      height: 4,
    },
    backgroundColor: Color.colorWhite,
  },
  buttonShadowBox30: {
    top: 2747,
    borderColor: Color.colorLightseagreen,
    paddingVertical: Padding.p_sm,
    paddingHorizontal: Padding.p_5xl,
    justifyContent: "center",
    alignItems: "center",
    flexDirection: "row",
    height: 53,
    width: 294,
    borderWidth: 3,
    borderStyle: "solid",
    elevation: 2,
    shadowRadius: 2,
    shadowColor: "rgba(0, 0, 0, 0.05)",
    borderRadius: Border.br_5xs,
    left: 39,
    position: "absolute",
    shadowOpacity: 1,
    shadowOffset: {
      width: 0,
      height: 4,
    },
    backgroundColor: Color.colorWhite,
  },
  buttonShadowBox29: {
    top: 2830,
    borderColor: Color.colorLightseagreen,
    paddingVertical: Padding.p_sm,
    paddingHorizontal: Padding.p_5xl,
    justifyContent: "center",
    alignItems: "center",
    flexDirection: "row",
    height: 53,
    width: 294,
    borderWidth: 3,
    borderStyle: "solid",
    elevation: 2,
    shadowRadius: 2,
    shadowColor: "rgba(0, 0, 0, 0.05)",
    borderRadius: Border.br_5xs,
    left: 39,
    position: "absolute",
    shadowOpacity: 1,
    shadowOffset: {
      width: 0,
      height: 4,
    },
    backgroundColor: Color.colorWhite,
  },
  buttonPrimary23: {
    top: 2166,
    left: 37,
  },
  buttonShadowBox27: {
    top: 2249,
    left: 37,
    borderColor: Color.colorLightseagreen,
    paddingVertical: Padding.p_sm,
    paddingHorizontal: Padding.p_5xl,
    justifyContent: "center",
    alignItems: "center",
    flexDirection: "row",
    height: 53,
    width: 294,
    borderWidth: 3,
    borderStyle: "solid",
    elevation: 2,
    shadowRadius: 2,
    shadowColor: "rgba(0, 0, 0, 0.05)",
    borderRadius: Border.br_5xs,
    position: "absolute",
    shadowOpacity: 1,
    shadowOffset: {
      width: 0,
      height: 4,
    },
    backgroundColor: Color.colorWhite,
  },
  buttonShadowBox26: {
    top: 2332,
    left: 37,
    borderColor: Color.colorLightseagreen,
    paddingVertical: Padding.p_sm,
    paddingHorizontal: Padding.p_5xl,
    justifyContent: "center",
    alignItems: "center",
    flexDirection: "row",
    height: 53,
    width: 294,
    borderWidth: 3,
    borderStyle: "solid",
    elevation: 2,
    shadowRadius: 2,
    shadowColor: "rgba(0, 0, 0, 0.05)",
    borderRadius: Border.br_5xs,
    position: "absolute",
    shadowOpacity: 1,
    shadowOffset: {
      width: 0,
      height: 4,
    },
    backgroundColor: Color.colorWhite,
  },
  buttonShadowBox25: {
    top: 2415,
    left: 37,
    borderColor: Color.colorLightseagreen,
    paddingVertical: Padding.p_sm,
    paddingHorizontal: Padding.p_5xl,
    justifyContent: "center",
    alignItems: "center",
    flexDirection: "row",
    height: 53,
    width: 294,
    borderWidth: 3,
    borderStyle: "solid",
    elevation: 2,
    shadowRadius: 2,
    shadowColor: "rgba(0, 0, 0, 0.05)",
    borderRadius: Border.br_5xs,
    position: "absolute",
    shadowOpacity: 1,
    shadowOffset: {
      width: 0,
      height: 4,
    },
    backgroundColor: Color.colorWhite,
  },
  buttonShadowBox24: {
    top: 2498,
    left: 37,
    borderColor: Color.colorLightseagreen,
    paddingVertical: Padding.p_sm,
    paddingHorizontal: Padding.p_5xl,
    justifyContent: "center",
    alignItems: "center",
    flexDirection: "row",
    height: 53,
    width: 294,
    borderWidth: 3,
    borderStyle: "solid",
    elevation: 2,
    shadowRadius: 2,
    shadowColor: "rgba(0, 0, 0, 0.05)",
    borderRadius: Border.br_5xs,
    position: "absolute",
    shadowOpacity: 1,
    shadowOffset: {
      width: 0,
      height: 4,
    },
    backgroundColor: Color.colorWhite,
  },
  buttonShadowBox23: {
    top: 1752,
    left: 37,
    borderColor: Color.colorLightseagreen,
    paddingVertical: Padding.p_sm,
    paddingHorizontal: Padding.p_5xl,
    justifyContent: "center",
    alignItems: "center",
    flexDirection: "row",
    height: 53,
    width: 294,
    borderWidth: 3,
    borderStyle: "solid",
    elevation: 2,
    shadowRadius: 2,
    shadowColor: "rgba(0, 0, 0, 0.05)",
    borderRadius: Border.br_5xs,
    position: "absolute",
    shadowOpacity: 1,
    shadowOffset: {
      width: 0,
      height: 4,
    },
    backgroundColor: Color.colorWhite,
  },
  buttonShadowBox22: {
    top: 1835,
    left: 37,
    borderColor: Color.colorLightseagreen,
    paddingVertical: Padding.p_sm,
    paddingHorizontal: Padding.p_5xl,
    justifyContent: "center",
    alignItems: "center",
    flexDirection: "row",
    height: 53,
    width: 294,
    borderWidth: 3,
    borderStyle: "solid",
    elevation: 2,
    shadowRadius: 2,
    shadowColor: "rgba(0, 0, 0, 0.05)",
    borderRadius: Border.br_5xs,
    position: "absolute",
    shadowOpacity: 1,
    shadowOffset: {
      width: 0,
      height: 4,
    },
    backgroundColor: Color.colorWhite,
  },
  buttonShadowBox21: {
    top: 1918,
    left: 37,
    borderColor: Color.colorLightseagreen,
    paddingVertical: Padding.p_sm,
    paddingHorizontal: Padding.p_5xl,
    justifyContent: "center",
    alignItems: "center",
    flexDirection: "row",
    height: 53,
    width: 294,
    borderWidth: 3,
    borderStyle: "solid",
    elevation: 2,
    shadowRadius: 2,
    shadowColor: "rgba(0, 0, 0, 0.05)",
    borderRadius: Border.br_5xs,
    position: "absolute",
    shadowOpacity: 1,
    shadowOffset: {
      width: 0,
      height: 4,
    },
    backgroundColor: Color.colorWhite,
  },
  buttonShadowBox20: {
    top: 2001,
    left: 37,
    borderColor: Color.colorLightseagreen,
    paddingVertical: Padding.p_sm,
    paddingHorizontal: Padding.p_5xl,
    justifyContent: "center",
    alignItems: "center",
    flexDirection: "row",
    height: 53,
    width: 294,
    borderWidth: 3,
    borderStyle: "solid",
    elevation: 2,
    shadowRadius: 2,
    shadowColor: "rgba(0, 0, 0, 0.05)",
    borderRadius: Border.br_5xs,
    position: "absolute",
    shadowOpacity: 1,
    shadowOffset: {
      width: 0,
      height: 4,
    },
    backgroundColor: Color.colorWhite,
  },
  buttonShadowBox19: {
    top: 2084,
    left: 37,
    borderColor: Color.colorLightseagreen,
    paddingVertical: Padding.p_sm,
    paddingHorizontal: Padding.p_5xl,
    justifyContent: "center",
    alignItems: "center",
    flexDirection: "row",
    height: 53,
    width: 294,
    borderWidth: 3,
    borderStyle: "solid",
    elevation: 2,
    shadowRadius: 2,
    shadowColor: "rgba(0, 0, 0, 0.05)",
    borderRadius: Border.br_5xs,
    position: "absolute",
    shadowOpacity: 1,
    shadowOffset: {
      width: 0,
      height: 4,
    },
    backgroundColor: Color.colorWhite,
  },
  buttonPrimary38: {
    top: 2166,
    left: 37,
  },
  buttonPrimary48: {
    top: 2913,
    left: 35,
    borderColor: Color.colorLightseagreen,
    paddingVertical: Padding.p_sm,
    paddingHorizontal: Padding.p_5xl,
    justifyContent: "center",
    alignItems: "center",
    flexDirection: "row",
    height: 53,
    width: 294,
    borderWidth: 3,
    borderStyle: "solid",
    elevation: 2,
    shadowRadius: 2,
    shadowColor: "rgba(0, 0, 0, 0.05)",
    borderRadius: Border.br_5xs,
    position: "absolute",
    shadowOpacity: 1,
    shadowOffset: {
      width: 0,
      height: 4,
    },
    backgroundColor: Color.colorWhite,
  },
  buttonShadowBox18: {
    top: 3825,
    left: 37,
    borderColor: Color.colorLightseagreen,
    paddingVertical: Padding.p_sm,
    paddingHorizontal: Padding.p_5xl,
    justifyContent: "center",
    alignItems: "center",
    flexDirection: "row",
    height: 53,
    width: 294,
    borderWidth: 3,
    borderStyle: "solid",
    elevation: 2,
    shadowRadius: 2,
    shadowColor: "rgba(0, 0, 0, 0.05)",
    borderRadius: Border.br_5xs,
    position: "absolute",
    shadowOpacity: 1,
    shadowOffset: {
      width: 0,
      height: 4,
    },
    backgroundColor: Color.colorWhite,
  },
  buttonShadowBox17: {
    top: 3908,
    left: 37,
    borderColor: Color.colorLightseagreen,
    paddingVertical: Padding.p_sm,
    paddingHorizontal: Padding.p_5xl,
    justifyContent: "center",
    alignItems: "center",
    flexDirection: "row",
    height: 53,
    width: 294,
    borderWidth: 3,
    borderStyle: "solid",
    elevation: 2,
    shadowRadius: 2,
    shadowColor: "rgba(0, 0, 0, 0.05)",
    borderRadius: Border.br_5xs,
    position: "absolute",
    shadowOpacity: 1,
    shadowOffset: {
      width: 0,
      height: 4,
    },
    backgroundColor: Color.colorWhite,
  },
  buttonShadowBox16: {
    top: 3991,
    left: 37,
    borderColor: Color.colorLightseagreen,
    paddingVertical: Padding.p_sm,
    paddingHorizontal: Padding.p_5xl,
    justifyContent: "center",
    alignItems: "center",
    flexDirection: "row",
    height: 53,
    width: 294,
    borderWidth: 3,
    borderStyle: "solid",
    elevation: 2,
    shadowRadius: 2,
    shadowColor: "rgba(0, 0, 0, 0.05)",
    borderRadius: Border.br_5xs,
    position: "absolute",
    shadowOpacity: 1,
    shadowOffset: {
      width: 0,
      height: 4,
    },
    backgroundColor: Color.colorWhite,
  },
  buttonShadowBox15: {
    top: 4074,
    left: 37,
    borderColor: Color.colorLightseagreen,
    paddingVertical: Padding.p_sm,
    paddingHorizontal: Padding.p_5xl,
    justifyContent: "center",
    alignItems: "center",
    flexDirection: "row",
    height: 53,
    width: 294,
    borderWidth: 3,
    borderStyle: "solid",
    elevation: 2,
    shadowRadius: 2,
    shadowColor: "rgba(0, 0, 0, 0.05)",
    borderRadius: Border.br_5xs,
    position: "absolute",
    shadowOpacity: 1,
    shadowOffset: {
      width: 0,
      height: 4,
    },
    backgroundColor: Color.colorWhite,
  },
  buttonShadowBox14: {
    top: 3410,
    left: 35,
    borderColor: Color.colorLightseagreen,
    paddingVertical: Padding.p_sm,
    paddingHorizontal: Padding.p_5xl,
    justifyContent: "center",
    alignItems: "center",
    flexDirection: "row",
    height: 53,
    width: 294,
    borderWidth: 3,
    borderStyle: "solid",
    elevation: 2,
    shadowRadius: 2,
    shadowColor: "rgba(0, 0, 0, 0.05)",
    borderRadius: Border.br_5xs,
    position: "absolute",
    shadowOpacity: 1,
    shadowOffset: {
      width: 0,
      height: 4,
    },
    backgroundColor: Color.colorWhite,
  },
  buttonShadowBox13: {
    top: 3493,
    left: 35,
    borderColor: Color.colorLightseagreen,
    paddingVertical: Padding.p_sm,
    paddingHorizontal: Padding.p_5xl,
    justifyContent: "center",
    alignItems: "center",
    flexDirection: "row",
    height: 53,
    width: 294,
    borderWidth: 3,
    borderStyle: "solid",
    elevation: 2,
    shadowRadius: 2,
    shadowColor: "rgba(0, 0, 0, 0.05)",
    borderRadius: Border.br_5xs,
    position: "absolute",
    shadowOpacity: 1,
    shadowOffset: {
      width: 0,
      height: 4,
    },
    backgroundColor: Color.colorWhite,
  },
  buttonShadowBox12: {
    top: 3576,
    left: 35,
    borderColor: Color.colorLightseagreen,
    paddingVertical: Padding.p_sm,
    paddingHorizontal: Padding.p_5xl,
    justifyContent: "center",
    alignItems: "center",
    flexDirection: "row",
    height: 53,
    width: 294,
    borderWidth: 3,
    borderStyle: "solid",
    elevation: 2,
    shadowRadius: 2,
    shadowColor: "rgba(0, 0, 0, 0.05)",
    borderRadius: Border.br_5xs,
    position: "absolute",
    shadowOpacity: 1,
    shadowOffset: {
      width: 0,
      height: 4,
    },
    backgroundColor: Color.colorWhite,
  },
  buttonShadowBox11: {
    top: 3659,
    left: 35,
    borderColor: Color.colorLightseagreen,
    paddingVertical: Padding.p_sm,
    paddingHorizontal: Padding.p_5xl,
    justifyContent: "center",
    alignItems: "center",
    flexDirection: "row",
    height: 53,
    width: 294,
    borderWidth: 3,
    borderStyle: "solid",
    elevation: 2,
    shadowRadius: 2,
    shadowColor: "rgba(0, 0, 0, 0.05)",
    borderRadius: Border.br_5xs,
    position: "absolute",
    shadowOpacity: 1,
    shadowOffset: {
      width: 0,
      height: 4,
    },
    backgroundColor: Color.colorWhite,
  },
  buttonShadowBox10: {
    top: 3742,
    left: 35,
    borderColor: Color.colorLightseagreen,
    paddingVertical: Padding.p_sm,
    paddingHorizontal: Padding.p_5xl,
    justifyContent: "center",
    alignItems: "center",
    flexDirection: "row",
    height: 53,
    width: 294,
    borderWidth: 3,
    borderStyle: "solid",
    elevation: 2,
    shadowRadius: 2,
    shadowColor: "rgba(0, 0, 0, 0.05)",
    borderRadius: Border.br_5xs,
    position: "absolute",
    shadowOpacity: 1,
    shadowOffset: {
      width: 0,
      height: 4,
    },
    backgroundColor: Color.colorWhite,
  },
  buttonShadowBox9: {
    top: 2996,
    left: 35,
    borderColor: Color.colorLightseagreen,
    paddingVertical: Padding.p_sm,
    paddingHorizontal: Padding.p_5xl,
    justifyContent: "center",
    alignItems: "center",
    flexDirection: "row",
    height: 53,
    width: 294,
    borderWidth: 3,
    borderStyle: "solid",
    elevation: 2,
    shadowRadius: 2,
    shadowColor: "rgba(0, 0, 0, 0.05)",
    borderRadius: Border.br_5xs,
    position: "absolute",
    shadowOpacity: 1,
    shadowOffset: {
      width: 0,
      height: 4,
    },
    backgroundColor: Color.colorWhite,
  },
  buttonShadowBox8: {
    top: 3079,
    left: 35,
    borderColor: Color.colorLightseagreen,
    paddingVertical: Padding.p_sm,
    paddingHorizontal: Padding.p_5xl,
    justifyContent: "center",
    alignItems: "center",
    flexDirection: "row",
    height: 53,
    width: 294,
    borderWidth: 3,
    borderStyle: "solid",
    elevation: 2,
    shadowRadius: 2,
    shadowColor: "rgba(0, 0, 0, 0.05)",
    borderRadius: Border.br_5xs,
    position: "absolute",
    shadowOpacity: 1,
    shadowOffset: {
      width: 0,
      height: 4,
    },
    backgroundColor: Color.colorWhite,
  },
  buttonShadowBox7: {
    top: 3162,
    left: 35,
    borderColor: Color.colorLightseagreen,
    paddingVertical: Padding.p_sm,
    paddingHorizontal: Padding.p_5xl,
    justifyContent: "center",
    alignItems: "center",
    flexDirection: "row",
    height: 53,
    width: 294,
    borderWidth: 3,
    borderStyle: "solid",
    elevation: 2,
    shadowRadius: 2,
    shadowColor: "rgba(0, 0, 0, 0.05)",
    borderRadius: Border.br_5xs,
    position: "absolute",
    shadowOpacity: 1,
    shadowOffset: {
      width: 0,
      height: 4,
    },
    backgroundColor: Color.colorWhite,
  },
  buttonShadowBox6: {
    top: 3245,
    left: 35,
    borderColor: Color.colorLightseagreen,
    paddingVertical: Padding.p_sm,
    paddingHorizontal: Padding.p_5xl,
    justifyContent: "center",
    alignItems: "center",
    flexDirection: "row",
    height: 53,
    width: 294,
    borderWidth: 3,
    borderStyle: "solid",
    elevation: 2,
    shadowRadius: 2,
    shadowColor: "rgba(0, 0, 0, 0.05)",
    borderRadius: Border.br_5xs,
    position: "absolute",
    shadowOpacity: 1,
    shadowOffset: {
      width: 0,
      height: 4,
    },
    backgroundColor: Color.colorWhite,
  },
  buttonShadowBox5: {
    top: 3328,
    left: 35,
    borderColor: Color.colorLightseagreen,
    paddingVertical: Padding.p_sm,
    paddingHorizontal: Padding.p_5xl,
    justifyContent: "center",
    alignItems: "center",
    flexDirection: "row",
    height: 53,
    width: 294,
    borderWidth: 3,
    borderStyle: "solid",
    elevation: 2,
    shadowRadius: 2,
    shadowColor: "rgba(0, 0, 0, 0.05)",
    borderRadius: Border.br_5xs,
    position: "absolute",
    shadowOpacity: 1,
    shadowOffset: {
      width: 0,
      height: 4,
    },
    backgroundColor: Color.colorWhite,
  },
  buttonShadowBox4: {
    left: 42,
    top: 4240,
    borderColor: Color.colorLightseagreen,
    paddingVertical: Padding.p_sm,
    paddingHorizontal: Padding.p_5xl,
    justifyContent: "center",
    alignItems: "center",
    flexDirection: "row",
    height: 53,
    width: 294,
    borderWidth: 3,
    borderStyle: "solid",
    elevation: 2,
    shadowRadius: 2,
    shadowColor: "rgba(0, 0, 0, 0.05)",
    borderRadius: Border.br_5xs,
    position: "absolute",
    shadowOpacity: 1,
    shadowOffset: {
      width: 0,
      height: 4,
    },
    backgroundColor: Color.colorWhite,
  },
  buttonShadowBox3: {
    top: 4323,
    left: 42,
    borderColor: Color.colorLightseagreen,
    paddingVertical: Padding.p_sm,
    paddingHorizontal: Padding.p_5xl,
    justifyContent: "center",
    alignItems: "center",
    flexDirection: "row",
    height: 53,
    width: 294,
    borderWidth: 3,
    borderStyle: "solid",
    elevation: 2,
    shadowRadius: 2,
    shadowColor: "rgba(0, 0, 0, 0.05)",
    borderRadius: Border.br_5xs,
    position: "absolute",
    shadowOpacity: 1,
    shadowOffset: {
      width: 0,
      height: 4,
    },
    backgroundColor: Color.colorWhite,
  },
  buttonShadowBox2: {
    top: 4406,
    left: 42,
    borderColor: Color.colorLightseagreen,
    paddingVertical: Padding.p_sm,
    paddingHorizontal: Padding.p_5xl,
    justifyContent: "center",
    alignItems: "center",
    flexDirection: "row",
    height: 53,
    width: 294,
    borderWidth: 3,
    borderStyle: "solid",
    elevation: 2,
    shadowRadius: 2,
    shadowColor: "rgba(0, 0, 0, 0.05)",
    borderRadius: Border.br_5xs,
    position: "absolute",
    shadowOpacity: 1,
    shadowOffset: {
      width: 0,
      height: 4,
    },
    backgroundColor: Color.colorWhite,
  },
  buttonShadowBox1: {
    top: 4489,
    left: 42,
    borderColor: Color.colorLightseagreen,
    paddingVertical: Padding.p_sm,
    paddingHorizontal: Padding.p_5xl,
    justifyContent: "center",
    alignItems: "center",
    flexDirection: "row",
    height: 53,
    width: 294,
    borderWidth: 3,
    borderStyle: "solid",
    elevation: 2,
    shadowRadius: 2,
    shadowColor: "rgba(0, 0, 0, 0.05)",
    borderRadius: Border.br_5xs,
    position: "absolute",
    shadowOpacity: 1,
    shadowOffset: {
      width: 0,
      height: 4,
    },
    backgroundColor: Color.colorWhite,
  },
  buttonShadowBox: {
    left: 40,
    top: 4157,
    borderColor: Color.colorLightseagreen,
    paddingVertical: Padding.p_sm,
    paddingHorizontal: Padding.p_5xl,
    justifyContent: "center",
    alignItems: "center",
    flexDirection: "row",
    height: 53,
    width: 294,
    borderWidth: 3,
    borderStyle: "solid",
    elevation: 2,
    shadowRadius: 2,
    shadowColor: "rgba(0, 0, 0, 0.05)",
    borderRadius: Border.br_5xs,
    position: "absolute",
    shadowOpacity: 1,
    shadowOffset: {
      width: 0,
      height: 4,
    },
    backgroundColor: Color.colorWhite,
  },
  buttonPrimary87: {
    top: 4654,
  },
  buttonPrimary88: {
    top: 4571,
  },
  kiemtraC9Child: {
    height: 164,
    left: 0,
    top: 0,
    backgroundColor: Color.colorWhite,
    width: 375,
  },
  container: {
    backgroundColor: Color.colorWhitesmoke_100,
    width: 40,
    height: 40,
    left: 0,
    top: 0,
    borderRadius: Border.br_5xs,
  },
  filterIcon: {
    top: 8,
    left: 8,
    position: "absolute",
  },
  iconfilter: {
    left: 319,
    width: 40,
    height: 40,
    top: 104,
  },
  label: {
    fontSize: FontSize.presetsBody2_size,
    lineHeight: 24,
    fontFamily: FontFamily.presetsBody2,
    color: Color.colorGray,
    marginLeft: 12,
    textAlign: "left",
    overflow: "hidden",
  },
  search: {
    left: 16,
    borderColor: Color.colorGainsboro_200,
    borderWidth: 1,
    width: 295,
    paddingLeft: Padding.p_xs,
    paddingTop: Padding.p_5xs,
    paddingRight: Padding.p_base,
    paddingBottom: Padding.p_5xs,
    top: 104,
    height: 40,
    alignItems: "center",
    flexDirection: "row",
    borderStyle: "solid",
    borderRadius: Border.br_5xs,
    backgroundColor: Color.colorWhite,
  },
  notchIcon: {
    top: -2,
    right: 78,
    bottom: 16,
    left: 78,
    maxWidth: "100%",
    maxHeight: "100%",
    overflow: "hidden",
  },
  batteryIcon: {
    right: 0,
    height: 11,
    width: 24,
    top: 0,
    position: "absolute",
  },
  wifiIcon: {
    width: 15,
    height: 11,
  },
  mobileSignalIcon: {
    width: 17,
    height: 11,
  },
  recordingIndicatorIcon: {
    top: -9,
    right: 56,
    width: 6,
    height: 6,
  },
  rightSide: {
    top: 17,
    right: 15,
    width: 67,
    height: 11,
    position: "absolute",
  },
  leftSideIcon: {
    top: 12,
    left: 21,
    width: 54,
    height: 21,
    position: "absolute",
  },
  statusBarIphoneXOrNewe: {
    height: 44,
    left: 0,
    top: 0,
    overflow: "hidden",
  },
  homeIndicator1: {
    marginLeft: -66.5,
    bottom: 8,
    left: "50%",
    borderRadius: Border.br_81xl,
    backgroundColor: Color.colorBlack,
    width: 134,
    height: 5,
    position: "absolute",
  },
  homeIndicator: {
    bottom: 0,
    left: 1,
    height: 34,
    backgroundColor: Color.colorWhite,
    width: 375,
  },
  kiemtraC9: {
    shadowColor: "rgba(0, 0, 0, 0.25)",
    shadowRadius: 4,
    elevation: 4,
    width: "100%",
    height: 4811,
    overflow: "hidden",
    shadowOpacity: 1,
    shadowOffset: {
      width: 0,
      height: 4,
    },
    flex: 1,
    backgroundColor: Color.colorWhite,
  },
});

export default KiemtraC;
